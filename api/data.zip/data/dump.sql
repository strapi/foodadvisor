-- -------------------------------------------------------------
-- TablePlus 3.6.1(320)
--
-- https://tableplus.com/
--
-- Database: data.db
-- Generation Time: 2020-06-18 3:34:59.2060 PM
-- -------------------------------------------------------------


CREATE TABLE `about_uses` (`id` integer not null primary key autoincrement, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);

CREATE TABLE `about_uses_components` (`id` integer not null primary key autoincrement, `field` varchar(255) not null, `order` integer not null, `component_type` varchar(255) not null, `component_id` integer not null, `about_us_id` integer not null, constraint `about_us_id_fk` foreign key(`about_us_id`) references "tmp_about_uses"(`id`) on delete CASCADE);

CREATE TABLE `categories` (`id` integer not null primary key autoincrement, `name` varchar(255) null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);

CREATE TABLE `components_about_us_headers` (`id` integer not null primary key autoincrement, `title` varchar(255) null, `description` text null);

CREATE TABLE `components_about_us_lists` (`id` integer not null primary key autoincrement, `content` varchar(255) null);

CREATE TABLE `components_about_us_text_block_with_lists` (`id` integer not null primary key autoincrement, `title` varchar(255) null, `body` text null);

CREATE TABLE `components_about_us_text_block_with_lists_components` (`id` integer not null primary key autoincrement, `field` varchar(255) not null, `order` integer not null, `component_type` varchar(255) not null, `component_id` integer not null, `components_about_us_text_block_with_list_id` integer not null, constraint `components_about_us_text_block_with_list_id_fk` foreign key(`components_about_us_text_block_with_list_id`) references `components_about_us_text_block_with_lists`(`id`) on delete CASCADE);

CREATE TABLE `components_about_us_text_block_with_titles` (`id` integer not null primary key autoincrement, `title` varchar(255) null, `content` text null);

CREATE TABLE `components_about_us_text_blocks` (`id` integer not null primary key autoincrement, `content` text null);

CREATE TABLE "components_opening_hours" (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `day_interval` varchar(255) not null, `opening_hour` varchar(255) null, `closing_hour` varchar(255) null);

CREATE TABLE `core_store` (
                          id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
`key` varchar(255)  NULL ,
`value` longtext  NULL ,
`type` varchar(255)  NULL ,
`environment` varchar(255)  NULL ,
`tag` varchar(255)  NULL 
                        );

CREATE TABLE `likes` (`id` integer not null primary key autoincrement, `author` integer null, `review` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);

CREATE TABLE `restaurants` (`id` integer not null primary key autoincrement, `name` varchar(255) null, `description` text null, `address` varchar(255) null, `website` varchar(255) null, `phone` varchar(255) null, `price` text check (`price` in ('_1', '_2', '_3', '_4')) null, `district` text check (`district` in ('_1st', '_2nd', '_3rd', '_4th', '_5th', '_6th', '_7th', '_8th', '_9th', '_10th', '_11th', '_12th', '_13th', '_14th', '_15th', '_16th', '_17th', '_18th', '_19th', '_20th')) null, `category` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);

CREATE TABLE "restaurants_components" (`id` integer not null primary key autoincrement, `field` varchar(255) not null, `order` integer not null, "component_type" varchar(255) not null, "component_id" integer not null, `restaurant_id` integer not null, foreign key(`restaurant_id`) references "tmp_restaurants"(`id`) on delete CASCADE);

CREATE TABLE `reviews` (`id` integer not null primary key autoincrement, `content` text null, `note` integer null, `author` integer null, `restaurant` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);

CREATE TABLE `strapi_administrator` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `username` varchar(255) not null, `email` varchar(255) not null, `password` varchar(255) not null, `resetPasswordToken` varchar(255) null, `blocked` boolean null);

CREATE TABLE `strapi_webhooks` (`id` integer not null primary key autoincrement, `name` varchar(255) null, `url` text null, `headers` text null, `events` text null, `enabled` boolean null);

CREATE TABLE `upload_file` (`id` integer not null primary key autoincrement, `name` varchar(255) not null, `alternativeText` varchar(255) null, `caption` varchar(255) null, `width` integer null, `height` integer null, `formats` text null, `hash` varchar(255) not null, `ext` varchar(255) null, `mime` varchar(255) not null, `size` float not null, `url` varchar(255) not null, `previewUrl` varchar(255) null, `provider` varchar(255) not null, `provider_metadata` text null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);

CREATE TABLE `upload_file_morph` (`id` integer not null primary key autoincrement, `upload_file_id` integer null, `related_id` integer null, `related_type` text null, `field` text null, `order` integer null);

CREATE TABLE `users-permissions_permission` (
                          id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
`type` varchar(255) NOT NULL ,
`controller` varchar(255) NOT NULL ,
`action` varchar(255) NOT NULL ,
`enabled` boolean NOT NULL ,
`policy` varchar(255)  NULL ,
`role` integer  NULL 
                        );

CREATE TABLE `users-permissions_role` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` varchar(255) not null, `description` varchar(255) null, `type` varchar(255) null);

CREATE TABLE `users-permissions_user` (`id` integer not null primary key autoincrement, `username` varchar(255) not null, `email` varchar(255) not null, `provider` varchar(255) null, `password` varchar(255) null, `resetPasswordToken` varchar(255) null, `confirmed` boolean null, `blocked` boolean null, `role` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);

INSERT INTO "about_uses" ("id", "created_at", "updated_at") VALUES
('1', '1592485228823', '1592485228823');

INSERT INTO "about_uses_components" ("id", "field", "order", "component_type", "component_id", "about_us_id") VALUES
('1', 'header', '1', 'components_about_us_headers', '1', '1'),
('2', 'body', '1', 'components_about_us_text_blocks', '1', '1'),
('3', 'body', '3', 'components_about_us_text_block_with_titles', '1', '1'),
('4', 'body', '2', 'components_about_us_text_block_with_lists', '1', '1');

INSERT INTO "categories" ("id", "name", "created_at", "updated_at") VALUES
('1', 'French', '1552325063771', '1552325063771'),
('2', 'Contemporary', '1552325063772', '1552325063772'),
('3', 'Italian', '1552325063772', '1552325063772'),
('4', 'Mexican', '1552325063773', '1552325063773'),
('5', 'Burgers', '1552325063773', '1552325063773'),
('6', 'Fusion', '1552325063774', '1552325063774'),
('7', 'Korean', '1552325063774', '1552325063774'),
('8', 'Mediterranean', '1552325063775', '1552325063775'),
('9', 'Vegan', '1552325063775', '1552325063775'),
('10', 'Local', '1552325063776', '1552325063776'),
('11', 'Japanese', '1552325063777', '1552325063777'),
('12', 'Pub', '1552325063777', '1552325063777'),
('13', 'Wine Bar', '1552325063778', '1552325063778'),
('14', 'Indian', '1552325063778', '1552325063778'),
('15', 'Vietnamese', '1552325063780', '1552325063780'),
('16', 'Fast Food', '1552325063781', '1552325063781'),
('17', 'Peruvien', '1552325063782', '1552325063782'),
('18', 'Fish', '1552325063782', '1552325063782'),
('19', 'Lebanese', '1552325063784', '1552325063784'),
('20', 'Dessert', '1552325063784', '1552325063784'),
('21', 'African', '1552325063785', '1552325063785'),
('22', 'Brazilian', '1552325063786', '1552325063786');

INSERT INTO "components_about_us_headers" ("id", "title", "description") VALUES
('1', 'About us', 'Manage you **content**,
Distribute it **anywhere**.');

INSERT INTO "components_about_us_lists" ("id", "content") VALUES
('1', 'List of products'),
('2', 'Comments'),
('3', 'Static Page'),
('4', 'Image Management'),
('5', 'Reviews'),
('6', 'Votes'),
('7', 'Filters');

INSERT INTO "components_about_us_text_block_with_lists" ("id", "title", "body") VALUES
('1', 'Our Mission', 'FoodAdvisor’s mission is to show you the endless possibilities of using Strapi to manage your content and making it accessible through a flexible and highly customizable API. And also to make you discover some of the restaurants we like in Paris.

FoodAdvisor displays functionalities like :');

INSERT INTO "components_about_us_text_block_with_lists_components" ("id", "field", "order", "component_type", "component_id", "components_about_us_text_block_with_list_id") VALUES
('1', 'list', '1', 'components_about_us_lists', '1', '1'),
('2', 'list', '5', 'components_about_us_lists', '2', '1'),
('3', 'list', '7', 'components_about_us_lists', '4', '1'),
('4', 'list', '6', 'components_about_us_lists', '3', '1'),
('5', 'list', '2', 'components_about_us_lists', '7', '1'),
('6', 'list', '3', 'components_about_us_lists', '5', '1'),
('7', 'list', '4', 'components_about_us_lists', '6', '1');

INSERT INTO "components_about_us_text_block_with_titles" ("id", "title", "content") VALUES
('1', 'Say Hello', 'If you have any question, a partnership, or just need some help, reach out to us. We’re available.

hi@strapi.io');

INSERT INTO "components_about_us_text_blocks" ("id", "content") VALUES
('1', 'FoodAdvisor is a app example to show you what can be made with Strapi. This is about restaurants because we like good food. And based in Paris because we’re from here.

We produce Strapi, a collaborative open-source headless CMS fueled by a community of amazing developers, designers and users. We use the word “food” a lot, because food is sharing and sharing is caring so come be our friend and see if we mean it.');

INSERT INTO "components_opening_hours" ("id", "day_interval", "opening_hour", "closing_hour") VALUES
('65', 'Tue - Sat', '7:30 PM', '10:00 PM'),
('66', 'Sun', '7:00 PM', '11:00 PM'),
('67', 'Wed - Thu', '7:00 PM', '11:00 PM'),
('68', 'Fri', '7:00 PM', '12:00 AM'),
('69', 'Sat', '7:30 PM', '12:00 AM'),
('70', 'Sun', '11:30 AM', '3:00 PM'),
('71', 'Tue - Sat', '6:00 PM', '11:30 PM'),
('72', 'Sun - Sat', '7:45 PM', '11:00 PM'),
('73', 'Sat - Sun', '12:00 PM', '3:00 PM'),
('74', 'Tue - Sat', '7:00 PM', '12:30 AM'),
('75', 'Du mardi au samedi', '19h', '20h'),
('76', 'Sun - Sat', '7:00 PM', '10:30 PM'),
('77', 'Mon - Fri', '11:30 AM', '3:00 PM'),
('78', 'Sun - Sat', '12:00 PM', '2:30 PM'),
('79', 'Sun - Sat', '7:00 PM', '11:30 PM'),
('80', 'Sun - Sat', '6:00 PM', '2:00 AM'),
('81', 'Wed - Sun', '12:30 PM', '2:00 PM'),
('82', 'Wed - Sun', '7:30 PM', '9:30 PM'),
('83', 'Tue - Fri', '12:00 PM', '2:30 PM'),
('84', 'Tue - Fri', '7:00 PM', '10:00 PM'),
('85', 'Sat - Sun', '11:30 AM', '3:00 PM'),
('86', 'Mon', '12:00 PM', '3:00 PM'),
('87', 'Tue - Sat', '12:00 PM', '10:30 PM'),
('88', 'Mon - Sat', '12:00', '22:30'),
('89', 'Tue - Thu', '12:00 PM', '2:00 PM'),
('90', 'Tue - Sat', '7:00 PM', '10:30 PM'),
('91', 'Fri - Sat', '12:00 PM', '3:30 PM'),
('92', 'Sun - Sat', '12:00 PM', '2:30 PM'),
('93', 'Sun - Sat', '7:00 PM', '10:30 PM'),
('94', 'Sun - Thu', '7:00 PM', '10:30 PM'),
('95', 'Mon - Fri', '12:00 PM', '2:30 PM'),
('96', 'Fri - Sat', '7:00 PM', '11:00 PM'),
('97', 'Sat - Sun', '12:00 PM', '3:00 PM'),
('98', 'Mon - Fri', '12:00 PM', '2:00 PM'),
('99', 'Mon - Sat', '6:00 PM', '9:00 PM'),
('100', 'Sat', '12:00 PM', '3:00 PM'),
('101', 'Sun', '7:00 PM', '10:00 PM'),
('102', 'Tue - Sat', '7:00 PM', '10:30 PM'),
('103', 'Wed - Sun', '12:00 PM', '2:30 PM'),
('104', 'Tue - Sat', '10:30 AM', '7:30 PM'),
('105', 'Sun', '10:00 AM', '4:00 PM'),
('106', 'Mon - Fri', '5:00 PM', '10:00 PM'),
('107', 'Tue - Fri', '10:00 AM', '2:00 PM'),
('108', 'Sat', '10:00 AM', '10:00 PM'),
('109', 'Sun', '12:00 PM', '10:30 PM'),
('110', 'Tue - Fri', '11:00 AM', '4:00 PM'),
('111', 'Tue - Fri', '6:00 PM', '11:30 PM'),
('112', 'Sat', '11:00 AM', '11:30 PM'),
('113', 'Sun', '9:00 AM', '7:00 PM'),
('114', 'Tue - Sat', '9:00 AM', '8:00 PM'),
('115', 'Tue - Sun', '12:00 PM', '2:30 PM'),
('116', 'Sun', '7:00 PM', '10:00 PM'),
('117', 'Tue - Sat', '7:00 PM', '10:30 PM'),
('118', 'Wed - Sat', '7:00 PM', '10:30 PM'),
('119', 'Tue - Thu', '12:00 PM', '10:30 PM'),
('120', 'Fri - Sat', '12:00 PM', '11:00 PM'),
('121', 'Sun', '11:00 AM', '4:00 PM'),
('122', 'Wed - Sun', '7:30 PM', '10:30 PM'),
('123', 'Fri - Sat', '12:00 PM', '2:30 PM'),
('124', 'Tue - Sat', '12:00 PM', '10:00 PM'),
('125', 'Fri', '8:00 AM', '2:00 AM'),
('126', 'Sat - Thu', '8:00 AM', '12:00 AM'),
('127', 'Sat', '12:00 AM', '2:00 AM'),
('128', 'Mon - Sat', '11:30 AM', '12:00 AM');

INSERT INTO "core_store" ("id", "key", "value", "type", "environment", "tag") VALUES
('1', 'db_model_categories', '{"name":{"default":"","type":"string"},"restaurants":{"collection":"restaurant","via":"category","isVirtual":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}', 'object', NULL, NULL),
('2', 'db_model_likes', '{"author":{"model":"user","via":"likes","plugin":"users-permissions"},"review":{"model":"review","via":"likes"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}', 'object', NULL, NULL),
('3', 'db_model_restaurants', '{"cover":{"collection":"file","via":"related","plugin":"upload"},"name":{"default":"","type":"string"},"description":{"default":"","type":"text"},"address":{"default":"","type":"string"},"website":{"default":"","type":"string"},"phone":{"default":"","type":"string"},"price":{"default":"","type":"enumeration","enum":["_1","_2","_3","_4"]},"district":{"default":"","type":"enumeration","enum":["_1st","_2nd","_3rd","_4th","_5th","_6th","_7th","_8th","_9th","_10th","_11th","_12th","_13th","_14th","_15th","_16th","_17th","_18th","_19th","_20th"]},"reviews":{"collection":"review","via":"restaurant","isVirtual":true},"category":{"model":"category","via":"restaurants"},"opening_hours":{"type":"component","component":"restaurant.opening-hours","min":1,"repeatable":true,"required":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}', 'object', NULL, NULL),
('4', 'db_model_reviews', '{"content":{"default":"","type":"text"},"note":{"default":"","type":"integer","max":5},"author":{"model":"user","via":"reviews","plugin":"users-permissions"},"likes":{"collection":"like","via":"review","isVirtual":true},"restaurant":{"model":"restaurant","via":"reviews"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}', 'object', NULL, NULL),
('5', 'db_model_core_store', '{"key":{"type":"string"},"value":{"type":"text"},"type":{"type":"string"},"environment":{"type":"string"},"tag":{"type":"string"}}', 'object', NULL, NULL),
('6', 'db_model_upload_file', '{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"collection":"*","filter":"field","configurable":false},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}', 'object', NULL, NULL),
('7', 'db_model_users-permissions_permission', '{"type":{"type":"string","required":true,"configurable":false},"controller":{"type":"string","required":true,"configurable":false},"action":{"type":"string","required":true,"configurable":false},"enabled":{"type":"boolean","required":true,"configurable":false},"policy":{"type":"string","configurable":false},"role":{"model":"role","via":"permissions","plugin":"users-permissions","configurable":false}}', 'object', NULL, NULL),
('8', 'db_model_users-permissions_role', '{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"collection":"permission","via":"role","plugin":"users-permissions","configurable":false,"isVirtual":true},"users":{"collection":"user","via":"role","configurable":false,"plugin":"users-permissions","isVirtual":true}}', 'object', NULL, NULL),
('9', 'db_model_users-permissions_user', '{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"model":"role","via":"users","plugin":"users-permissions","configurable":false},"reviews":{"collection":"review","via":"author","isVirtual":true},"likes":{"collection":"like","via":"author","isVirtual":true},"picture":{"model":"file","via":"related","plugin":"upload","required":false},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}', 'object', NULL, NULL),
('10', 'db_model_upload_file_morph', '{"upload_file_id":{"type":"integer"},"related_id":{"type":"integer"},"related_type":{"type":"text"},"field":{"type":"text"},"order":{"type":"integer"}}', 'object', NULL, NULL),
('11', 'plugin_content-manager_schema', '{"generalSettings":{"search":true,"filters":true,"bulkActions":true,"pageEntries":10},"models":{"plugins":{"upload":{"file":{"label":"File","labelPlural":"Files","orm":"bookshelf","search":true,"filters":true,"bulkActions":true,"pageEntries":10,"defaultSort":"id","sort":"ASC","options":{"timestamps":["created_at","updated_at"]},"editDisplay":{"availableFields":{"name":{"label":"Name","type":"string","description":"","name":"name","editable":true,"placeholder":""},"hash":{"label":"Hash","type":"string","description":"","name":"hash","editable":true,"placeholder":""},"sha256":{"label":"Sha256","type":"string","description":"","name":"sha256","editable":true,"placeholder":""},"ext":{"label":"Ext","type":"string","description":"","name":"ext","editable":true,"placeholder":""},"mime":{"label":"Mime","type":"string","description":"","name":"mime","editable":true,"placeholder":""},"size":{"label":"Size","type":"string","description":"","name":"size","editable":true,"placeholder":""},"url":{"label":"Url","type":"string","description":"","name":"url","editable":true,"placeholder":""},"provider":{"label":"Provider","type":"string","description":"","name":"provider","editable":true,"placeholder":""},"public_id":{"label":"Public_id","type":"string","description":"","name":"public_id","editable":true,"placeholder":""}},"displayedField":"id","fields":["name","hash","sha256","ext","mime","size","url","provider","public_id"],"relations":[]},"info":{"name":"file","description":""},"connection":"default","collectionName":"upload_file","attributes":{"name":{"type":"string","configurable":false,"required":true},"hash":{"type":"string","configurable":false,"required":true},"sha256":{"type":"string","configurable":false},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"string","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"provider":{"type":"string","configurable":false,"required":true},"public_id":{"type":"string","configurable":false},"related":{"collection":"*","filter":"field","configurable":false}},"globalId":"UploadFile","globalName":"UploadFile","primaryKey":"id","associations":[{"alias":"related","type":"collection","related":["Restaurant","UsersPermissionsUser"],"nature":"manyMorphToOne","autoPopulate":true,"filter":"field"}],"fields":{"name":{"label":"Name","description":"","type":"string","disabled":false,"name":"name","sortable":true,"searchable":true},"hash":{"label":"Hash","description":"","type":"string","disabled":false,"name":"hash","sortable":true,"searchable":true},"sha256":{"label":"Sha256","description":"","type":"string","disabled":false,"name":"sha256","sortable":true,"searchable":true},"ext":{"label":"Ext","description":"","type":"string","disabled":false,"name":"ext","sortable":true,"searchable":true},"mime":{"label":"Mime","description":"","type":"string","disabled":false,"name":"mime","sortable":true,"searchable":true},"size":{"label":"Size","description":"","type":"string","disabled":false,"name":"size","sortable":true,"searchable":true},"url":{"label":"Url","description":"","type":"string","disabled":false,"name":"url","sortable":true,"searchable":true},"provider":{"label":"Provider","description":"","type":"string","disabled":false,"name":"provider","sortable":true,"searchable":true},"public_id":{"label":"Public_id","description":"","type":"string","disabled":false,"name":"public_id","sortable":true,"searchable":true}},"listDisplay":[{"name":"id","label":"Id","type":"string","sortable":true,"searchable":true},{"label":"Name","description":"","type":"string","disabled":false,"name":"name","sortable":true,"searchable":true},{"label":"Hash","description":"","type":"string","disabled":false,"name":"hash","sortable":true,"searchable":true},{"label":"Sha256","description":"","type":"string","disabled":false,"name":"sha256","sortable":true,"searchable":true},{"label":"Ext","description":"","type":"string","disabled":false,"name":"ext","sortable":true,"searchable":true}],"relations":{"related":{"alias":"related","type":"collection","related":["Restaurant","UsersPermissionsUser"],"nature":"manyMorphToOne","autoPopulate":true,"filter":"field","description":"","label":"Related","displayedAttribute":"id"}}}},"users-permissions":{"permission":{"label":"Permission","labelPlural":"Permissions","orm":"bookshelf","search":true,"filters":true,"bulkActions":true,"pageEntries":10,"defaultSort":"id","sort":"ASC","options":{"timestamps":false},"editDisplay":{"availableFields":{"type":{"label":"Type","type":"string","description":"","name":"type","editable":true,"placeholder":""},"controller":{"label":"Controller","type":"string","description":"","name":"controller","editable":true,"placeholder":""},"action":{"label":"Action","type":"string","description":"","name":"action","editable":true,"placeholder":""},"enabled":{"label":"Enabled","type":"boolean","description":"","name":"enabled","editable":true,"placeholder":""},"policy":{"label":"Policy","type":"string","description":"","name":"policy","editable":true,"placeholder":""}},"displayedField":"id","fields":["type","controller","action","enabled","policy"],"relations":["role"]},"info":{"name":"permission","description":""},"connection":"default","collectionName":"users-permissions_permission","attributes":{"type":{"type":"string","required":true,"configurable":false},"controller":{"type":"string","required":true,"configurable":false},"action":{"type":"string","required":true,"configurable":false},"enabled":{"type":"boolean","required":true,"configurable":false},"policy":{"type":"string","configurable":false},"role":{"model":"role","via":"permissions","plugin":"users-permissions","configurable":false}},"globalId":"UsersPermissionsPermission","globalName":"UsersPermissionsPermission","primaryKey":"id","associations":[{"alias":"role","type":"model","model":"role","via":"permissions","nature":"manyToOne","autoPopulate":true,"dominant":true,"plugin":"users-permissions"}],"fields":{"type":{"label":"Type","description":"","type":"string","disabled":false,"name":"type","sortable":true,"searchable":true},"controller":{"label":"Controller","description":"","type":"string","disabled":false,"name":"controller","sortable":true,"searchable":true},"action":{"label":"Action","description":"","type":"string","disabled":false,"name":"action","sortable":true,"searchable":true},"enabled":{"label":"Enabled","description":"","type":"boolean","disabled":false,"name":"enabled","sortable":true,"searchable":true},"policy":{"label":"Policy","description":"","type":"string","disabled":false,"name":"policy","sortable":true,"searchable":true}},"listDisplay":[{"name":"id","label":"Id","type":"string","sortable":true,"searchable":true},{"label":"Type","description":"","type":"string","disabled":false,"name":"type","sortable":true,"searchable":true},{"label":"Controller","description":"","type":"string","disabled":false,"name":"controller","sortable":true,"searchable":true},{"label":"Action","description":"","type":"string","disabled":false,"name":"action","sortable":true,"searchable":true},{"label":"Enabled","description":"","type":"boolean","disabled":false,"name":"enabled","sortable":true,"searchable":true}],"relations":{"role":{"alias":"role","type":"model","model":"role","via":"permissions","nature":"manyToOne","autoPopulate":true,"dominant":true,"plugin":"users-permissions","description":"","label":"Role","displayedAttribute":"name"}}},"role":{"label":"Role","labelPlural":"Roles","orm":"bookshelf","search":true,"filters":true,"bulkActions":true,"pageEntries":10,"defaultSort":"id","sort":"ASC","options":{"timestamps":false},"editDisplay":{"availableFields":{"name":{"label":"Name","type":"string","description":"","name":"name","editable":true,"placeholder":""},"description":{"label":"Description","type":"string","description":"","name":"description","editable":true,"placeholder":""},"type":{"label":"Type","type":"string","description":"","name":"type","editable":true,"placeholder":""}},"displayedField":"id","fields":["name","description","type"],"relations":["permissions","users"]},"info":{"name":"role","description":""},"connection":"default","collectionName":"users-permissions_role","attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"collection":"permission","via":"role","plugin":"users-permissions","configurable":false,"isVirtual":true},"users":{"collection":"user","via":"role","plugin":"users-permissions","isVirtual":true}},"globalId":"UsersPermissionsRole","globalName":"UsersPermissionsRole","primaryKey":"id","associations":[{"alias":"permissions","type":"collection","collection":"permission","via":"role","nature":"oneToMany","autoPopulate":true,"dominant":true,"plugin":"users-permissions"},{"alias":"users","type":"collection","collection":"user","via":"role","nature":"oneToMany","autoPopulate":true,"dominant":true,"plugin":"users-permissions"}],"fields":{"name":{"label":"Name","description":"","type":"string","disabled":false,"name":"name","sortable":true,"searchable":true},"description":{"label":"Description","description":"","type":"string","disabled":false,"name":"description","sortable":true,"searchable":true},"type":{"label":"Type","description":"","type":"string","disabled":false,"name":"type","sortable":true,"searchable":true}},"listDisplay":[{"name":"id","label":"Id","type":"string","sortable":true,"searchable":true},{"label":"Name","description":"","type":"string","disabled":false,"name":"name","sortable":true,"searchable":true},{"label":"Description","description":"","type":"string","disabled":false,"name":"description","sortable":true,"searchable":true},{"label":"Type","description":"","type":"string","disabled":false,"name":"type","sortable":true,"searchable":true}],"relations":{"permissions":{"alias":"permissions","type":"collection","collection":"permission","via":"role","nature":"oneToMany","autoPopulate":true,"dominant":true,"plugin":"users-permissions","description":"","label":"Permissions","displayedAttribute":"type"},"users":{"alias":"users","type":"collection","collection":"user","via":"role","nature":"oneToMany","autoPopulate":true,"dominant":true,"plugin":"users-permissions","description":"","label":"Users","displayedAttribute":"username"}}},"user":{"label":"User","labelPlural":"Users","orm":"bookshelf","search":true,"filters":true,"bulkActions":true,"pageEntries":10,"defaultSort":"id","sort":"ASC","options":{"timestamps":false},"editDisplay":{"availableFields":{"username":{"label":"Username","type":"string","description":"","name":"username","editable":true,"placeholder":""},"email":{"label":"Email","type":"email","description":"","name":"email","editable":true,"placeholder":""},"provider":{"label":"Provider","type":"string","description":"","name":"provider","editable":true,"placeholder":""},"password":{"label":"Password","type":"password","description":"","name":"password","editable":true,"placeholder":""},"confirmed":{"label":"Confirmed","type":"boolean","description":"","name":"confirmed","editable":true,"placeholder":""},"blocked":{"label":"Blocked","type":"boolean","description":"","name":"blocked","editable":true,"placeholder":""},"picture":{"description":"","editable":true,"label":"Picture","multiple":false,"name":"picture","placeholder":"","type":"file","disabled":false}},"displayedField":"id","fields":["username","email","provider","password","confirmed","blocked","picture"],"relations":["role","reviews","likes"]},"info":{"name":"user","description":""},"connection":"default","collectionName":"users-permissions_user","attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"model":"role","via":"users","plugin":"users-permissions","configurable":false},"reviews":{"collection":"review","via":"author","isVirtual":true},"likes":{"collection":"like","via":"author","isVirtual":true},"picture":{"model":"file","via":"related","plugin":"upload","required":false}},"globalId":"UsersPermissionsUser","globalName":"UsersPermissionsUser","primaryKey":"id","associations":[{"alias":"role","type":"model","model":"role","via":"users","nature":"manyToOne","autoPopulate":true,"dominant":true,"plugin":"users-permissions"},{"alias":"reviews","type":"collection","collection":"review","via":"author","nature":"oneToMany","autoPopulate":true,"dominant":true},{"alias":"likes","type":"collection","collection":"like","via":"author","nature":"oneToMany","autoPopulate":true,"dominant":true},{"alias":"picture","type":"model","model":"file","via":"related","nature":"oneToManyMorph","autoPopulate":true,"dominant":true,"plugin":"upload","filter":"field"}],"fields":{"username":{"label":"Username","description":"","type":"string","disabled":false,"name":"username","sortable":true,"searchable":true},"email":{"label":"Email","description":"","type":"email","disabled":false,"name":"email","sortable":true,"searchable":true},"provider":{"label":"Provider","description":"","type":"string","disabled":false,"name":"provider","sortable":true,"searchable":true},"password":{"label":"Password","description":"","type":"password","disabled":false,"name":"password","sortable":true,"searchable":true},"confirmed":{"label":"Confirmed","description":"","type":"boolean","disabled":false,"name":"confirmed","sortable":true,"searchable":true},"blocked":{"label":"Blocked","description":"","type":"boolean","disabled":false,"name":"blocked","sortable":true,"searchable":true}},"listDisplay":[{"name":"id","label":"Id","type":"string","sortable":true,"searchable":true},{"label":"Username","description":"","type":"string","disabled":false,"name":"username","sortable":true,"searchable":true},{"label":"Email","description":"","type":"email","disabled":false,"name":"email","sortable":true,"searchable":true},{"label":"Provider","description":"","type":"string","disabled":false,"name":"provider","sortable":true,"searchable":true},{"label":"Password","description":"","type":"password","disabled":false,"name":"password","sortable":true,"searchable":true}],"relations":{"role":{"alias":"role","type":"model","model":"role","via":"users","nature":"manyToOne","autoPopulate":true,"dominant":true,"plugin":"users-permissions","description":"","label":"Role","displayedAttribute":"name"},"reviews":{"alias":"reviews","type":"collection","collection":"review","via":"author","nature":"oneToMany","autoPopulate":true,"dominant":true,"description":"","label":"Reviews","displayedAttribute":"id"},"likes":{"alias":"likes","type":"collection","collection":"like","via":"author","nature":"oneToMany","autoPopulate":true,"dominant":true,"description":"","label":"Likes","displayedAttribute":"id"},"picture":{"alias":"picture","type":"model","model":"file","via":"related","nature":"oneToManyMorph","autoPopulate":true,"dominant":true,"plugin":"upload","filter":"field","description":"","label":"Picture","displayedAttribute":"name"}}}}},"category":{"label":"Category","labelPlural":"Categories","orm":"bookshelf","search":true,"filters":true,"bulkActions":true,"pageEntries":10,"defaultSort":"id","sort":"ASC","options":{"increments":true,"timestamps":["created_at","updated_at"],"comment":""},"editDisplay":{"availableFields":{"name":{"label":"Name","type":"string","description":"","name":"name","editable":true,"placeholder":""}},"displayedField":"id","fields":["name"],"relations":["restaurants"]},"info":{"name":"category","description":""},"connection":"default","collectionName":"categories","attributes":{"name":{"default":"","type":"string"},"restaurants":{"collection":"restaurant","via":"category","isVirtual":true}},"globalId":"Category","globalName":"Category","primaryKey":"id","associations":[{"alias":"restaurants","type":"collection","collection":"restaurant","via":"category","nature":"oneToMany","autoPopulate":true,"dominant":true}],"fields":{"name":{"label":"Name","description":"","type":"string","disabled":false,"name":"name","sortable":true,"searchable":true}},"listDisplay":[{"name":"id","label":"Id","type":"string","sortable":true,"searchable":true},{"label":"Name","description":"","type":"string","disabled":false,"name":"name","sortable":true,"searchable":true}],"relations":{"restaurants":{"alias":"restaurants","type":"collection","collection":"restaurant","via":"category","nature":"oneToMany","autoPopulate":true,"dominant":true,"description":"","label":"Restaurants","displayedAttribute":"name"}}},"like":{"label":"Like","labelPlural":"Likes","orm":"bookshelf","search":true,"filters":true,"bulkActions":true,"pageEntries":10,"defaultSort":"id","sort":"ASC","options":{"increments":true,"timestamps":["created_at","updated_at"],"comment":""},"editDisplay":{"availableFields":{},"displayedField":"id","fields":[],"relations":["author","review"]},"info":{"name":"like","description":""},"connection":"default","collectionName":"likes","attributes":{"author":{"model":"user","via":"likes","plugin":"users-permissions"},"review":{"model":"review","via":"likes"}},"globalId":"Like","globalName":"Like","primaryKey":"id","associations":[{"alias":"author","type":"model","model":"user","via":"likes","nature":"manyToOne","autoPopulate":true,"dominant":true,"plugin":"users-permissions"},{"alias":"review","type":"model","model":"review","via":"likes","nature":"manyToOne","autoPopulate":true,"dominant":true}],"fields":{},"listDisplay":[{"name":"id","label":"Id","type":"string","sortable":true,"searchable":true}],"relations":{"author":{"alias":"author","type":"model","model":"user","via":"likes","nature":"manyToOne","autoPopulate":true,"dominant":true,"plugin":"users-permissions","description":"","label":"Author","displayedAttribute":"username"},"review":{"alias":"review","type":"model","model":"review","via":"likes","nature":"manyToOne","autoPopulate":true,"dominant":true,"description":"","label":"Review","displayedAttribute":"id"}}},"restaurant":{"label":"Restaurant","labelPlural":"Restaurants","orm":"bookshelf","search":true,"filters":true,"bulkActions":true,"pageEntries":10,"defaultSort":"id","sort":"ASC","options":{"increments":true,"timestamps":["created_at","updated_at"],"comment":""},"editDisplay":{"availableFields":{"name":{"label":"Name","type":"string","description":"","name":"name","editable":true,"placeholder":""},"description":{"label":"Description","type":"text","description":"","name":"description","editable":true,"placeholder":""},"opening_hours":{"label":"Opening_hours","type":"text","description":"","name":"opening_hours","editable":true,"placeholder":""},"address":{"label":"Address","type":"string","description":"","name":"address","editable":true,"placeholder":""},"website":{"label":"Website","type":"string","description":"","name":"website","editable":true,"placeholder":""},"phone":{"label":"Phone","type":"string","description":"","name":"phone","editable":true,"placeholder":""},"price":{"label":"Price","type":"enumeration","description":"","name":"price","editable":true,"placeholder":""},"district":{"label":"District","type":"enumeration","description":"","name":"district","editable":true,"placeholder":""},"cover":{"description":"","editable":true,"label":"Cover","multiple":true,"name":"cover","placeholder":"","type":"file","disabled":false}},"displayedField":"id","fields":["name","description","opening_hours","address","website","phone","price","district","cover"],"relations":["reviews","category"]},"info":{"name":"restaurant","description":""},"connection":"default","collectionName":"restaurants","attributes":{"cover":{"collection":"file","via":"related","plugin":"upload","required":false},"name":{"default":"","type":"string"},"description":{"default":"","type":"text"},"opening_hours":{"default":"","type":"text"},"address":{"default":"","type":"string"},"website":{"default":"","type":"string"},"phone":{"default":"","type":"string"},"price":{"default":"","type":"enumeration","enum":["_1","_2","_3","_4"]},"district":{"default":"","type":"enumeration","enum":["_1st","_2nd","_3rd","_4th","_5th","_6th","_7th","_8th","_9th","_10th","_11th","_12th","_13th","_14th","_15th","_16th","_17th","_18th","_19th","_20th"]},"reviews":{"collection":"review","via":"restaurant","isVirtual":true},"category":{"model":"category","via":"restaurants"}},"globalId":"Restaurant","globalName":"Restaurant","primaryKey":"id","associations":[{"alias":"cover","type":"collection","collection":"file","via":"related","nature":"manyToManyMorph","autoPopulate":true,"dominant":true,"plugin":"upload","filter":"field"},{"alias":"reviews","type":"collection","collection":"review","via":"restaurant","nature":"oneToMany","autoPopulate":true,"dominant":true},{"alias":"category","type":"model","model":"category","via":"restaurants","nature":"manyToOne","autoPopulate":true,"dominant":true}],"fields":{"name":{"label":"Name","description":"","type":"string","disabled":false,"name":"name","sortable":true,"searchable":true},"description":{"label":"Description","description":"","type":"text","disabled":false,"name":"description","sortable":true,"searchable":true},"opening_hours":{"label":"Opening_hours","description":"","type":"text","disabled":false,"name":"opening_hours","sortable":true,"searchable":true},"address":{"label":"Address","description":"","type":"string","disabled":false,"name":"address","sortable":true,"searchable":true},"website":{"label":"Website","description":"","type":"string","disabled":false,"name":"website","sortable":true,"searchable":true},"phone":{"label":"Phone","description":"","type":"string","disabled":false,"name":"phone","sortable":true,"searchable":true},"price":{"label":"Price","description":"","type":"enumeration","disabled":false,"name":"price","sortable":true,"searchable":true},"district":{"label":"District","description":"","type":"enumeration","disabled":false,"name":"district","sortable":true,"searchable":true}},"listDisplay":[{"name":"id","label":"Id","type":"string","sortable":true,"searchable":true},{"label":"Name","description":"","type":"string","disabled":false,"name":"name","sortable":true,"searchable":true},{"label":"Description","description":"","type":"text","disabled":false,"name":"description","sortable":true,"searchable":true},{"label":"Opening_hours","description":"","type":"text","disabled":false,"name":"opening_hours","sortable":true,"searchable":true},{"label":"Address","description":"","type":"string","disabled":false,"name":"address","sortable":true,"searchable":true}],"relations":{"cover":{"alias":"cover","type":"collection","collection":"file","via":"related","nature":"manyToManyMorph","autoPopulate":true,"dominant":true,"plugin":"upload","filter":"field","description":"","label":"Cover","displayedAttribute":"name"},"reviews":{"alias":"reviews","type":"collection","collection":"review","via":"restaurant","nature":"oneToMany","autoPopulate":true,"dominant":true,"description":"","label":"Reviews","displayedAttribute":"id"},"category":{"alias":"category","type":"model","model":"category","via":"restaurants","nature":"manyToOne","autoPopulate":true,"dominant":true,"description":"","label":"Category","displayedAttribute":"name"}}},"review":{"label":"Review","labelPlural":"Reviews","orm":"bookshelf","search":true,"filters":true,"bulkActions":true,"pageEntries":10,"defaultSort":"id","sort":"ASC","options":{"increments":true,"timestamps":["created_at","updated_at"],"comment":""},"editDisplay":{"availableFields":{"content":{"label":"Content","type":"text","description":"","name":"content","editable":true,"placeholder":""},"note":{"label":"Note","type":"integer","description":"","name":"note","editable":true,"placeholder":""}},"displayedField":"id","fields":["content","note"],"relations":["author","restaurant","likes"]},"info":{"name":"review","description":""},"connection":"default","collectionName":"reviews","attributes":{"content":{"default":"","type":"text"},"note":{"default":"","type":"integer","max":5},"author":{"model":"user","via":"reviews","plugin":"users-permissions"},"restaurant":{"model":"restaurant","via":"reviews"},"likes":{"collection":"like","via":"review","isVirtual":true}},"globalId":"Review","globalName":"Review","primaryKey":"id","associations":[{"alias":"author","type":"model","model":"user","via":"reviews","nature":"manyToOne","autoPopulate":true,"dominant":true,"plugin":"users-permissions"},{"alias":"restaurant","type":"model","model":"restaurant","via":"reviews","nature":"manyToOne","autoPopulate":true,"dominant":true},{"alias":"likes","type":"collection","collection":"like","via":"review","nature":"oneToMany","autoPopulate":true,"dominant":true}],"fields":{"content":{"label":"Content","description":"","type":"text","disabled":false,"name":"content","sortable":true,"searchable":true},"note":{"label":"Note","description":"","type":"integer","disabled":false,"name":"note","sortable":true,"searchable":true}},"listDisplay":[{"name":"id","label":"Id","type":"string","sortable":true,"searchable":true},{"label":"Content","description":"","type":"text","disabled":false,"name":"content","sortable":true,"searchable":true},{"label":"Note","description":"","type":"integer","disabled":false,"name":"note","sortable":true,"searchable":true}],"relations":{"author":{"alias":"author","type":"model","model":"user","via":"reviews","nature":"manyToOne","autoPopulate":true,"dominant":true,"plugin":"users-permissions","description":"","label":"Author","displayedAttribute":"username"},"restaurant":{"alias":"restaurant","type":"model","model":"restaurant","via":"reviews","nature":"manyToOne","autoPopulate":true,"dominant":true,"description":"","label":"Restaurant","displayedAttribute":"name"},"likes":{"alias":"likes","type":"collection","collection":"like","via":"review","nature":"oneToMany","autoPopulate":true,"dominant":true,"description":"","label":"Likes","displayedAttribute":"id"}}}},"layout":{"user":{"actions":{"create":"User.create","update":"User.update","destroy":"User.destroy","deleteall":"User.destroyAll"},"attributes":{"username":{"className":"col-md-6"},"email":{"className":"col-md-6"},"resetPasswordToken":{"className":"d-none"},"role":{"className":"d-none"}}},"category":{"attributes":{}},"like":{"attributes":{}},"restaurant":{"attributes":{}},"review":{"attributes":{}}}}', 'object', '', ''),
('12', 'core_application', '{"name":"Default Application","description":"This API is going to be awesome!"}', 'object', '', ''),
('13', 'plugin_users-permissions_grant', '{"email":{"enabled":true,"icon":"envelope"},"discord":{"enabled":false,"icon":"comments","key":"","secret":"","callback":"/auth/discord/callback","scope":["identify","email"]},"facebook":{"enabled":false,"icon":"facebook-official","key":"","secret":"","callback":"/auth/facebook/callback","scope":["email"]},"google":{"enabled":false,"icon":"google","key":"","secret":"","callback":"/auth/google/callback","scope":["email"]},"github":{"enabled":false,"icon":"github","key":"","secret":"","callback":"/auth/github/callback","scope":["user","user:email"],"redirect_uri":"/auth/github/callback"},"microsoft":{"enabled":false,"icon":"windows","key":"","secret":"","callback":"/auth/microsoft/callback","scope":["user.read"]},"twitter":{"enabled":false,"icon":"twitter","key":"","secret":"","callback":"/auth/twitter/callback"},"instagram":{"enabled":false,"icon":"instagram","key":"","secret":"","callback":"/auth/instagram/callback"},"vk":{"enabled":false,"icon":"vk","key":"","secret":"","callback":"/auth/vk/callback","scope":["email"]},"twitch":{"enabled":false,"icon":"twitch","key":"","secret":"","callback":"/auth/twitch/callback","scope":["user:read:email"]}}', 'object', '', ''),
('14', 'plugin_email_provider', '{"provider":"sendmail","name":"Sendmail","auth":{"sendmail_default_from":{"label":"Sendmail Default From","type":"text"},"sendmail_default_replyto":{"label":"Sendmail Default Reply-To","type":"text"}}}', 'object', 'development', ''),
('15', 'plugin_upload_provider', '{"provider":"local","name":"Local server","enabled":true,"sizeLimit":1000000}', 'object', 'development', ''),
('16', 'plugin_users-permissions_email', '{"reset_password":{"display":"Email.template.reset_password","icon":"refresh","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"­Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\n\n<p>But don’t worry! You can use the following link to reset your password:</p>\n\n<p><%= URL %>?code=<%= TOKEN %></p>\n\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square-o","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\n\n<p>You have to confirm your email address. Please click on the link below.</p>\n\n<p><%= URL %>?confirmation=<%= CODE %></p>\n\n<p>Thanks.</p>"}}}', 'object', '', ''),
('17', 'plugin_users-permissions_advanced', '{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_confirmation_redirection":"http://localhost:1337/admin","default_role":"authenticated"}', 'object', '', ''),
('18', 'db_model_groups_opening_hours', '{"day_interval":{"required":true,"type":"string"},"opening_hour":{"type":"string"},"closing_hour":{"type":"string"}}', 'object', NULL, NULL),
('19', 'db_model_strapi_administrator', '{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"required":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"blocked":{"type":"boolean","default":false,"configurable":false}}', 'object', NULL, NULL),
('20', 'plugin_documentation_config', '{"restrictedAccess":false}', 'object', '', ''),
('25', 'plugin_content_manager_configuration_content_types::admin.administrator', '{"uid":"administrator","source":"admin","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","resetPasswordToken"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"resetPasswordToken","size":6}],[{"name":"blocked","size":4}]],"editRelations":[]}}', 'object', '', ''),
('26', 'plugin_content_manager_configuration_content_types::upload.file', '{"uid":"file","source":"upload","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"hash":{"edit":{"label":"Hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Hash","searchable":true,"sortable":true}},"sha256":{"edit":{"label":"Sha256","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Sha256","searchable":true,"sortable":true}},"ext":{"edit":{"label":"Ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"Mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"Size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Size","searchable":true,"sortable":true}},"url":{"edit":{"label":"Url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Url","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"public_id":{"edit":{"label":"Public_id","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Public_id","searchable":true,"sortable":true}},"related":{"edit":{"label":"Related","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Related","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","hash","sha256"],"edit":[[{"name":"name","size":6},{"name":"hash","size":6}],[{"name":"sha256","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":6}],[{"name":"url","size":6},{"name":"provider","size":6}],[{"name":"public_id","size":6}]],"editRelations":["related"]}}', 'object', '', ''),
('27', 'plugin_content_manager_configuration_content_types::users-permissions.permission', '{"uid":"permission","source":"users-permissions","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"controller":{"edit":{"label":"Controller","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Controller","searchable":true,"sortable":true}},"action":{"edit":{"label":"Action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Action","searchable":true,"sortable":true}},"enabled":{"edit":{"label":"Enabled","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Enabled","searchable":true,"sortable":true}},"policy":{"edit":{"label":"Policy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Policy","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}}},"layouts":{"list":["id","type","controller","action"],"edit":[[{"name":"type","size":6},{"name":"controller","size":6}],[{"name":"action","size":6},{"name":"enabled","size":4}],[{"name":"policy","size":6}]],"editRelations":["role"]}}', 'object', '', ''),
('28', 'plugin_content_manager_configuration_content_types::users-permissions.role', '{"uid":"role","source":"users-permissions","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"Permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"type"},"list":{"label":"Permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"Users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Users","searchable":false,"sortable":false}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6}]],"editRelations":["permissions","users"]}}', 'object', '', ''),
('29', 'plugin_content_manager_configuration_content_types::users-permissions.user', '{"uid":"user","source":"users-permissions","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"Confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}},"reviews":{"edit":{"label":"Reviews","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Reviews","searchable":false,"sortable":false}},"likes":{"edit":{"label":"Likes","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Likes","searchable":false,"sortable":false}},"picture":{"edit":{"label":"Picture","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Picture","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","provider"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"provider","size":6},{"name":"password","size":6}],[{"name":"resetPasswordToken","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"picture","size":6}]],"editRelations":["role","reviews","likes"]}}', 'object', '', ''),
('30', 'plugin_content_manager_configuration_groups::opening_hours', '{"uid":"opening_hours","isGroup":true,"settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"day_interval","defaultSortBy":"day_interval","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"day_interval":{"edit":{"label":"Day_interval","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Day_interval","searchable":true,"sortable":true}},"opening_hour":{"edit":{"label":"Opening_hour","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Opening_hour","searchable":true,"sortable":true}},"closing_hour":{"edit":{"label":"Closing_hour","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Closing_hour","searchable":true,"sortable":true}}},"layouts":{"list":["day_interval","opening_hour","closing_hour"],"edit":[[{"name":"day_interval","size":6},{"name":"opening_hour","size":6}],[{"name":"closing_hour","size":6}]],"editRelations":[]}}', 'object', '', ''),
('31', 'db_model_strapi_webhooks', '{"name":{"type":"string"},"url":{"type":"text"},"headers":{"type":"json"},"events":{"type":"json"},"enabled":{"type":"boolean"}}', 'object', NULL, NULL),
('32', 'db_model_components_opening_hours', '{"day_interval":{"required":true,"type":"string"},"opening_hour":{"type":"string"},"closing_hour":{"type":"string"}}', 'object', NULL, NULL),
('33', 'plugin_content_manager_configuration_content_types::application::category.category', '{"uid":"application::category.category","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"restaurants":{"edit":{"label":"Restaurants","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Restaurants","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","created_at","updated_at"],"edit":[[{"name":"name","size":6}]],"editRelations":["restaurants"]}}', 'object', '', ''),
('34', 'plugin_content_manager_configuration_content_types::application::like.like', '{"uid":"application::like.like","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"author":{"edit":{"label":"Author","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Author","searchable":false,"sortable":false}},"review":{"edit":{"label":"Review","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Review","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","created_at","updated_at"],"edit":[],"editRelations":["author","review"]}}', 'object', '', ''),
('35', 'plugin_content_manager_configuration_content_types::application::restaurant.restaurant', '{"uid":"application::restaurant.restaurant","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"cover":{"edit":{"label":"Cover","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Cover","searchable":false,"sortable":false}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"address":{"edit":{"label":"Address","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Address","searchable":true,"sortable":true}},"website":{"edit":{"label":"Website","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Website","searchable":true,"sortable":true}},"phone":{"edit":{"label":"Phone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Phone","searchable":true,"sortable":true}},"price":{"edit":{"label":"Price","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Price","searchable":true,"sortable":true}},"district":{"edit":{"label":"District","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"District","searchable":true,"sortable":true}},"reviews":{"edit":{"label":"Reviews","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Reviews","searchable":false,"sortable":false}},"category":{"edit":{"label":"Category","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Category","searchable":false,"sortable":false}},"opening_hours":{"edit":{"label":"Opening_hours","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Opening_hours","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","cover","name","description"],"edit":[[{"name":"cover","size":6},{"name":"name","size":6}],[{"name":"description","size":6},{"name":"address","size":6}],[{"name":"website","size":6},{"name":"phone","size":6}],[{"name":"price","size":6},{"name":"district","size":6}],[{"name":"opening_hours","size":12}]],"editRelations":["reviews","category"]}}', 'object', '', ''),
('36', 'plugin_content_manager_configuration_content_types::application::review.review', '{"uid":"application::review.review","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"content":{"edit":{"label":"Content","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Content","searchable":true,"sortable":true}},"note":{"edit":{"label":"Note","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Note","searchable":true,"sortable":true}},"author":{"edit":{"label":"Author","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Author","searchable":false,"sortable":false}},"likes":{"edit":{"label":"Likes","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Likes","searchable":false,"sortable":false}},"restaurant":{"edit":{"label":"Restaurant","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Restaurant","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","content","note","created_at"],"edit":[[{"name":"content","size":6},{"name":"note","size":4}]],"editRelations":["author","likes","restaurant"]}}', 'object', '', ''),
('37', 'plugin_content_manager_configuration_content_types::plugins::upload.file', '{"uid":"plugins::upload.file","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"AlternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"AlternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"Caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"Width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Width","searchable":true,"sortable":true}},"height":{"edit":{"label":"Height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"Formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"Hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"Ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"Mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"Size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Size","searchable":true,"sortable":true}},"url":{"edit":{"label":"Url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"PreviewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"PreviewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"Provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Provider_metadata","searchable":false,"sortable":false}},"related":{"edit":{"label":"Related","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Related","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","hash","alternativeText"],"edit":[[{"name":"name","size":6},{"name":"hash","size":6}],[{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"alternativeText","size":6},{"name":"caption","size":6}],[{"name":"width","size":4},{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"previewUrl","size":6}]],"editRelations":["related"]}}', 'object', '', ''),
('38', 'plugin_content_manager_configuration_content_types::plugins::users-permissions.permission', '{"uid":"plugins::users-permissions.permission","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"type","defaultSortBy":"type","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"controller":{"edit":{"label":"Controller","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Controller","searchable":true,"sortable":true}},"action":{"edit":{"label":"Action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Action","searchable":true,"sortable":true}},"enabled":{"edit":{"label":"Enabled","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Enabled","searchable":true,"sortable":true}},"policy":{"edit":{"label":"Policy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Policy","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}}},"layouts":{"list":["id","type","controller","action"],"edit":[[{"name":"type","size":6},{"name":"controller","size":6}],[{"name":"action","size":6},{"name":"enabled","size":4}],[{"name":"policy","size":6}]],"editRelations":["role"]}}', 'object', '', ''),
('39', 'plugin_content_manager_configuration_content_types::plugins::users-permissions.role', '{"uid":"plugins::users-permissions.role","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"Permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"type"},"list":{"label":"Permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"Users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Users","searchable":false,"sortable":false}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6}]],"editRelations":["permissions","users"]}}', 'object', '', ''),
('40', 'plugin_content_manager_configuration_content_types::strapi::administrator', '{"uid":"strapi::administrator","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","blocked"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"blocked","size":4}]],"editRelations":[]}}', 'object', '', ''),
('41', 'plugin_content_manager_configuration_content_types::plugins::users-permissions.user', '{"uid":"plugins::users-permissions.user","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"Confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}},"reviews":{"edit":{"label":"Reviews","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Reviews","searchable":false,"sortable":false}},"likes":{"edit":{"label":"Likes","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Likes","searchable":false,"sortable":false}},"picture":{"edit":{"label":"Picture","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Picture","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"picture","size":6}]],"editRelations":["role","reviews","likes"]}}', 'object', '', ''),
('42', 'plugin_content_manager_configuration_components::restaurant.opening-hours', '{"uid":"restaurant.opening-hours","isComponent":true,"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"day_interval","defaultSortBy":"day_interval","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"day_interval":{"edit":{"label":"Day_interval","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Day_interval","searchable":true,"sortable":true}},"opening_hour":{"edit":{"label":"Opening_hour","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Opening_hour","searchable":true,"sortable":true}},"closing_hour":{"edit":{"label":"Closing_hour","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Closing_hour","searchable":true,"sortable":true}}},"layouts":{"list":["id","day_interval","opening_hour","closing_hour"],"edit":[[{"name":"day_interval","size":6},{"name":"opening_hour","size":6}],[{"name":"closing_hour","size":6}]],"editRelations":[]}}', 'object', '', ''),
('43', 'db_model_components_about_us_headers', '{"logo":{"model":"file","via":"related","allowedTypes":["images","files","videos"],"plugin":"upload","required":false},"title":{"type":"string"},"description":{"type":"richtext"}}', 'object', NULL, NULL),
('44', 'db_model_components_about_us_lists', '{"content":{"type":"string"}}', 'object', NULL, NULL),
('45', 'db_model_components_about_us_text_block_with_lists', '{"title":{"type":"string"},"body":{"type":"richtext"},"list":{"type":"component","repeatable":true,"component":"about-us.list"}}', 'object', NULL, NULL),
('46', 'db_model_components_about_us_text_block_with_titles', '{"title":{"type":"string"},"content":{"type":"richtext"}}', 'object', NULL, NULL),
('47', 'db_model_components_about_us_text_blocks', '{"content":{"type":"richtext"}}', 'object', NULL, NULL),
('48', 'db_model_about_uses', '{"header":{"type":"component","repeatable":false,"component":"about-us.header","required":true},"body":{"type":"dynamiczone","components":["about-us.text-block","about-us.text-block-with-title","about-us.text-block-with-list"]},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}', 'object', NULL, NULL),
('49', 'plugin_upload_settings', '{"sizeOptimization":true,"responsiveDimensions":true}', 'object', 'development', ''),
('50', 'plugin_content_manager_configuration_content_types::application::about-us.about-us', '{"uid":"application::about-us.about-us","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"header":{"edit":{"label":"Header","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Header","searchable":false,"sortable":false}},"body":{"edit":{"label":"Body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Body","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","created_at","updated_at"],"editRelations":[],"edit":[[{"name":"header","size":12}],[{"name":"body","size":12}]]}}', 'object', '', ''),
('51', 'plugin_content_manager_configuration_components::about-us.header', '{"uid":"about-us.header","isComponent":true,"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"logo":{"edit":{"label":"Logo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Logo","searchable":false,"sortable":false}},"title":{"edit":{"label":"Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Title","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":false,"sortable":false}}},"layouts":{"list":["id","logo","title"],"edit":[[{"name":"logo","size":6}],[{"name":"title","size":6}],[{"name":"description","size":12}]],"editRelations":[]}}', 'object', '', ''),
('52', 'plugin_content_manager_configuration_components::about-us.list', '{"uid":"about-us.list","isComponent":true,"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"content","defaultSortBy":"content","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"content":{"edit":{"label":"Content","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Content","searchable":true,"sortable":true}}},"layouts":{"list":["id","content"],"edit":[[{"name":"content","size":6}]],"editRelations":[]}}', 'object', '', ''),
('53', 'plugin_content_manager_configuration_components::about-us.text-block-with-list', '{"uid":"about-us.text-block-with-list","isComponent":true,"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"title":{"edit":{"label":"Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Title","searchable":true,"sortable":true}},"body":{"edit":{"label":"Body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Body","searchable":false,"sortable":false}},"list":{"edit":{"label":"List","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"List","searchable":false,"sortable":false}}},"layouts":{"list":["id","title"],"edit":[[{"name":"title","size":6}],[{"name":"body","size":12}],[{"name":"list","size":12}]],"editRelations":[]}}', 'object', '', ''),
('54', 'plugin_content_manager_configuration_components::about-us.text-block-with-title', '{"uid":"about-us.text-block-with-title","isComponent":true,"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"title":{"edit":{"label":"Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Title","searchable":true,"sortable":true}},"content":{"edit":{"label":"Content","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Content","searchable":false,"sortable":false}}},"layouts":{"list":["id","title"],"edit":[[{"name":"title","size":6}],[{"name":"content","size":12}]],"editRelations":[]}}', 'object', '', ''),
('55', 'plugin_content_manager_configuration_components::about-us.text-block', '{"uid":"about-us.text-block","isComponent":true,"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"content":{"edit":{"label":"Content","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Content","searchable":false,"sortable":false}}},"layouts":{"list":["id"],"edit":[[{"name":"content","size":12}]],"editRelations":[]}}', 'object', '', '');

INSERT INTO "likes" ("id", "author", "review", "created_at", "updated_at") VALUES
('1', '2', '120', '1552409861500', '1553524828411'),
('2', '49', '137', '1552409874018', '1553525156969'),
('3', '49', '112', '1552409882376', '1553524578363'),
('4', '49', '136', '1552409890865', '1553525179660'),
('5', '52', '139', '1552409899519', '1553525206475'),
('6', '37', '115', '1552409905809', '1553524704341'),
('7', '40', '61', '1552409912840', '1552409912842'),
('8', '40', '140', '1552409918062', '1553525228396'),
('9', '17', '113', '1552409924094', '1553524619572'),
('10', '44', '121', '1552409931449', '1553524862220'),
('11', '46', '113', '1552409936266', '1553524619574'),
('12', '102', '116', '1552409974380', '1553524676545'),
('13', '101', '131', '1552409982823', '1553525054285'),
('14', '100', '132', '1552409991172', '1553525073953'),
('15', '80', '133', '1552410000442', '1553525108725'),
('16', '65', '127', '1552410009488', '1553524996898'),
('17', '3', '118', '1552410015610', '1553524748576'),
('18', '2', '125', '1552410019978', '1553524967437'),
('19', '10', '134', '1552410027899', '1553525123933'),
('20', '44', '135', '1552410035499', '1553525141595'),
('21', '50', '88', '1552410043633', '1552487130992'),
('22', '69', '119', '1552410067648', '1552410067651'),
('23', '19', '62', '1552410075180', '1552410075183'),
('24', '42', '118', '1552410079652', '1553524748575'),
('25', '19', '117', '1552410088188', '1553524731859'),
('26', '34', '80', '1552410097276', '1552410097279'),
('27', '56', '126', '1552410104876', '1553524987058'),
('28', '31', '34', '1552410113948', '1552410113951'),
('29', '65', '116', '1552410121354', '1553524676547'),
('30', '44', '3', '1552410127531', '1552487181210'),
('31', '91', '112', '1552410138455', '1553524578363'),
('32', '22', '111', '1552410147963', '1553524558089'),
('33', '50', '116', '1552410159092', '1553524676548');

INSERT INTO "restaurants" ("id", "name", "description", "address", "website", "phone", "price", "district", "category", "created_at", "updated_at") VALUES
('1', 'ASPIC', 'ASPIC is a human sized Parisian restaurant located in the heart of the 9th district, close to Place Pigalle. ASPIC serves a seasonal set menu that changes every month and dishes are served by the chefs for a better dinning experience. We serve organic and natural wines.', '24 Rue de la Tour d''Auvergne, 75009 Paris', 'aspic-restaurant.fr', '09 82 49 30 98', '_4', '_9th', '1', '1552325063905', '1552498274417'),
('2', 'Signature Montmartre', 'Fusion Korean Restaurant in Paris Montmartre, just next to the Sacre Coeur. Signature Montmartre Restaurant Korean traditional dishes adapted with French gastronomy. Signature Restaurant''s chefs cooks quality and healthy products to give you the best of both worlds!', '12 rue des Trois Freres, 75018 Paris', 'https://signature-montmartre.fr', '+33 1 84 25 30 00', '_2', '_18th', '6', '1552325063905', '1552498325471'),
('3', 'Can Alegria Paris', 'If you like Mediterranean and exotic dishes, then discover Can Alegria. This new restaurant set in the heart of the Pigalle neighborhood, this new place has been designed by Marc-Antoine Colonna and Matthieu Lecomte.', '73 rue Jean Baptiste Pigalle, 75009 Paris', 'https://www.canalegriaparis.com/en/', '+33 6 13 10 51 90', '_2', '_9th', '8', '1552325063906', '1552498368145'),
('4', 'Bateau le Calife', 'Your dinner cruise on a boat barge on the Seine river, dining out Paris.', 'Amarre Port de Saints-Peres | Pont des Arts, 75006 Paris', 'http://www.calife.com/english/Croisiere/Diner_croisiere.html', '+33 1 43 54 50 04', '_3', '_6th', '9', '1552325063906', '1552498414258'),
('5', 'Le Piaf', 'Le Piaf embodies its name in full: a charming sparrow that lives on music, fresh water, and little feasts has flown over Paris from top to bottom, deciding to make a nest on a quiet street in the chic 8th arrondissement, at 38 Rue Jean Mermoz, just a stone''s throw from the luxury boutiques of Avenue Montaigne and the Champs Elysees. This cute birdie loves company, good cooking and also to unwind with friends in a trendy and cozy place with a mellow atmosphere. And so it was natural to name it Piaf, just like France’s own sultry songstress-sparrow, Edith.', '38 rue Jean Mermoz, 75008 Paris', 'https://lepiaf-paris.com/', '+33 1 47 42 64 10', '_3', '_8th', '1', '1552325063907', '1552498477137'),
('6', 'GUILO GUILO', 'Reserve well in advance for a seat at the counter where you can watch Kyoto chef Eichi Edakuni prepare a modern Japanese feast before your eyes.', '8 rue Garreau, 75018 Paris', 'https://lefooding.com/en/restaurants/restaurant-guilo-guilo-paris', '+33 1 42 54 23 92', '_4', '_18th', '6', '1552325063907', '1552498495585'),
('7', 'La MiN', 'The MiN is a restaurant with 2 rooms. One with a friendly atmosphere (like that of his big brother restaurant "Le MiM" in montreuil).
As well as a vaulted room more intimate and romantic.', '45 rue de Montreuil, 75011 Paris', 'https://la-min-paris.eatbu.com/?lang=en', '+33 1 73 71 47 15', '_2', '_11th', '12', '1552325063907', '1552498528556'),
('8', 'Oplato', '
The philosophy of Oplato can be summed up in a few words: to find the flavors and the atmosphere of the good aperitifs of yesteryear. Our concept is simple: to offer quality boards to share with friends.', '69 rue de Charonne, 75011 Paris', 'http://www.oplato.com', '+33 9 81 80 44 70', '_2', '_11th', '13', '1552325063908', '1552498571433'),
('9', 'Le jardin du Kashmir', '
INDO-PAKISTANIZED KITCHEN - Taste walk in the Kashmir Garden! This Indo-Pakistani restaurant offers fine and neat cuisine ... Ideal for taste buds!', '60 rue Legendre, 75017 Paris, France', 'https://jardindukashmir.fr/en', '+33 1 42 12 94 88', '_2', '_17th', '14', '1552325063908', '1552498656057'),
('10', 'Cezembre', 'Cézembre is a coastal island located in the bay of Saint-Malo (Ille-et-Vilaine, north-east of Brittany). 

Our bistro restaurant is rooted in it.

Located in a small street of the sixth district of Paris between the metro stations Odeon and Mabillon, we offer a cuisine between land and sea based on seasonal products.', '17 rue Gregoire de Tours, 75006 Paris, France ', 'https://www.cezembrerestaurant.com/?utm_source=tripadvisor&utm_medium=referral', '+33 1 42 38 25 08', '_4', '_6th', '10', '1552325063908', '1552498689930'),
('11', 'Bisou Creperie', 'The Darling New Secret Crêperie: The signature : crêpes and pancakes as pimped as Kim Kardashian on the red carpet (this is a compliment, Kim if you follow us)', '62 Passage des Panoramas, 75002 Paris, France', 'http://bisoucreperie.fr', '+33 9 62 50 35 28', '_2', '_2nd', '1', '1552325063909', '1552498728959'),
('12', 'Restaurant Biscotte', 'RESTAURANT BISCOTTE WISHES TO OFFER YOU A Cuisine BASED ON FRESH PRODUCTS, OF QUALITY, OFTEN LOCAL, BIO WHEN POSSIBLE, PRODUCED BY PASSIONATE PRODUCERS.', '22 rue Desnouettes, 75015 Paris, France', 'https://restaurant-biscotte.com', ' +33 1 45 33 22 22', '_2', '_15th', '1', '1552325063909', '1552498771446'),
('13', 'Le Bistrot d''Indochine', 'the bistronomic of Indochina', ' 49 rue de Dantzig, 75015 Paris, France', 'https://www.facebook.com/BistroIndochine/', ' +33 1 45 31 87 27', '_1', '_15th', '15', '1552325063910', '1552498818317'),
('14', 'Le Ruisseau Burger Joint', 'Ruisseau makes you the best burgers. French restaurant specialized in burgers made with fresh and local products. All in a unique homemade bread. Steam burgers are ready to cook. ENJOY YOUR MEAL !', '22 rue Rambuteau, 75003 Paris, France ', 'https://www.facebook.com/leruisseauburgerjoint/', '+33 1 43 70 02 21', '_1', '_3rd', '5', '1552325063910', '1552498872420'),
('15', 'Mancora Cebicheria', 'Máncora Cebicheria also revisits traditional Peruvian dishes, such as octopus with Peruvian olive, anticuchos and causa, in the form of tapas to share.', '16 rue Dupetit Thouars, 75003 Paris, France ', 'https://www.facebook.com/mancoracebiche', '+33 1 43 48 47 65', '_2', '_3rd', '17', '1552325063910', '1552498910871'),
('16', 'Pizzeria Arrivederci', 'Specialized in pizza, we invite you to rediscover our classics such as 4 Formaggi or Calzone and our original creations such as Do Luigi or Nduja.', '47 rue Gay Lussac, 75005 Paris, France', 'https://www.arrivederci-paris.com/', '+33 1 77 32 45 57', '_2', '_5th', '3', '1552325063911', '1552498942246'),
('17', 'Loubnane', 'It was in 1984 that Kamal Nassif, heir to the Ambassador of the Lebanese Gastronomy in France, had the good sense to open Loubnane, continuing the work of his uncle: Rachid Youssef Makhoul, who was the first to try their luck dice 1952 by Chez Rachid, the delights of Lebanon, the only Lebanese restaurant in France.', '29 rue Galande, 75005 Paris, France', 'https://www.loubnane.fr', '+33 1 43 26 70 60', '_2', '_5th', '19', '1552325063911', '1552498984838'),
('18', 'Fromagerie Danard', 'In our cheese aisle we combine the great French classics with our discoveries. We also show foreign cheeses less known in France.', '5 rue du Colonel Driant, 75001 Paris, France', 'http://www.fromagerie-danard.com', '+33 9 72 53 62 92', '_2', '_1st', '13', '1552325063912', '1552499012388'),
('19', 'Le Baron Rouge', 'The Baron Rouge in the elegant and lively 12th arrondissement of Paris provides a friendly welcome and a taste of a "local " Parisian bar. The wines and cheeses are good, and the ambience convivial. My sons in their 20''s recently visited on my recommendation and "loved" the feel of the bar. To quote them "It felt like the real Paris, not a tourist trap." I totally agree with them.', '1 rue Theophile Roussel, 75012 Paris, France ', 'http://lebaronrouge.net', '+33 1 43 43 14 32', '_1', '_12th', '13', '1552325063912', '1552499048390'),
('20', 'She''s cake', 'She''s Cake by Sephora is the spot devoted to cheesecake in Paris, but not just any cheesecake', '20 avenue Ledru Rollin | 12eme Arrondissement, 75012 Paris, France', 'http://www.shescake.fr', '+33 1 53 46 93 16', '_2', '_12th', '20', '1552325063913', '1552499067782'),
('21', 'Aux Merveilleux de Fred', 'These deliciously made meringue pastries literally melt in your mouth!', '29 rue de l Annonciation, 75016 Paris, France ', 'http://www.auxmerveilleux.com/home_en/', '+33 1 45 20 13 82', '_2', '_16th', '20', '1552325063913', '1552499101388'),
('22', 'Comptoir Gourmet', 'Dining bar and delicatessen in the historic district of the Marais in Paris suggesting discovering products of countries come from Italy and from France. The amateurs, the regular customers of the district and the curious find themselves in a friendly and warm atmosphere to taste a selection of delicatessen, cheeses and products specially were selected for their authenticity.', '51 rue du Temple, 75004 Paris, France', 'http://www.comptoirgourmet.com', ' +33 1 84 17 24 07', '_3', '_4th', '3', '1552325063914', '1552499144222'),
('23', 'Reed', 'The perfect bite. ', '11 B rue Amelie | 7th Arrondissement, 75007 Paris, France ', 'http://www.reedrestaurant.com/Reed/Welcome.html', '+33 1 45 55 88 40', '_3', '_7th', '2', '1552325063914', '1552499164917'),
('24', 'Thai Papaya', 'Thai Papaya offers delicioius Thai food prepared to order with fresh ingredients served in a relaxed, friendly atmosphere.', '51 rue des 5 Diamants, 75013 Paris, France ', 'https://www.facebook.com/pages/category/Thai-Restaurant/Thai-Papaya-129910203853336/', '+33 1 45 80 61 38', '_1', '_13th', '6', '1552325063914', '1552499196084'),
('25', 'La Becane A Gaston', 'This place is so hygge, and we''re all about it. With a dark wood interior, rustic accents, brocade wallpaper, and vintage photo frames, this bistro in the 10th arrondissement is the perfect spot for a cozy family Sunday dinner.', '24 rue Lucien Sampaix, 75010 Paris, France ', 'https://labecaneagaston.fr', '+33 9 80 73 22 98', '_1', '_10th', '1', '1552325063915', '1552499224118'),
('26', 'BMK Paris-Bamako', 'Discover all the riches of Africa with BMK Paris-Bamako! Canteen grocery store in Paris', '4 rue de la Fidelite, 75010 Paris, France ', 'https://www.bmkparis.com/', '+33 9 82 54 17 48', '_2', '_10th', '21', '1552325063915', '1552499249202'),
('27', 'Cafe Bolivar', 'Located in the heart of the 19th century, just a stone''s throw from the Halle Secrétan, the Café Bolivar is a pretty café-brasserie neighborhood, with a warm and relaxed atmosphere. The cuisine is homemade thanks to fresh products. In fine weather, the terrace offers a magnificent view. A typical Parisian address!', '31 avenue Secretan, 75019 Paris, France', 'https://cafebolivar.fr', '+33 1 42 00 17 52', '_2', '_19th', '1', '1552325063916', '1552499276911'),
('28', 'Aux Enfants Gates', 'This restaurant makes us ... Spoiled Kids! The interior is adorned with beautiful contemporary hues; on the walls, quotes from great chefs and some recipes give an almost "literary" side to the room.', '4 rue Danville | 75014, 75014 Paris, France ', 'http://www.auxenfantsgates.fr', '+33 1 40 47 56 81', '_2', '_14th', '2', '1552325063916', '1552499292132'),
('29', 'Restaurant Obrigado Paris', 'Brazilian restaurant Paris, Restaurant Obrigado Paris: ceviche, picanha, feijoada, fish and meat grilled with charcoal.', '8 avenue de la Porte de Montreuil, 75020 Paris, France ', 'http://obrigado.paris', '+33 9 84 58 24 21', '_2', '_20th', '22', '1552325063916', '1552499306946');

INSERT INTO "restaurants_components" ("id", "field", "order", "component_type", "component_id", "restaurant_id") VALUES
('65', 'opening_hours', '1', 'components_opening_hours', '65', '1'),
('66', 'opening_hours', '1', 'components_opening_hours', '66', '2'),
('67', 'opening_hours', '2', 'components_opening_hours', '67', '2'),
('68', 'opening_hours', '3', 'components_opening_hours', '68', '2'),
('69', 'opening_hours', '4', 'components_opening_hours', '69', '2'),
('70', 'opening_hours', '1', 'components_opening_hours', '70', '3'),
('71', 'opening_hours', '2', 'components_opening_hours', '71', '3'),
('72', 'opening_hours', '1', 'components_opening_hours', '72', '4'),
('73', 'opening_hours', '2', 'components_opening_hours', '73', '4'),
('74', 'opening_hours', '1', 'components_opening_hours', '74', '6'),
('75', 'opening_hours', '1', 'components_opening_hours', '75', '5'),
('76', 'opening_hours', '1', 'components_opening_hours', '76', '7'),
('77', 'opening_hours', '2', 'components_opening_hours', '77', '7'),
('78', 'opening_hours', '1', 'components_opening_hours', '78', '9'),
('79', 'opening_hours', '2', 'components_opening_hours', '79', '9'),
('80', 'opening_hours', '1', 'components_opening_hours', '80', '8'),
('81', 'opening_hours', '1', 'components_opening_hours', '81', '10'),
('82', 'opening_hours', '2', 'components_opening_hours', '82', '10'),
('83', 'opening_hours', '1', 'components_opening_hours', '83', '12'),
('84', 'opening_hours', '2', 'components_opening_hours', '84', '12'),
('85', 'opening_hours', '3', 'components_opening_hours', '85', '12'),
('86', 'opening_hours', '1', 'components_opening_hours', '86', '11'),
('87', 'opening_hours', '2', 'components_opening_hours', '87', '11'),
('88', 'opening_hours', '1', 'components_opening_hours', '88', '14'),
('89', 'opening_hours', '1', 'components_opening_hours', '89', '13'),
('90', 'opening_hours', '2', 'components_opening_hours', '90', '13'),
('91', 'opening_hours', '3', 'components_opening_hours', '91', '13'),
('92', 'opening_hours', '1', 'components_opening_hours', '92', '16'),
('93', 'opening_hours', '2', 'components_opening_hours', '93', '16'),
('94', 'opening_hours', '1', 'components_opening_hours', '94', '15'),
('95', 'opening_hours', '2', 'components_opening_hours', '95', '15'),
('96', 'opening_hours', '3', 'components_opening_hours', '96', '15'),
('97', 'opening_hours', '4', 'components_opening_hours', '97', '15'),
('98', 'opening_hours', '1', 'components_opening_hours', '98', '18'),
('99', 'opening_hours', '3', 'components_opening_hours', '100', '18'),
('100', 'opening_hours', '2', 'components_opening_hours', '99', '18'),
('101', 'opening_hours', '1', 'components_opening_hours', '101', '17'),
('102', 'opening_hours', '2', 'components_opening_hours', '102', '17'),
('103', 'opening_hours', '3', 'components_opening_hours', '103', '17'),
('104', 'opening_hours', '1', 'components_opening_hours', '104', '20'),
('105', 'opening_hours', '1', 'components_opening_hours', '105', '19'),
('106', 'opening_hours', '2', 'components_opening_hours', '106', '19'),
('107', 'opening_hours', '3', 'components_opening_hours', '107', '19'),
('108', 'opening_hours', '4', 'components_opening_hours', '108', '19'),
('109', 'opening_hours', '1', 'components_opening_hours', '109', '22'),
('110', 'opening_hours', '2', 'components_opening_hours', '110', '22'),
('111', 'opening_hours', '3', 'components_opening_hours', '111', '22'),
('112', 'opening_hours', '4', 'components_opening_hours', '112', '22'),
('113', 'opening_hours', '1', 'components_opening_hours', '113', '21'),
('114', 'opening_hours', '2', 'components_opening_hours', '114', '21'),
('115', 'opening_hours', '2', 'components_opening_hours', '115', '24'),
('116', 'opening_hours', '1', 'components_opening_hours', '116', '24'),
('117', 'opening_hours', '3', 'components_opening_hours', '117', '24'),
('118', 'opening_hours', '1', 'components_opening_hours', '118', '23'),
('119', 'opening_hours', '1', 'components_opening_hours', '119', '26'),
('120', 'opening_hours', '2', 'components_opening_hours', '120', '26'),
('121', 'opening_hours', '1', 'components_opening_hours', '121', '25'),
('122', 'opening_hours', '2', 'components_opening_hours', '122', '25'),
('123', 'opening_hours', '3', 'components_opening_hours', '123', '25'),
('124', 'opening_hours', '1', 'components_opening_hours', '124', '28'),
('125', 'opening_hours', '1', 'components_opening_hours', '125', '27'),
('126', 'opening_hours', '3', 'components_opening_hours', '127', '27'),
('127', 'opening_hours', '2', 'components_opening_hours', '126', '27'),
('128', 'opening_hours', '1', 'components_opening_hours', '128', '29');

INSERT INTO "reviews" ("id", "content", "note", "author", "restaurant", "created_at", "updated_at") VALUES
('1', 'Formidable!
A fantastic restaurant. Service was outstanding and food delicious. The staff of this restaurant are at the top of their game. The pollock fish dish was exceptionally good. If only more restaurants are as focused on customer satisfaction to the extent that this one is. Well done ASPIC!', '5', '2', '1', '1552396507734', '1552406848205'),
('2', 'Exceptional experience
The chef Quentin, prepared us a wonderful diner. Very refind palet of tastes on the various beautiful served courses. The choclate desert was beyond expectation. 
Service very friendly and helpfull. It would not suprise me when Aspic gets a star in the very near future.
Vaut le détour!!', '5', '3', '1', '1552396554565', '1552406851842'),
('3', 'Paris fine dining at its best
The service, food, and intimate setting was everything you would wish for in a premier restaurant in Paris. Each dish was unique and of top quality in both ingredients and preparation. The wine pairing was excellent and the server was fun, pleasantly informal, but extremely knowledgeable and vigilant.', '5', '4', '1', '1552396572912', '1552406855846'),
('4', 'Lovely evening
Me and my wife visited the restaurant after reading all the reviews on here and had a truly exceptional evening. We were made to feel very relaxed from the start and a pleasant atmosphere remained throughout. Every course worked well and I thought the wine accompanied it perfectly. We both left satisfied and full.

Due to my wife being pregnant the chef ensured all of her dishes were slightly more well done (although it must of hurt him inside having to overcook the duck )', '5', '5', '1', '1552396598685', '1552406860381'),
('5', 'Elegant in all ways
ASPIC was the main fake fancy dinner that we had planned for our Paris trip, we left it for the very last night, and were eagerly anticipating the multiple course tasting menu!The restaurant did not disappoint, most impressive was the elegant service, breathtaking all around experience.', '5', '6', '1', '1552396617420', '1552407191844'),
('6', 'Delicious restaurant in Montmartre.
The ambiance was pleasant and the food was spectacular! The Asian-French combination was perfection.', '5', '7', '2', '1552396826552', '1552407198092'),
('7', 'Interesting experience
Went for dinner here on the back of previous TA reviews; the food is certainly unique but I''m not sure all the flavour combinations we had worked. I did particularly enjoy the rabbit broth and oysters with pork belly. Service was friendly but the dining room itself felt a touch drafty and austere. Definitely worth trying for the experience of Korean/French fusion food, though I''m not sure I would return.', '4', '8', '2', '1552396864574', '1552407360739'),
('8', 'Anniversary dinner
This little quiet place in the district of Montmartre will astonish you. Victor meets you at the door to his and his wife’s establishment with a smile and an exceptional knowledge of French and Korean cuisine. His engaging personality brings your dinner experience to a new level. And the food.... fantastic flavors meet in this fusion kitchen. You will find your tastebuds experience new and very nice combinations. This is a must try when in Paris!', '5', '9', '2', '1552396902601', '1552407370602'),
('9', 'Just amazing
What a fantastic place! The warm welcome followed by the most amazing food. Started with carpaccio with fabulous tastes. Such a journey with flavors. 
Had the most fantastic cod and the an apple dessert with a white ipa beer which was just great. 
I will definitely come back and I truly recommend this place.', '5', '10', '2', '1552396918232', '1552407380816'),
('10', 'Last evening dinner in Paris
Kind of Korean-French fusion cuisine, chefs are all Koreans with an English speaking guy who helped to explain / recommend the dishes to us. Limited choices, it’s just very different and unique.', '3', '11', '2', '1552396936217', '1552407395671'),
('11', 'Weekend trip to Paris / excellent Dinner
We started our weekend in Paris with a great dinner in Can Algeria Paris. We ordered 3 different main courses- very delicious. And the services had been obliging.', '5', '12', '3', '1552397101425', '1552407408011'),
('12', 'World class experience!
World class experience..food is amazing can t wait to go back there.i don t like entrecote cause generaly this piece of beef is full of fat but the CAN ALEGRIA one is fantastic great staff.. 50 m from one of the famous club of Paris Le rouge wonderful night !!!', '5', '13', '3', '1552397114760', '1552407415028'),
('13', 'Great, but noisy!!
We had a very nice dinner - the service was great, the food was colorful and tasteful. The best thing are the combinations of the ingredients. The negative side was that it was sooooo loud and crowded - very little space in between the tables and too many people for the space and the bathrooms.', '4', '14', '3', '1552397129020', '1552407423852'),
('14', 'Cosy and simple with good food
I went here with some friends and we shared a bottle of red some starters and the Octopus as main dish. The ambient is warm and cosy yet simple. Food was pretty and tasty just a little expensive referring to the portions. Service was very kind but very slow.', '4', '15', '3', '1552397147787', '1552407542192'),
('15', 'Ok
Nice decor. Fairly cold temperature in the restaurant. 

Menu is limited with only 5 or so mains. Only one option for vegetarian main.

Had the cauliflower as a starter- quite bland - only a minimal amount of sauce.

There was a miscellaneous chunk of meat in the quinoa in the fish dish. 

Fairly pricey for the quality of food.

Staff were friendly enough.', '3', '16', '3', '1552397164797', '1552407549498'),
('16', 'So worth a trip on le Calife
My sister and I enjoyed a wonderful evening on le Calife. The food and cocktails were absolutely delicious. All the staff were very attentive.
The highlight was passing the Eiffel Tower and seeing it light up. It was a lovely way to spend our last night. I would highly recommend going on trip.', '5', '21', '4', '1552397361833', '1552408136069'),
('17', 'Extraordinary ♥️♥️
A splendid experience,cruising down The Seine is the most romantic thing you can ever do in Paris.

And Le Calife is the best boat option.
With the cozy oriental interiors the romantic atmosphere and the very friendly staff enjoy you trip.the best idea for proposing ♥️, specially when you pick the right time when the boat is next to the Eiffel Tower at 10 pm while it’s bluffing it’s light

Tha food is either three meals course or five meals course , 
Guys the food is Super
A REALLY WOUNDERFUL EXPERIENCE ♥️♥️', '5', '18', '4', '1552397385314', '1552407563180'),
('18', 'Brilliant
What a wonderful evening - lovely food (guinea fowl was delicious), attentive, friendly, efficient staff. Would certainly recommend this trip, saw all the sites. Lovely atmosphere onboard and nice and warm on a cold evening.', '5', '19', '4', '1552397410935', '1552407571050'),
('19', 'Lovely experience for a special occasion
After researching the absolute best river cruise with dinner, it seems unanimous that this was the best.

The service was lovely, the wine was tasty and the food was quite good to say it was cooked in a small kitchen on a boat. The only issue being the sauce with the steak needed to be sent back as it was cold.

This is a must do if you''re here for a special occasion as they send the desert out with a little sparkler.', '5', '20', '4', '1552397426843', '1552407582524'),
('20', 'Fell at the First Hurdle...
I would love to be commenting on the gastronomic delights which this experience claims to offer, but after trying twice to follow up on my booking via the phone (to pay the deposit) and only getting an answer machine, I gave up. 
I left my details but never got any response - despite my calls being well within the ''office hours'' mentioned on the recording.
There are plenty of other options out there - alternatives are worth considering.', '1', '21', '4', '1552397488963', '1552407593240'),
('21', 'Underwhelmed
It’s a classic case of style of substance. The food was ok, the service was good, the knowledge of the server was good, but you get a feeling that your paying for the boogie environment then quality food.', '3', '22', '6', '1552397950136', '1552407623028'),
('22', 'Unacceptable standard for a Japanese restaurant
Was over in Paris this week for my Europe tour and decided to check out Guilo Guilo after seeing all the largely positive reviews online. It was a cosy little place and it was nice to be greeted by a friendly mix of French & Japanese crew. English speaking crew are always a plus here in Paris.

They serve a secret Chef''s menu or most call it the Omakase set that cost €55, which is incredibly overpriced if you''d ask me, but allow me get to that. First dish that came was a tiny glutinous rice dish that had Roasted Eel (Unagi) on it. I literally choked on it as the fine bones were stuck at the back of my throat. It''s not my first time having Unagi, having eaten across the region and several times in some of Japan''s finest establishments.

Unagi bones are usually soft and edible, but this one I had was really tough and it got stuck and caused much pain and discomfort to me. When I informed the crew and chef, all they did was to get some sushi rice to get me to swallow, in the hole that it would help force the bone down my throat. I appreciate that gesture, I really do. And the crew apologised that the Unagi was all frozen during this season of time and they probably didn''t do a thorough check on it.

So let''s be very clear here. It is absolutely unacceptable for a Japanese restaurant or chef to present a dish that is of this standard to any guest. Known for their highest standards in culinary, you wouldn''t expect anything like this. I was actually quite mad how the Japanese Chef just brushed the issue off very easily. It''s not a small issue. That is not the Japanese way, so please do not tell me this is the norm. It''s NOT. What a shame, and we only just started the evening with the bone stuck in my throat. Just horrible.

And as much as I''d like to be objective, some of the other dishes throughout the night was okay and some below average. It was really mediocre. It seem as though the chef tried to be adventurous in his creations just for the sake of being adventurous. 

Overall, I wanna sum up this restaurant isn''t awful when it comes to the taste department. But for the amount of money I dished out, I was expecting a lot more. Top up a little to the €55 and you could easily get a great experience at a Michelin Starred meal in Tokyo. 

I won''t recommend anyone who''s well travelled or foodie to come here that''s for sure. You can''t be great when the fundamentals are not done right. Much to learn from the real Japanese Takumi craftsmanship of food making.

Best,
Eric', '1', '23', '6', '1552398166857', '1552407631788'),
('23', 'Absolutely fabulous
My wife and I came here with a friend on a lovely summer Parisian evening. The restaurant is very cosy and the seating is bar-style around the central cooking area. The food was freshly prepared and of excellent quality. The fixed menu was full of fabulously prepared dishes full of wonderful flavours and odours. Each dish was marvelously explained in detail by the passionate waiter, and each one was beautifully arranged, almost a work of art. The menu isn''t cheap but is worth every cent. We will come back again soon.', '5', '24', '6', '1552398189118', '1552407641631'),
('24', 'Absolutely brilliant
We had a fantastic night at this wonderful gem of a place. The staff was amazing, the great chef himself was there interacting with everyone, the food was exceptional, we made friends with some of the other diners, and by the end of it all, we were happy to pay the somewhat expensive bill as it wasn''t just a meal, the whole thing was an incredible experience in itself.', '5', '25', '6', '1552398226954', '1552407651152'),
('25', 'Extremely overated
The food is not bad, it is just average. The price on the other hand is quite exceptional. As usual in paris the risk is to end up paying more for the concept than for the talent.', '1', '26', '6', '1552398249124', '1552407664600'),
('26', 'Noise level like a techno club
Beautiful, cozy and elegant restaurant, good food, not cheap but normal process for an elegant Parisian restaurant. Upscale, local crowd, no tourists.
The restaurant accommodates approximately 60 people. When we were there a big group of about 30 people was celebrating a birthday. You couldnt understand your own word even before the music started. When at some point some more or less talented piano player started singing and playing French evergreens the entire group started to sing along and to dance on the tables.
Which is actually all great and pretty fun if that is what you are looking for.
However, if you go there with your girl friend to have a romantic dinner and perhaps a conversation you are screwed.
When we asked the maitre why they didnt tell us when we made the reservation that there was going to be such a party he told us that they have this kind of atmosphere every night.', '2', '28', '5', '1552398403727', '1552407675289'),
('27', 'Trendy place
Great place to go when you want to eat and listen to a live band music . The food is average but the mood makes the difference . Hard to get a table in weekends . The bar downstairs is very nice for a drink', '4', '29', '5', '1552398450370', '1552407686428'),
('28', 'Good live music, French oldies mix and contemporary hits
Limited food choices but good quality, attentive and smiling service and above all a fun vibe with live music and trendy young crowd. An overall good time.', '4', '30', '5', '1552398461772', '1552407694824'),
('29', 'Hidden gem
This place is definitely hidden gem of Paris. Amazing service and food that you can try in Paris. You won''t be sorry for dining in this place for sure. I can''t wait to come back here.', '5', '31', '7', '1552398618608', '1552407704013'),
('30', 'Wonderful
Don''t expect a fancy place! This gem is tucked away from the main tourist area. Everything was incredible..food, wine and service! Definitely returning on our next visit!!', '5', '32', '7', '1552398641672', '1552407713981'),
('31', 'Lovely dinner
We chose the fried mozzarella & crab cakes to start, both of which were lovely & crispy having been freshly prepared. Then we opted for the chicken kiev & steak. The steak was alright but the cut was a bit more gristly than expected, however the chicken was gorgeous, it was crispy & moist inside. They also happily accommodated my request to have the blue cheese sauce on the side! Dessert was the chocolate fondant which oozed with a gorgeous gooey centre, am amazing dessert!

The service was personal & all questions happily answered. The restaurant is cozy but it is Parisian after all!', '5', '33', '7', '1552398736389', '1552407724647'),
('32', 'Great restaurant
Not only the food was nice but the service was quick and friendly. For the quality of food and the environment, the price was very low. I wholeheartedly recommend this restaurant.', '5', '34', '7', '1552398753364', '1552407733008'),
('33', 'Great experience
Brilliant, gorgeous, whimsical, delicious. We plan a meal here. Food, service, ambiance — everything is perfect. Unmatched. And unforgettable.', '5', '35', '7', '1552398769338', '1552407746907'),
('34', 'Don''t do it!
39 out of 20,231 restaurants in Paris???

I thought we had problems with Brexit!! 

Greasy onion ring served as a bhaji - a samosa soaked in old oil - and keep your starter plate for mains?

Dull - low quality food at a price that should deliver more! 

Such a disappointment!!!', '2', '36', '9', '1552399188166', '1552407757718'),
('35', 'Best service in Paris
Me and my partner visited as part of a short city break. On the trip advisor reviews we decided to visit here on our final night. We were greeted by a friendly and welcoming man who wanted to ensure we had the best meal, which we did! The food was amazing and made so much better by the attentive service. We even ordered two extra naans to take away as the food was so delicious! Would 100% recommend for both food and excellent service!', '5', '37', '9', '1552399207383', '1552407774952'),
('36', 'A wonderful surprise
How wonderful to find freshly made flavoursome Indian food. A warm welcome awaited us on our first visit and we shall be back soon.', '5', '38', '9', '1552399223372', '1552407803608'),
('37', 'Excellent and well priced
Went for on a saturday nigbt and the restaurant was full by 9pm.
Small place and not fancy in terms of decor or atmosphere, with only 1 person taking care of all the tables.
The service was good and friendly, and everything we ordered was delicious (onion bhajas, eggplant pakora, butter chicken, tikka masala chicken, cheese naan and kashmir rice), the bill came in at 69 euros.
Will definitely come back.', '5', '39', '9', '1552399240069', '1552407816380'),
('38', 'Amazing food and service
My boyfriend and I went to this restaurant this evening and it was absolutely amazing. We took a 25euro menu that included starter, main and dessert. The food was absolutely delicious! The waiter was really, really nice and made sure we had everything we needed. I would give 6 stars if I could!', '5', '40', '9', '1552399256806', '1552407824518'),
('39', 'Cozy space, decent staff, good food
Cézembre occupies a small, unassuming space in a small, nondescript street. It seems to be fully booked—or nearly—on most days. We, like many others, couldn’t get in as walk-ins but were able to reserve a table for dinner a couple of days later, 

There’s nothing lavish about the space, but it does offer an air of neighborhood coziness. Everyone seems fairly relaxed, and there is a mix of clientele. Not surprisingly, there are many foreigners, but on the day we were there, there were definitely some French voices as well. 

The details of the menu and service are described in numerous other posts, so I’ll just comment on the food. On the day we were there, we found most of the dishes to be quite rich. This is not to say that the flavors were bad or the execution poor, but the foie gras, cream and butter eventually took their toll and three of the four of us were feeling very full by the time the main course came around. 

We don’t mind rich food on occasion, and it’s quife possible that the richness varies in accordance with the raw ingredients. It was a bit too much this time, but we’d really have to come back and try it again to see if it was just a one-off.', '4', '41', '10', '1552399364607', '1552407833444'),
('40', 'Gorgeous food, great service and ambiance. Loved this.
We thoroughly enjoyed a fantastic 5 course dinner at Cézembre.

The welcome was friendly and the service attentive. Each dish in the five course menu was outstanding in quality, taste combinations and presentation. Textures were cleverly combined and the price was reasonable. This is an outstanding small restaurant. It was very romantic too.', '5', '42', '10', '1552399386292', '1552407845058'),
('41', 'Worth the hype
Not much to say, other than strongly recommend that you give this place a try - you will not regret it! This was a truly terrific all-around experience; from the service, to the atmosphere, and, of course, the food! As noted elsewhere, they only offer a 6-course menu for 65 euros that delivers a spectacular experience at a fraction of the price of what you would pay at a similar (yet inevitably inferior) place in the states. The portions, though obviously small, were extremely high quality and were more than sufficient to leave you super full yet satisfied.The staff were also incredibly courteous and were happy to accommodate my fiancé, who is a vegetarian- she highly approves of her meal as well! They also paid attention to the little details, like warming our jackets so that we wouldn’t be cold when we left. Highly recommended!', '5', '43', '10', '1552399402453', '1552407862878'),
('42', 'An absolute winner - and a great value
Lunch, and I believe dinner, changes daily (or close to it) and it’s fixed-menu - at a very reasonable price. 

I had lunch. The appetizer was a stunning langoustine in a Granny Smith curried apple sauce and foam. Simply delicious and perfectly cooked (i.e. not overcooked). The main course was a marinated quail in wine reduction with chestnuts, mushrooms and delightful little vegetables. The portion was generous but still sensible. The wine pairings were spot-on and reasonably priced.

The chef appears to work alone in the tiny kitchen. While the restaurant is quite small (maybe 30 seats) it was full, and the dishes came out at a very reasonable pace. There were two male waitstaff who were informative, friendly, professional and explained things in French or English depending of the guest’s preference.

Given that the chef appears to work solo (though he may have prepping help I did not see) the fixed menu is probably his only option. This was certainly no problem for me the day I was there - I loved all the choices. That may not be true every day for everyone, so calling beforehand to hear what’s on the menu might be advisable. I had no choice, given a short stay in Paris, and don’t mind surprises anyway. I think this creative chef can make almost anything work unless you have an allergy or deep distaste for some ingredient.

This is an unqualified 5 in my book and I will be back.', '5', '44', '10', '1552399416733', '1552407878062'),
('43', 'Super nice food & friendly staff !! Would definitely go back when in Paris.
We were not sure if we could enter the restaurant with our pram. But the staff ensured us that they would make it possible for us to have a table where we could put the pram next to.
As we arrived in the restaurant, we had a nice table close to the kitchen where the pram could stand next to.
The food (a 5 course menu) was delicious ! The portions were quite large and the price (59 EUR) was very good for this menu. 
The waiter made sure the wines matched the meals.

We definitely recommend this restaurant !', '5', '45', '10', '1552399431224', '1552407893049'),
('44', 'Very tasty and good price
during a recent visit we wanted to try a crepe and trip advisor review led us here. we were very pleased with our choice as the food and drinks were both very good and reasonably priced. I had the steak crepe and my fiancé the chicken one. highly recommend for a lunch trip if you are looking for a crepe', '5', '46', '11', '1552399518903', '1552407901565'),
('45', 'best crepes ever!
i have been in Paris many times, but I ve never eat some crepes like those!!! just magnifique!good service and funny guys!', '5', '47', '11', '1552399537808', '1552407911974'),
('46', 'Great crepes in a fantastic location
We were recommended to visit the Passage des Panoramas by our hotel receptionist, when looking for a light-bite nearby. It’s such a beautiful arcade, jam-packed with lovely looking restaurants and bars. We had a lovely, casual meal in this Creperie. The food is yummy, the service is quick and polite, and the staff don’t mind you trying to practice your terrible French on them!', '4', '12', '11', '1552399551383', '1552407981145'),
('47', 'Crêpes in Paris
The menu offers several alternatives, including vegetarian crepes. We tried Popeye Power and Chiquita, then Cookie’n’crime for dessert. Ingredients and dough were good, but we preferred the sweet one. A bit pricey.', '4', '3', '11', '1552399574718', '1552407963866'),
('48', 'Great crepes. Great service.
We came here for lunch and the service was excellent. I had the Chiquita and my wife had the Marius and Fanny (giggle). Both were so good we decided to have a sweet crepe to finish. We highly recommend the Madagascan vanilla ice cream with it.', '5', '48', '11', '1552399610303', '1552407927518'),
('49', 'Outstanding restaurant with a perfect food
Of course my visit in this place was due to high place in TripAdvisor ranking! After having a dinner there with my friends I can easily recommend this place for everyone looking something special! 3 course menu was exceptional- portions were tiny but after eating everything it was slightly enough!!! Go and try', '5', '49', '12', '1552399750877', '1552407937176'),
('50', 'Fabulous food
My wife and I ate here the night after an incredible feast at Le Grand Vefour. The quality and preparation of the food both nights was perfect. Wonderful cuts of meat, moist, tender, perfectly cooked and presented. Here the kitchen was open and it was a joy to see the staff working together with an obvious joy and pride that was evident in every course!

It is a small and exceptional restaurant, so make reservations early.', '5', '50', '12', '1552399765020', '1552407944766'),
('51', 'Magnificent
I popped in for lunch after reading the reviews on “trip advisor “
And was I impressed, small ,beautiful & as chic as Paris can be 
The food is outstanding and as many other reviews point out 
You have to visit this place as you will be so pleased you have 
The risotto with truffles is perfect 
And the service is quick and efficient 
I sat and watched the chefs preparing the dishes gracefully and with ease ', '5', '51', '12', '1552399779722', '1552408215212'),
('52', 'Don’t leave Paris before trying this novel French dining!!!
We loved every minute of our Saturday brunch but we hadn’t reserved so we had to wait for the crowds to leave! This young dynamic couple will marvel your palate! Pauline excels at French baking and Maximillien creates the fresh seasonal savouries!!
They are published every week in a different magazine!!!!
My only regret at leaving Paris is that I will miss next week', '5', '52', '12', '1552399793649', '1552408230123'),
('53', 'Great view from the bar
We took advantage of it being quieter in the summer holidays to walk in on a Friday evening - Biscotte is usually full so it pays to book! Offered a seat up at the bar so could watch the kitchen at work and the dessert chef poach apricots and lay out desserts. A great view from the bar it gas to be said.

The menu has a good set of choices. Similarly, the wine list which is reasonably priced. Euro 36.00 is a good dinner deal for entre, main and dessert. 

Try it out. ..but be sure to book in advance!', '4', '53', '12', '1552399813140', '1552408241267'),
('54', 'Awesome discovery
Two friends invited us at this restaurant, we had a very good time and the foods are fantastic. Everything is homemade and there is no doubt as it is so delicious.
From the outside you may not enter but simply push the door and you will have a great experience.', '5', '54', '13', '1552400315867', '1552408253269'),
('55', 'Love it
Very nice Vietnamese restaurant in Paris. The food is delicious, fresh, good service staff. Price is quite expensive.', '5', '55', '13', '1552400329424', '1552408263380'),
('56', 'Best Vietnamese Food
I had one of the best Vietnamese meals ever at L’Bistrot d’Indochine. (I am from California where there is a sizable number of Vietnamese restaurants.). The friend rice noodle was simply heavenly. The service was very friendly, one of the best I have encountered in a Parisian restaurant. The price was very reasonable too.', '5', '56', '13', '1552400341666', '1552408277889'),
('57', 'Very Good Vietnamese Food in Paris
We were a group of five for dinner. Not sure a reservation is required, but we had made one and were promptly seated upon arrival. The owner was very friendly and made good recommendations. Menus in English are available. Food was authentic and delicious. We tried a variety of appetizers and mains. Recommend the Mi xao gion, the chicken a la citronelle and the duck.', '5', '57', '13', '1552400354823', '1552408295668'),
('58', 'December Holidays
Visited this place before Christmas with my family. The food is good but quite expensive for what kind of customer service you get. We might think if we recommend it to others.', '4', '58', '13', '1552400379915', '1552408321250'),
('59', 'Nothing Special
I went for a burger based on the reviews, however; there is absolutely nothing special about their burger. It was almost tasteless. I would not go back there again', '2', '59', '14', '1552400479588', '1552408331791'),
('60', 'Well Priced, Quick Service
13 EUR for a burger and chips and another 3 EUR for a beer - you can''t go far wrong with that!

This is not somewhere where you''d go for quite chat or a private moment... it''s quite the opposite. With everybody sitting cheek by jowl, you need to keep your elbows in lest you poke someones eye out!

Service is brisk and the turnover of patrons equally so, and that''s the business model. But if you''re looking for a quick burger and are not hung up on the ''dining'' experience, then the Burger Joint is certainly well worth the visit.', '5', '59', '14', '1552400493877', '1552408342211'),
('61', 'Delicious!
We all ate hearty burgers - perfect and filling! They have a €13 menu which comes with a burger, drink and choice of salad or fries, and I would recommend the fries! There are plenty of burgers to choose from and they are all delicious.', '4', '61', '14', '1552400509148', '1552408354948'),
('62', 'Holy crap, this is the European “Fergburger”
Besides New Zealand’s “Fergburger” this is the best burger I’ve ever had. Best burger in Europe. I had the blue cheese and BBQ burgers and they both were amazing. The French fries were outstanding and it came with spicy sauce reminiscent of America “fry sauce”.', '5', '62', '14', '1552400531440', '1552408363887'),
('63', 'Top-notch
I went there on Jan 1st with two friends of mine. We were in Paris on vacation and we were having trouble finding a place where we could have a nice lunch on New Year’s Day, then we found this little heaven thanks to TripAdvisor. 
Although it’s quite small and there were a lot of people waiting for food (no empty tables and a lot of deliveries to be made), it took us half an hour - more or less - to get a table and the time we waited was totally worth it.
The food was great and they have many choices (I’m vegetarian and for once I had the chance to eat an amazing veggie burger - you can order any burger on the menu and then ask to replace the beef with the veggie steak, which is excellent). 
In fact, it was so good we decided to come back two days later for our last meal before leaving Paris and, yet again, we absolutely enjoyed the burgers.
Last but not least, I loved the fact that this place is really eco friendly: I saw no plastic at all (they gave us paper straws and paper cups) and they use very little paper to serve their meals, so that’s definitely a plus for me.
Totally recommend!', '5', '63', '14', '1552400546206', '1552408379126'),
('64', 'Best surprise Paris had to offer
I''ve got to admit that I never heard about ceviche before visiting this place. But what a nice experience it has been. Great and original fresh food. Good quality for reasonable price and nice atmosphere with mostly young local people. Definitely coming back again.

PS: thanks for the rolled cigarette. You know who you are;)', '5', '64', '15', '1552400631691', '1552408389390'),
('65', 'Perfect
We came back here because the first time we fell in love! The place is super nice, in the summer you can eat outside and it’s super cute! 
The dishes are all delicious and the drinks too! Try the “panna cotta with maracuja” it’s the best dessert!
We’ll definitely come back again!', '5', '65', '15', '1552400764544', '1552408399996'),
('66', 'Great ceviche
The ceviche was very tasty. Also the location and the place are great. It was nice to have lunch there outside.', '5', '66', '15', '1552400803599', '1552408408007'),
('67', 'bland
Looks great in photos but found the flavours repetitive and flat. nothing special as nothing had that punch I was looking for. The portions are quite big too, so you can''t order a variety when you''re just 2 people...', '3', '67', '15', '1552400867288', '1552408421891'),
('68', 'Nice Ceviche
Nice outside lunch with a friend. The quinoa salad was very tasty and the ceviche fresh... i visited Peru last summer so it doesn’t quite compare but the food was fresh and tasty... it was just missing a little oomph. Service was spot on. Good coffee. I would go again.', '5', '68', '15', '1552400886507', '1552408440828'),
('69', 'Taste of Italy in Paris
Such a great venue. The pizzas were absolutely delicious and service fantastic. I definitely recommend this venue if you looking for proper clay oven baked Italian pizzas.', '5', '69', '16', '1552401925603', '1552408461576'),
('70', 'Amazing little pizza place
We were wandering around St. Germain in the afternoon... decided to book a higher ranked casual place for dinner. Came across this one at #103 among 15000+, so decided to book it despite the slightly off location. 

The place was still packed at 8:30, the food was amazing, nothing fancy but everything was simple but done right. The dough of the pizza, the meat sauce in the bolognese and their house-recipe tiramisu... there is simply nothing not to like. 

Add in the attentive services and the huge portions... oh and the complementary limoncello... I will be thinking about this place when I want Italian. ', '5', '70', '16', '1552401940328', '1552408472174'),
('71', 'Delicious!
The food was excellent and atmosphere cozy. You can’t ask for more. The owner (at least we thought he was the owner) took very good care for us. We recommend warmly.', '5', '70', '16', '1552401958516', '1552408481002'),
('72', 'Excellent pizza and great atmosphere
Very easy to make a reservation on Trip Advisor for dinner. The restaurant filled up and I can understand why. Excellent pizza and service. We will visit again next time we are in Paris.', '4', '71', '16', '1552401971036', '1552408492068'),
('73', 'Outstanding pizzeria
Thank goodness we found this little pizzeria close to our hotel. We managed to get a table without booking at 19.30 but later than that it was fully booked. Excellent pizza, wine and tiramisu and the best cappuccino I’ve had in Paris.', '5', '72', '16', '1552401982941', '1552408508947'),
('74', 'Cosy nice place
Lovely Lebanese restaurant . The food is so tasty .waiters are friendly and they have a wide variety of Lebanese wine. We have tried a Pinot Noir from Chateau St Thomas and it was perfect with the Lebanese dishes . Give it a try ! Cheers', '5', '73', '17', '1552402093475', '1552408527707'),
('75', 'Great dinner, great service
Excelent dishes in a good atmosphere, short waiting time for food, fear prize and good location. Always fun to have surprise dishes.', '4', '75', '17', '1552402106160', '1552408543334'),
('76', 'Very delicious and splendid service
We had the luck of finding this place in a side street of a touristic area and were truly amazed by the reception and the delicious food which was recommended by the staff. This place deserves more than the full score!!', '5', '76', '17', '1552402118598', '1552408555513'),
('77', 'Great hosts servicing authentic Lebanese dishes
The restaurant requires reservations though it’s open quite late. We stopped in without reservations on a Saturday night in January and the small main dining room, which seats about 40 when full, was packed. There is no waiting area for a table. We popped in to confirm they were full and maybe to get a recommendation for another restaurant. They were so accommodating and nice upon hearing out American accents. The owner invites us to stay saying they would probably have a free table a bit later - in 10 minutes we were seated. The mean was fantastic and service better.', '5', '76', '17', '1552402131832', '1552408568235'),
('78', 'Very good Lebanese cuisine
The flavors of each dish here are distinctive and delicious. The staff is eager to help you choose from the full menu of Lebanese specialties. Portions are generous and everything was really good.

', '4', '77', '17', '1552402146089', '1552408578288'),
('79', 'Great experience.
We knew going to Paris we needed to do a cheese tasting. We went in not knowing anything about cheese or what kinds we liked. They asked what types of cheese we liked & if we we''re willing to try anything a little different. We ended up with about 6 different cheeses which we we''re told a little history of each, some meats & some bread. The experience was fantastic. If we ever end up in Paris again this is a stop we will make again.', '5', '78', '18', '1552402346289', '1552408767208'),
('80', 'Tasty
Actually I was going to buy some cheese and was looking for "Fromagerie". And bumped into this semi-shop semi-restaurant. They have cheese, wine, charcuterie. Thats all. But I found quality is good. The shop owner talks that mostly all the cheese is from small farms and I believe it''s true. Anyway everything I bought there were really tasty (roquefort, young goat cheese and one piece of strange-looking green cheese).', '5', '79', '18', '1552402358183', '1552408783100'),
('81', 'Wine & cheese on a rainy day in Paris
Visited here whilst away for our anniversary. We opted for the Tour De France paired with a wine recommendation from one of the helpful members of staff. His recommendations were excellent and the wine was also good. Overall, a great selection of cheese, and wines.', '4', '33', '18', '1552402374657', '1552408955751'),
('82', 'More then good!!
This is my second time, my visit to Fromagerie Danard. It was really good again :) they know a lot about cheese , it’s nice to let them choosing for you! Then you taste something new!
And they service they always good and friendly! Thank you again and see you next year. Greets Yordi Bon', '5', '80', '18', '1552402389912', '1552408969864'),
('83', 'Absolutely awesome
Fantastic cheese shop with a few tables available to book for lunch. Great spot just off the beaten track. We ordered the mixed meat and cheese selection after being asked what we liked and were delighted with the food especially the truffle cheese. Great bottle of wine left to the owners discretion to choose. Really friendly staff. Best food experience of our long weekend in Paris.', '5', '81', '18', '1552402411003', '1552409098664'),
('84', 'Le Baron Rouge Bar
The Baron Rouge in the elegant and lively 12th arrondissement of Paris provides a friendly welcome and a taste of a "local " Parisian bar. The wines and cheeses are good, and the ambience convivial. My sons in their 20''s recently visited on my recommendation and "loved" the feel of the bar. To quote them "It felt like the real Paris, not a tourist trap." I totally agree with them.', '5', '82', '19', '1552402563097', '1552409134858'),
('85', 'Pleasant wine bar away from the bustle
I was able to pay a visit to Le Baron Rouge last week. It was a bit further away from any other places I had been to. Perhaps that is part of the draw because there really were not many tourists around except for yours truly.

I got there just after they opened at 5 pm. I sat at a small table and looked over the wine menus on the wall. Having settled on a red I was good to go and placed my drink order with the bartender. He spoke English and was friendly.

Everyone else that made their way in seemed to be locals coming to talk story over a glass of wine and for some small glasses of beer. It was very laid back and relaxed. I did not see anyone order any food nor was anyone present with oysters. I suppose that I struck out there as I was looking forward to some.

I enjoyed 3 glasses of wine and then ventured on. The wines to be found here are pretty extensive. A cozy little bar to enjoy some lovely drinks without feeling that you are in a tourist trap. If that''s your type of thing then you would enjoy this place.', '5', '83', '19', '1552402576556', '1552409178327'),
('86', 'Fresh oysters and good wine
affordable place: we had 2 dozen oysters and 4 glasses of good wine, payed less than 50€. We came around 5pm. Nice local atmosphere - We liked it a lot.', '5', '84', '19', '1552402590841', '1552409561827'),
('87', 'A Very Favorite Wine Bar
When we are in Paris we “”always””stop here for snacks, for its great atmosphere, for the very wide variety of choices of wine and to participate in a very old tradition in this section of Paris.. it is so wonderfully casual that we feel right at home immediately when we enter.. very friendly atmosphere... an absolute must... worth a metro trip...', '4', '85', '19', '1552402607162', '1552409572507'),
('88', 'Great local wine bar with amazing prices
While walking the neighborhood we stopped for few glasses of wine in this lovely small French wine bar. As we couldn''t decide what to choose friendly waiter recommended us some wine that we really liked and after few glasses we went home with two bottles of natural wine. Atmosphere was really great and friendly, customers were mostly French and you can really enjoy the experience of local life far from tourist traps and attractions. Prices are really good, you can enjoy good quality wine for more than acceptable price.', '5', '86', '19', '1552402619487', '1552409631399'),
('89', 'Dessert in Paris!
What is there to say? Do you enjoy cheesecake? If you do, this is a must! If you don’t, then you need to try it and change your mind ASAP! Owner is amazing and very helpful! We had 6 choices and chose cafe and regular with raspberry and blueberry! The definition of delicious! Not too big, perfect to share with your significant other and family! Highly highly recommend!', '5', '87', '20', '1552402717970', '1552409645945'),
('90', 'Paris visit in February. She''s Cake
She''s Cake is a truly fantastic not only because of their gastronomic food, but also the friendly staff they have. The food, especially the beetroot cheesecake tastes amazing but also the care they go into making the dish complete and also to top it of, the excellent presentation of the dish. It''s worth going and trying the food for yourself!!', '5', '88', '20', '1552402729744', '1552409677288'),
('91', 'Best cheesecake in Paris
I went in this restaurant 5 times. The cheesecake is amazing with a lot of different tastes. Tried the brunch too, really really nice with a cheesecake made with comté and Philadelphia cheese, soooo good ! their juices are quite nice too as the coffee. 
For lunch they make special prices, it can be interesting (even more in the other shop close to Gare de Lyon).
The restaurant is charming.
The staff is very nice too.
Would recommend it to anyone.
Not too expensive : between 4 an 8 euros for a cheesecake (the brunch is 23 euros I think but with plenty of things, worthed try).', '5', '89', '20', '1552402745201', '1552409697572'),
('92', 'Great!
We visited She''s cake in the Marais: loved it. Very friendly and attentive staff, GREAT cheesecake and a nice pot of tea in a nicely decorated space. Definitely recommended.', '5', '90', '20', '1552402758517', '1552409712260'),
('93', 'The most amazing cheesecake of my life
This place is a small, well decorated with amazing cheesecakes! So worth it! Every visit was an lovely experience. They also serve lunch, I ate an exquisite salty cheesecake made of gorgonzola so smooth and decadent! A wonderful place to go when in Paris...', '5', '91', '20', '1552402774942', '1552409730576'),
('94', 'Marvelous Merveilleux
Stopped by to try merveilleux, a pastry previously unknown to me. The shop is beautiful and clean. The chandelier was spectacular and really made the shop special. We tried the traditional merveilleux and a pain au chocolat. The merveilleux was a wonderfully light meringue with whipped cream and chocolate. It was light, crisp, and not too sweet. The pain au chocolat was even better than the merveilleux. We will be back!', '5', '93', '21', '1552402879258', '1552409745260'),
('95', 'These deliciously made meringue pastries literally melt in your mouth! And I couldn’t stop eating!
These are by far my favourite pastries in all Paris!! So light and delicious! I bought a dozen of these to share with the boyfriend and we easily finished them within minutes! 

The store is within walking distance from the Eiffel Tower. I always paid a visit to this place every time I came to Paris! 

These meringue cakes are way too underrated! They seriously need to open up more stores worldwide!!', '5', '94', '21', '1552402894609', '1552409756340'),
('96', 'Best meringue cake around
There will be other bakeries trying to make a similar cake, but just go to this place (it is a chain.) Over the years I have tried similar cakes, always more dense and heavy. Other reviewers have already adequately described how good they are - the lightness and just the right amount of sweet.', '5', '95', '21', '1552402908333', '1552409769366'),
('97', 'Fantastic!
Just go there, you will know what I am talking about. This place is wonderful and the pastries and meringues are incredible, you will not be dissapointed.', '5', '96', '21', '1552402921667', '1552409779680'),
('98', 'Deserts that melt in your mouth
We loved the merveilleux, in room temperature, you must eat it within 1 hour. If refrigerated, it can last for 1-2 days according to the store staff.
It''s best to eat it fresh.
They have white chocolate, dark chocolate, coffee, hazelnut, and 1-2 more flavors. 
Delicious. 
I''ve never seen something quite like this one, a chocolate dessert that melt in your mouth.
They have multiple locations in Paris.', '5', '97', '21', '1552402939964', '1552409793802'),
('99', 'Italy in Paris
We had lunch here. Great food and very kind staff. Outside Paris inside Italy. Be careful you don’t order too much! :) I wrote a review but forgot to mention the panna cotta. Ooooh the panna cotta......wow.......!', '5', '98', '22', '1552403112722', '1552409814470'),
('100', 'Amazing Service and Food
What a great Trip Advisor recommendation that I came across. This place is fabulous as a great Italian place in Paris. The manager was very friendly as well as the server. I tried a plate of the day that was to die for. The place is cute and the atmosphere in a very nice neighborhood. The Prosecco was a very good bottle as well. I did the lemon meringue pie and that was superb!', '5', '4', '22', '1552403129386', '1553524329689'),
('101', 'Very little good restaurant
Good deli restaurant Delicious cheese and sausages Cool atmosphere Semi bar quiet area wroth the visit

', '5', '27', '22', '1552403143845', '1553524394510'),
('102', 'Lovely italian
In Le Marais there are many little, good restaurants to be found. This one is a small place, price/quality ok (burrata with truffel, 20 € but really, you can share it with your partner, that big and tasty!) with good service (at least here we had a lady who smile, which is hard to find in even expensive restaurants), and who offered us a cup of coffee for free, after we paid. I call that a superhost! Will def go back!', '4', '48', '22', '1552403159200', '1553524406657'),
('103', 'Fantastic dinner
I had the chance to have dinner at Comptoir gourmet and as Italian I can say the food is authentic and very appreciated. Service is fantastic, they make you feel at home and please try their “piadina”, just delicious. I will surely come back when I am in Paris.', '5', '101', '22', '1552403178114', '1553524441817'),
('104', 'Delicious
We enjoyed a great meal. Make a reservation she only seats a few tables at a time. I had the duck. My wife had the mushroom risotto. Both were delicious. Strong delicious flavours in every course. It’s small, quiet, and delicious.', '5', '39', '23', '1552403280859', '1553524451942'),
('105', 'Amazing day spent with Catherine Reed, cooking lessons and great food!
Our group of six spent a glorious day with Catherine Reed. Catherine is the owner/chef of Reed Restaurant, her hospitality, sense of humor and great cooking lessons made for a memorable day. We learned great techniques, made a full course meal (including an amazing cheese souffle, gougere, duck breast with mango chutney, potatoes and green beans, both cooked in duck fat, profiteroles with home made ice cream for dessert) that we then enjoyed with Catherine. We left with recipes in hand and many memories. It was the highlight of our trip. I highly recommend a visit to Reed Restaurant for either a meal or the cooking lesson. Thank you, Catherine❤', '5', '44', '23', '1552403292349', '1553524459381'),
('106', 'Fantastic evening
Catherine Reed is a delight and she does it all. She was a great hostess, made us feel right at home and we knew instantly that we had made a good decision to eat there. We were served (by Catherine herself) a delicious dinner - 3 courses. Her wine recommendation was terrific. Will happily go back next time in Paris', '5', '70', '23', '1552403292937', '1553524489952'),
('107', 'A real gem!
I had taken a cooking class with Catherine a few years ago and returned to dine at her wonderful restaurant! The place is very small (three tables), and she does all the cooking and serving herself. But this results in personalized service and conversation with the chef, and spectacular food and wine! Highly recommend!', '5', '86', '23', '1552403309600', '1553524477016'),
('108', 'Wonderful Place - Charming Owner/Chef
By far one of the best restaurants in Paris! I recently visited this restaurant with my family. We had a wonderful time. The food was excellent and Catherine Reed was incredibly charming! Be sure to order the tomato tart. It was incredible!', '5', '90', '23', '1552403411005', '1553524503586'),
('109', 'Late Dinner In Paris
Arrived late at our hotel and was just looking for anything that was open and after being turned away from the pizza place across the street decided to try this place. The lady at the counter was extremely friendly as well as the rest of the staff. We ordered some pad Thai to go but they offered to let us stay so we ordered a couple of beers and had our dinner there and everything was excellent. Highly recommend.', '5', '92', '24', '1552403541338', '1553524519771'),
('110', 'As expected in Europe
There are few outstanding Thai restaurants in Europe.
The best one experienced has been a positive surprise in Madrid some years ago. I have reviewed it.

We had:
Shrimp spring rolls - ok - but not totally pealed shrimps.
Papaya salad - ok
Red Prawn Curry- almost no Curry and maybe too much coconut milk.
Chicken basil - I should have asked if it was minced chicken basil- it was not.
Pineapple fried rice - OK

The tables were really not big enough for our dishes which we always share.

The dishes were good sized.

The best this night was really the Singha beer which we do enjoy to Asian Kitchen.

We sat at the open window table. It was a very warm evening and the restaurant started to fill up quite fast.', '3', '72', '24', '1552403554905', '1553524536140'),
('111', 'Lovely tiny thai restaurant
We picked the "meny découverte" and we had three lovely courses, the food is tasty and the price of the menu is really reasonable. The restaurant is located in a quiet and beautiful area, you have the impression to be in a village in the heart of Paris. The staff is really friendly. I definitely recommend this restaurant!', '5', '12', '24', '1552403568693', '1553524558084'),
('112', 'Tasty!
At the hotel where we stayed, receptionist recommended Thai Papaya ( she confirmed that we might not find a table as it’s always busy in the evening). So we decided to give it a shot! 

When we first arrived, Restauarant was almost full with a couple of empty tables. The manager (might be the owner) immediately turned us down by assuring that his place is fully booked and we might find a table in 30 mins! So we agreed to walk around and come back for the table! Then the manager / owner immediately offered to give us a table for two, which felt a bit strange after confirming that all tables were booked! Anyways we were seated and offered a menu. 

Menu had many options with a wide selection of veggie choices which is great.

For starters, we ordered Nems Crevettes - 4pcs (6.8£), Riz Aux Legumes - big portion (8£), Nouille Legumes big portion (10£), Poulet Curry (11£) & 1 Thai beer (4.90£). 

Food and service were excellent. Options were tasty and big enough for two to three persons.

Total invoice was 40,70£ which is fair enough for the tasty food and service. 

Keep it up Thai Papaya! ', '4', '16', '24', '1552403591165', '1553524578357'),
('113', 'Fantastic Food
We ate at Thai Papaya this evening and it was absolutely beautiful. We selected the set menu and were not disappointed. The food was amazing and the portions were very satisfying. We had 1) spring rolls, steamed fish in banana leaves and Thai flan 2) dim sum, green chicken curry and ice cream. We have already decided to go back for a second meal.', '5', '38', '24', '1552403611659', '1553524619567'),
('114', 'Great place for dinner
My wife and I reserved a table here for dinner on a Saturday evening. The small family restaurant was buzzing with happy diners - a great atmosphere which reflects the first class food that is prepared and served here. A lovely spot to relax and enjoy ourselves- thank you.', '5', '59', '25', '1552403719742', '1553524647259'),
('115', 'Excellent
Best home made food with French touch ! Atmosphere, people, ingredients, clients everything is just so PARIS so Good', '5', '26', '25', '1552403734773', '1553524704337'),
('116', 'Must go.
Myself and 2 sisters came away for a few nights in Paris and were lucky enough to find this amazing gem. Superior food and magnificent prices. Every mouthful was a delight. Simple wholesome ingredients and great atmosphere made for a fabulous evening. French heart and soul. Ce magnifique!!! X', '5', '94', '25', '1552403747674', '1553524676540'),
('117', 'Fabulous
We enjoyed the food here so much, we came twice in four days! Couldn’t fault it. Gets busy so booking essential', '5', '47', '25', '1552403762605', '1553524731854'),
('118', 'Excellent
Very friendly environment! Food quality very good! Even if the restaurant was very busy we were attended and have a great support. English speaking as well.', '5', '18', '25', '1552403763238', '1553524748571'),
('119', 'Brilliant Parisian Brunch!
We stumbled across this place whilst actually waiting for somewhere else where the queue was too long. And how glad we were!! 

Their menu is simple but very delicious. We had two of their meat brunches with a cappuccino and fresh orange juice. 

Everything was really well done and delicious. A real gem.', '5', '28', '25', '1552403800571', '1553524764941'),
('120', 'African taste
Couple night at BMK. The staff is really nice, the restaurant is well designed and enjoyable. The food is wonderfull, tasty and unusual (for those unfamiliar with African cuisine). A must try in Paris !', '5', '67', '26', '1552404117139', '1553524841441'),
('121', 'cute african style canteen - many vegetarian options
BMK Paris Bamako is a canteen style restaurant that offers african dishes, revisited to fit the parisians taste. 

i particularly appreciated the fact that there were many vegetarian dishes available.

compared to a traditional african restaurant service is much faster, prices are higher, and dishes don''t have as much flavour. 

Overall great option for a nice lunch.', '4', '30', '26', '1552404140933', '1553524862217'),
('122', 'Excellent food in a charming place
Went for lunch with a friend. The place is cute, the food delicious, the staff super friendly and welcoming! I loved the Mafe and the plantain 😍😍! I will definitely come again and highly recommend :).', '5', '19', '26', '1552404155922', '1553524886142'),
('123', 'A beautiful space to experience African flavours
I was very curious about this restaurant after passing by several times, this area of Paris has an abundance of world kitchen restaurants so it can be a bit over whelming to pick a place to eat when exploring this part of town. However this place kept drawing my attention because of its stylish African inspired interior and shelves with special food products.

We decided to go for dinner and enjoyed a vegan senegalese mafe and a vegan durban salad plus a home made ginger drink. All the food served is from different locations in Africa, but they don’t do typical North African, Moroccan food who are already well established world wide with their tagine dishes.

The mafe was delicious and the salad too, it’s interesting to discover this kind of food because African restos are more scarce than many other world kitchens in general. 

For dessert I had a slice with gluten free sponge cake with raspberries and pistachios, it was baked with cassava flour and tasted very fresh. A perfect ending with the aromatic Ethiopian coffee. 

The service and interior are impeccable, if you’re curious about African food this is a good place to start. The prices are very reasonable too.', '5', '29', '26', '1552404169374', '1553524909125'),
('124', 'Surprisingly good
Very nice and pragmatic atmosphere. Nice ladies on the neighboring table gave us to get the price for the right food.there was no wine, but that we got half the words in the bistro got good food, is your most fear, but of students good place to stay in the evening', '5', '45', '26', '1552404183800', '1553524950941'),
('125', 'Worth a trip
Definitely worth a visit, good food and great service. Groups of us all really enjoyed our meals. Reccommended', '5', '58', '27', '1552404307764', '1553524967434'),
('126', 'Delicious food, great atmosphere
Went for lunch and a drink in this lovely bar that happened to be around the corner from where we were staying. Food was delicious and arrived within 10 minutes of ordering, great and attentive service and good laidback atmosphere to relax and enjoy a drink, highly reccommend!', '5', '93', '27', '1552404322107', '1553524987054'),
('127', 'I loved it
I were there yesterday and I had a really great time. The place is beautiful and waiters are great. I loved the “bavette” with its sauce ❤️', '5', '25', '27', '1552404337746', '1553524996895'),
('128', 'Great location and service
This restaurant was close t our hotel and we went there based on TripAdvisor rating. Service was very good and we all enjoyed our food.', '4', '51', '27', '1552404352368', '1553525008206'),
('129', 'Recommended!
Lovely atmosphere, very quick and friendly service, nice neighborhood. We tried salmon with veggies and salmon-feta salad, both delicious. Coffee is also good, which is not granted in Paris :)', '5', '79', '27', '1552404363823', '1553525021888'),
('130', 'I liked everything
While ln a 6 day vacation in Paris, i went to Cafe Bolivar for lunch every single day!
Lovely food, lovely staff and a homey atmosphere.
Going to Cafe Bolivar is a must if you plan on coming to Paris', '5', '43', '27', '1552404377074', '1553525035928'),
('131', 'Excellent lunch
There are countless great restaurants in Paris but this whole in the wall stood out on our recent trip. We were headed to the catacombs and were deterred by the line. Thus we decided to do what we did every day - and had a 2 hour lunch instead. 

We caught the end of the lunch hour and we’re the only ones there. The server was a little annoyed at first - I think he was hoping to go home. But he shortly warmed up and was great. The food was fabulous. The dessert really good. There are only 10 tables or so - one guy up front and the owner/chef in back. 

I would highly recommend it to anyone staying in Montparnasse or doing the tourist visit to the catacombs.', '5', '60', '28', '1552404473386', '1553525054283'),
('132', 'Delicious dinner for two
Delicious food, very tasty! The service was perfect aswell! I would recommend this restaurant for anybody who would like an authentic french evening.', '5', '21', '28', '1552404487827', '1553525073950'),
('133', 'Cozy, intimate and excellent
This hole-in-the wall restaurant, elegantly decorated in blue, white and red, is a short (approx 15 min) walk from the catacombs, through a charming neighborhood, pedestrian market included. If you''re looking for an upscale, delicate, delicious and friendly restaurant, you can''t do better. Our waiter, Fabian, saw that our French was terrible, and made sure, with good humor and jokes tossed in, that we understood everything we were about to order. Since we went for lunch, there were only two other tables seated for lunch, and together, we built a rapport that made our lunch even more special. I cannot recommend it more highly. We look forward to returning to Paris, and AUX Enfants Gates! (Not LES Enfants Gates! that''s a different restaurant!)', '5', '71', '28', '1552404504067', '1553525108722'),
('134', 'Excellent restaurant do not miss it
This is a very good small restuarant with a cosy athmosphere. Nice decoration, very good table service, a nice and efficient waiter. Excellent food and wine, what you expect of a restaurant with stars in the Michelin guide. All this at a convenient price. I strongly recomment it', '5', '40', '28', '1552404518653', '1553525123931'),
('135', 'Fantastic meal
We had a fantastic meal with excellent service. Standout dishes were the fresh crab starter and cheesecake dessert. Would defintley recommend!', '5', '47', '28', '1552404538130', '1553525141592'),
('136', 'Simply perfect!
I came to this small and cosy restaurant with some colleagues tonight based on a recommendation and because it is well located in relation to our office. I have to say, it was simply perfect! The food was very nicely presented, very fresh and extremely tasty. The one thing that made the evening perfect was our waiter. Funny, attentative, relaxed and very knowledgeable - this was the cherry on the cake. In addition, no frills when you pick up the bill, the value for money is great. I highly recommend this restaurant and I know that I will be back.', '5', '41', '28', '1552404554942', '1553525179654'),
('137', 'Great place in the 14th
Top place with cool waiter really loving it. Dishes change periodically, quality food, revisited with great taste. A must go if you are in this area. Expect to pay 40ish/person without drinks.', '5', '56', '28', '1552404566659', '1553525156966'),
('138', 'Kitchen opens at 20 h
Hi everyone. Beware. The kitchen does not open until 20:00h. I know. I tried to get food around 18:00 on a thursday. Peup nix nada :-)', '4', '23', '29', '1552404714322', '1553525196320'),
('139', 'Brasilian Style in Paris
Nice and popular place, decent food and some real Brasilian dishes. Really nice staff and good service. Also a nice place to hang out with friends. By the way, they have some excellent cocktails.', '4', '22', '29', '1552404730949', '1553525206471'),
('140', 'No complaints here
We were staying in the nearby Ibis Hotel, and just needed some place to eat. The service here was really great. They were able to meet the requests I had wanted, e.g my son wanted pineapple on his pizza, and while that was not on the menu they accommodated it. As well as swapping rice for fries. We enjoyed it to the point that were went back the next day but ordered take away instead. My son loved the Portuguese chicken meal, and I enjoyed my pina colada. 

The staff were really friendly and welcoming, especially the guy who was behind the till, didn''t get his name. It was always busy when we passed, so it must be thoroughly liked by Parisians.', '4', '20', '29', '1552404748486', '1553525228393'),
('141', 'Brazilian option in Paris
Really nice place if you would like to try some Brazilian food, including the famous Brazilian guaraná. Wonderful staff always very supportive.', '4', '14', '29', '1552404763364', '1553525249421'),
('142', 'Superb
Beautiful restaurant. Great food, beautiful atmosphere & the staff cannot do enough for you.. would highly recommend & definitely worth a visit! 5*', '5', '1', '29', '1552404776214', '1553525254458'),
('143', 'Great place ...super impressed
Obrigado is a gemstone in Montrueil Pizza was an absolute highlight. We then tried some tasting plate we were so tempted by the menu. Not dissapointed. Try this place out you will be surprised and delighted A true jewel', '5', '2', '29', '1552404788457', '1553525259887');

INSERT INTO "sqlite_sequence" ("name", "seq") VALUES
('about_uses', '1'),
('about_uses_components', '4'),
('categories', '22'),
('components_about_us_headers', '1'),
('components_about_us_lists', '7'),
('components_about_us_text_block_with_lists', '1'),
('components_about_us_text_block_with_lists_components', '7'),
('components_about_us_text_block_with_titles', '1'),
('components_about_us_text_blocks', '1'),
('components_opening_hours', '128'),
('core_store', '55'),
('likes', '33'),
('restaurants', '29'),
('restaurants_components', '128'),
('reviews', '143'),
('strapi_administrator', '1'),
('upload_file', '218'),
('upload_file_morph', '218'),
('users-permissions_permission', '450'),
('users-permissions_role', '3'),
('users-permissions_user', '101');

INSERT INTO "upload_file" ("id", "name", "alternativeText", "caption", "width", "height", "formats", "hash", "ext", "mime", "size", "url", "previewUrl", "provider", "provider_metadata", "created_at", "updated_at") VALUES
('1', 'aspic_004.jpeg', NULL, NULL, NULL, NULL, NULL, '29d5f5ef9bbc4a438cfb9a9299fd0607', '.jpeg', 'image/jpeg', '69.93', '/uploads/29d5f5ef9bbc4a438cfb9a9299fd0607.jpeg', NULL, 'local', NULL, '1552396322403', '1552396322416'),
('2', 'aspic_001.jpeg', NULL, NULL, NULL, NULL, NULL, '48f5da81ca8e460eb29591605fa6edba', '.jpeg', 'image/jpeg', '633.28', '/uploads/48f5da81ca8e460eb29591605fa6edba.jpeg', NULL, 'local', NULL, '1552396322404', '1552396322417'),
('3', 'aspic_002.jpeg', NULL, NULL, NULL, NULL, NULL, '2f600e2114994432ae78a3d05e94e133', '.jpeg', 'image/jpeg', '740.22', '/uploads/2f600e2114994432ae78a3d05e94e133.jpeg', NULL, 'local', NULL, '1552396322404', '1552396322418'),
('4', 'aspic_003.jpeg', NULL, NULL, NULL, NULL, NULL, '063efd98c5b7401f9ea00864211095ed', '.jpeg', 'image/jpeg', '142.25', '/uploads/063efd98c5b7401f9ea00864211095ed.jpeg', NULL, 'local', NULL, '1552396322404', '1552396322418'),
('5', 'canalegria_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'b2f1a916549e4857a2735831b98fc5c0', '.jpeg', 'image/jpeg', '290.63', '/uploads/b2f1a916549e4857a2735831b98fc5c0.jpeg', NULL, 'local', NULL, '1552397066261', '1552397066273'),
('6', 'canalegria_004.jpeg', NULL, NULL, NULL, NULL, NULL, '8591e6e5719944389f7b666ea11a66bf', '.jpeg', 'image/jpeg', '119.42', '/uploads/8591e6e5719944389f7b666ea11a66bf.jpeg', NULL, 'local', NULL, '1552397066261', '1552397066273'),
('7', 'canalegria_002.jpeg', NULL, NULL, NULL, NULL, NULL, '05db335321794210a7f2c1591df54d20', '.jpeg', 'image/jpeg', '72.31', '/uploads/05db335321794210a7f2c1591df54d20.jpeg', NULL, 'local', NULL, '1552397066262', '1552397066274'),
('8', 'canalegria_001.jpeg', NULL, NULL, NULL, NULL, NULL, 'e2b7a9488e504269b0c8268ffa163225', '.jpeg', 'image/jpeg', '71.1', '/uploads/e2b7a9488e504269b0c8268ffa163225.jpeg', NULL, 'local', NULL, '1552397066262', '1552397066275'),
('9', 'signamont_001.jpeg', NULL, NULL, NULL, NULL, NULL, '2ba3387bb58f4070a0c12d3432b50dea', '.jpeg', 'image/jpeg', '142.32', '/uploads/2ba3387bb58f4070a0c12d3432b50dea.jpeg', NULL, 'local', NULL, '1552397250921', '1552397250933'),
('10', 'signamont_002.jpeg', NULL, NULL, NULL, NULL, NULL, '6d7c0d264993437b9d4232f16201d233', '.jpeg', 'image/jpeg', '67.73', '/uploads/6d7c0d264993437b9d4232f16201d233.jpeg', NULL, 'local', NULL, '1552397250921', '1552397250934'),
('11', 'signamont_003.jpeg', NULL, NULL, NULL, NULL, NULL, '8a07d783b2614621b36da01b0f906aaa', '.jpeg', 'image/jpeg', '154.25', '/uploads/8a07d783b2614621b36da01b0f906aaa.jpeg', NULL, 'local', NULL, '1552397250922', '1552397250935'),
('12', 'signamont_004.jpeg', NULL, NULL, NULL, NULL, NULL, '6729da59d5b64f3f96b1cb2c4a279f5a', '.jpeg', 'image/jpeg', '138.31', '/uploads/6729da59d5b64f3f96b1cb2c4a279f5a.jpeg', NULL, 'local', NULL, '1552397250922', '1552397250935'),
('13', 'lecalife_002.jpeg', NULL, NULL, NULL, NULL, NULL, '05b96a46ea2b4b7bb045bd8b000bedb3', '.jpeg', 'image/jpeg', '84.69', '/uploads/05b96a46ea2b4b7bb045bd8b000bedb3.jpeg', NULL, 'local', NULL, '1552397338169', '1552397338181'),
('14', 'lecalife_001.jpeg', NULL, NULL, NULL, NULL, NULL, 'e705591685f34e7a9b56b794d545b5b3', '.jpeg', 'image/jpeg', '73.38', '/uploads/e705591685f34e7a9b56b794d545b5b3.jpeg', NULL, 'local', NULL, '1552397338170', '1552397338182'),
('15', 'lecalife_003.jpeg', NULL, NULL, NULL, NULL, NULL, '22c8d9281f7a4c03bed5fa4178ccfcbe', '.jpeg', 'image/jpeg', '141.92', '/uploads/22c8d9281f7a4c03bed5fa4178ccfcbe.jpeg', NULL, 'local', NULL, '1552397338170', '1552397338183'),
('16', 'lecalife_004.jpeg', NULL, NULL, NULL, NULL, NULL, '5d81455f4ad34e33a520c94ac3cc5947', '.jpeg', 'image/jpeg', '44.82', '/uploads/5d81455f4ad34e33a520c94ac3cc5947.jpeg', NULL, 'local', NULL, '1552397338170', '1552397338184'),
('17', 'lepiaf_003.jpeg', NULL, NULL, NULL, NULL, NULL, '5fe7e3ac45354029bc0d9dd52d4e00ec', '.jpeg', 'image/jpeg', '81.7', '/uploads/5fe7e3ac45354029bc0d9dd52d4e00ec.jpeg', NULL, 'local', NULL, '1552397796586', '1552397796599'),
('18', 'lepiaf_001.jpeg', NULL, NULL, NULL, NULL, NULL, '86b4ea14d0e142fe95eacfde5508372f', '.jpeg', 'image/jpeg', '153.87', '/uploads/86b4ea14d0e142fe95eacfde5508372f.jpeg', NULL, 'local', NULL, '1552397796587', '1552397796600'),
('19', 'lepiaf_002.jpeg', NULL, NULL, NULL, NULL, NULL, '002c37a9152e487cac8cfb387a1e99db', '.jpeg', 'image/jpeg', '143.03', '/uploads/002c37a9152e487cac8cfb387a1e99db.jpeg', NULL, 'local', NULL, '1552397796588', '1552397796602'),
('20', 'lepiaf_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'da26bb68e1384ceab0e4cfa1944b48a0', '.jpeg', 'image/jpeg', '87.03', '/uploads/da26bb68e1384ceab0e4cfa1944b48a0.jpeg', NULL, 'local', NULL, '1552397796588', '1552397796603'),
('21', 'guiloguilo_001.jpeg', NULL, NULL, NULL, NULL, NULL, '17273dd904c14c80b986e889f2e91121', '.jpeg', 'image/jpeg', '146.15', '/uploads/17273dd904c14c80b986e889f2e91121.jpeg', NULL, 'local', NULL, '1552397911044', '1552397911060'),
('22', 'guiloguilo_004.jpeg', NULL, NULL, NULL, NULL, NULL, '0962dfef80ce4a4f968b2abe67dd5e1b', '.jpeg', 'image/jpeg', '121.66', '/uploads/0962dfef80ce4a4f968b2abe67dd5e1b.jpeg', NULL, 'local', NULL, '1552397911044', '1552397911061'),
('23', 'guiloguilo_002.jpeg', NULL, NULL, NULL, NULL, NULL, '42a507e3fdf448a586cb9886192ebcd1', '.jpeg', 'image/jpeg', '198.78', '/uploads/42a507e3fdf448a586cb9886192ebcd1.jpeg', NULL, 'local', NULL, '1552397911044', '1552397911062'),
('24', 'guiloguilo_003.jpeg', NULL, NULL, NULL, NULL, NULL, '899f9f3eff6544eca26aca760633bf90', '.jpeg', 'image/jpeg', '475.98', '/uploads/899f9f3eff6544eca26aca760633bf90.jpeg', NULL, 'local', NULL, '1552397911045', '1552397911064'),
('25', 'laMiN_002.jpeg', NULL, NULL, NULL, NULL, NULL, 'f2a502483a5f4d9db024185670323889', '.jpeg', 'image/jpeg', '181.55', '/uploads/f2a502483a5f4d9db024185670323889.jpeg', NULL, 'local', NULL, '1552398585441', '1552398585449'),
('26', 'laMiN_001.jpeg', NULL, NULL, NULL, NULL, NULL, '9e1b5bfc019a462781d10df1c20ed630', '.jpeg', 'image/jpeg', '427.32', '/uploads/9e1b5bfc019a462781d10df1c20ed630.jpeg', NULL, 'local', NULL, '1552398585441', '1552398585450'),
('27', 'laMiN_003.jpeg', NULL, NULL, NULL, NULL, NULL, '589acd0143df4609b170870fda629ce6', '.jpeg', 'image/jpeg', '251.0', '/uploads/589acd0143df4609b170870fda629ce6.jpeg', NULL, 'local', NULL, '1552398585441', '1552398585451'),
('28', 'laMiN_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'b2927120b21c40d08bb8d4829818b8cb', '.jpeg', 'image/jpeg', '208.83', '/uploads/b2927120b21c40d08bb8d4829818b8cb.jpeg', NULL, 'local', NULL, '1552398585441', '1552398585452'),
('29', 'oplato_001.jpeg', NULL, NULL, NULL, NULL, NULL, '7e9b27ad612b44739c7b5a4e8601966f', '.jpeg', 'image/jpeg', '79.99', '/uploads/7e9b27ad612b44739c7b5a4e8601966f.jpeg', NULL, 'local', NULL, '1552398874796', '1552398874806'),
('30', 'oplato_002.jpeg', NULL, NULL, NULL, NULL, NULL, '906e5ebb9b2a493ea8fe154fab153d28', '.jpeg', 'image/jpeg', '248.3', '/uploads/906e5ebb9b2a493ea8fe154fab153d28.jpeg', NULL, 'local', NULL, '1552398874796', '1552398874807'),
('31', 'oplato_003.jpeg', NULL, NULL, NULL, NULL, NULL, '0fa876133d994feaa1c6f8990e2d9dea', '.jpeg', 'image/jpeg', '96.49', '/uploads/0fa876133d994feaa1c6f8990e2d9dea.jpeg', NULL, 'local', NULL, '1552398874797', '1552398874807'),
('32', 'oplato_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'a45867042208488e931ed093c6f412b1', '.jpeg', 'image/jpeg', '219.82', '/uploads/a45867042208488e931ed093c6f412b1.jpeg', NULL, 'local', NULL, '1552398874797', '1552398874808'),
('33', 'jardinkashmir_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'f52bb9722efe4b10bb3e5c3e0fd0896e', '.jpeg', 'image/jpeg', '128.4', '/uploads/f52bb9722efe4b10bb3e5c3e0fd0896e.jpeg', NULL, 'local', NULL, '1552399083732', '1552399083743'),
('34', 'jardinkashmir_002.jpeg', NULL, NULL, NULL, NULL, NULL, '9d9c9a89985345cc8e36dfe162f63a98', '.jpeg', 'image/jpeg', '299.52', '/uploads/9d9c9a89985345cc8e36dfe162f63a98.jpeg', NULL, 'local', NULL, '1552399083733', '1552399083744'),
('35', 'jardinkashmir_001.jpeg', NULL, NULL, NULL, NULL, NULL, '08c9c93c6f194351808820bf507edae1', '.jpeg', 'image/jpeg', '278.82', '/uploads/08c9c93c6f194351808820bf507edae1.jpeg', NULL, 'local', NULL, '1552399083733', '1552399083744'),
('36', 'jardinkashmir_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'd867c7b4856c4669bca6bf85d709735c', '.jpeg', 'image/jpeg', '119.01', '/uploads/d867c7b4856c4669bca6bf85d709735c.jpeg', NULL, 'local', NULL, '1552399083733', '1552399083745'),
('37', 'cezembre_001.jpeg', NULL, NULL, NULL, NULL, NULL, '341731eeddf9411eaeaa9b01aa1c6bf8', '.jpeg', 'image/jpeg', '173.21', '/uploads/341731eeddf9411eaeaa9b01aa1c6bf8.jpeg', NULL, 'local', NULL, '1552399333610', '1552399333622'),
('38', 'cezembre_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'fd15670843a54bf5a58852bbb454fb1d', '.jpeg', 'image/jpeg', '431.44', '/uploads/fd15670843a54bf5a58852bbb454fb1d.jpeg', NULL, 'local', NULL, '1552399333610', '1552399333623'),
('39', 'cezembre_002.jpeg', NULL, NULL, NULL, NULL, NULL, '23ddaf9d7971435183b8f720f04a0430', '.jpeg', 'image/jpeg', '288.05', '/uploads/23ddaf9d7971435183b8f720f04a0430.jpeg', NULL, 'local', NULL, '1552399333610', '1552399333624'),
('40', 'cezembre_004.jpeg', NULL, NULL, NULL, NULL, NULL, '7923a72ae36f405085cc26395a1ef5aa', '.jpeg', 'image/jpeg', '283.47', '/uploads/7923a72ae36f405085cc26395a1ef5aa.jpeg', NULL, 'local', NULL, '1552399333611', '1552399333625'),
('41', 'bisouscreperie_001.jpeg', NULL, NULL, NULL, NULL, NULL, '1a1e9c2f1129455281aa1333f7aafcc8', '.jpeg', 'image/jpeg', '382.37', '/uploads/1a1e9c2f1129455281aa1333f7aafcc8.jpeg', NULL, 'local', NULL, '1552399498854', '1552399498864'),
('42', 'bisouscreperie_002.jpeg', NULL, NULL, NULL, NULL, NULL, '1b1977ebcaf949db980de397bdda36ad', '.jpeg', 'image/jpeg', '158.88', '/uploads/1b1977ebcaf949db980de397bdda36ad.jpeg', NULL, 'local', NULL, '1552399498854', '1552399498866'),
('43', 'bisouscreperie_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'f2759b0d63c24dd3987841f23aad0707', '.jpeg', 'image/jpeg', '134.88', '/uploads/f2759b0d63c24dd3987841f23aad0707.jpeg', NULL, 'local', NULL, '1552399498855', '1552399498867'),
('44', 'bisouscreperie_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'f77f7b1d36bc4ceab5e9e510fee3b1b6', '.jpeg', 'image/jpeg', '286.45', '/uploads/f77f7b1d36bc4ceab5e9e510fee3b1b6.jpeg', NULL, 'local', NULL, '1552399498855', '1552399498868'),
('45', 'biscotte_001.jpeg', NULL, NULL, NULL, NULL, NULL, '25862c74ac624b08aac7743297ef1232', '.jpeg', 'image/jpeg', '203.66', '/uploads/25862c74ac624b08aac7743297ef1232.jpeg', NULL, 'local', NULL, '1552399727432', '1552399727440'),
('46', 'biscotte_004.jpeg', NULL, NULL, NULL, NULL, NULL, '0ebc4fe2de194a25ab8bedfe4379152c', '.jpeg', 'image/jpeg', '162.53', '/uploads/0ebc4fe2de194a25ab8bedfe4379152c.jpeg', NULL, 'local', NULL, '1552399727432', '1552399727441'),
('47', 'biscotte_002.jpeg', NULL, NULL, NULL, NULL, NULL, '6399482399e946f38503a69e5e298aa1', '.jpeg', 'image/jpeg', '79.23', '/uploads/6399482399e946f38503a69e5e298aa1.jpeg', NULL, 'local', NULL, '1552399727432', '1552399727443'),
('48', 'biscotte_003.jpeg', NULL, NULL, NULL, NULL, NULL, '4358665e44d04adebb31e9e5b5496a6c', '.jpeg', 'image/jpeg', '114.88', '/uploads/4358665e44d04adebb31e9e5b5496a6c.jpeg', NULL, 'local', NULL, '1552399727432', '1552399727444'),
('49', 'bistrotindochine_002.jpeg', NULL, NULL, NULL, NULL, NULL, '9d54d9ed91274f0b8155f5eceb53a87d', '.jpeg', 'image/jpeg', '69.18', '/uploads/9d54d9ed91274f0b8155f5eceb53a87d.jpeg', NULL, 'local', NULL, '1552400250819', '1552400250829'),
('50', 'bistrotindochine_001.jpeg', NULL, NULL, NULL, NULL, NULL, '4e8b11be6d084bfebc35b2e67ab6b830', '.jpeg', 'image/jpeg', '95.13', '/uploads/4e8b11be6d084bfebc35b2e67ab6b830.jpeg', NULL, 'local', NULL, '1552400250819', '1552400250830'),
('51', 'bistrotindochine_004.jpeg', NULL, NULL, NULL, NULL, NULL, '9e7c21319cb8498f8bae02709ec4fd95', '.jpeg', 'image/jpeg', '61.63', '/uploads/9e7c21319cb8498f8bae02709ec4fd95.jpeg', NULL, 'local', NULL, '1552400250821', '1552400250830'),
('52', 'bistrotindochine_003.jpeg', NULL, NULL, NULL, NULL, NULL, '49de1f4b215b4303b4fda937740cd8a9', '.jpeg', 'image/jpeg', '73.69', '/uploads/49de1f4b215b4303b4fda937740cd8a9.jpeg', NULL, 'local', NULL, '1552400250821', '1552400250832'),
('53', 'ruisseauburger_001.jpeg', NULL, NULL, NULL, NULL, NULL, 'ded61641738540438ca95eb4e354a1b8', '.jpeg', 'image/jpeg', '53.8', '/uploads/ded61641738540438ca95eb4e354a1b8.jpeg', NULL, 'local', NULL, '1552400458503', '1552400458515'),
('54', 'ruisseauburger_002.jpeg', NULL, NULL, NULL, NULL, NULL, '42d030f989984871967833252fb2e047', '.jpeg', 'image/jpeg', '92.08', '/uploads/42d030f989984871967833252fb2e047.jpeg', NULL, 'local', NULL, '1552400458503', '1552400458516'),
('55', 'ruisseauburger_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'f1943d93ddc64c16adfa787ae678fe78', '.jpeg', 'image/jpeg', '85.53', '/uploads/f1943d93ddc64c16adfa787ae678fe78.jpeg', NULL, 'local', NULL, '1552400458503', '1552400458517'),
('56', 'ruisseauburger_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'fd62ac435a9c4bb6b3f2919de58e5740', '.jpeg', 'image/jpeg', '42.72', '/uploads/fd62ac435a9c4bb6b3f2919de58e5740.jpeg', NULL, 'local', NULL, '1552400458503', '1552400458517'),
('57', 'mancoracebicheria_001.jpeg', NULL, NULL, NULL, NULL, NULL, '71035765a586481cb3c7a3e2f0615561', '.jpeg', 'image/jpeg', '73.68', '/uploads/71035765a586481cb3c7a3e2f0615561.jpeg', NULL, 'local', NULL, '1552400602846', '1552400602856'),
('58', 'mancoracebicheria_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'e51bbc9dbb8e47b9b37340d30937a903', '.jpeg', 'image/jpeg', '148.79', '/uploads/e51bbc9dbb8e47b9b37340d30937a903.jpeg', NULL, 'local', NULL, '1552400602846', '1552400602857'),
('59', 'mancoracebicheria_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'bc665a991c834386adfadb3a847e70a9', '.jpeg', 'image/jpeg', '115.93', '/uploads/bc665a991c834386adfadb3a847e70a9.jpeg', NULL, 'local', NULL, '1552400602846', '1552400602857'),
('60', 'mancoracebicheria_002.jpeg', NULL, NULL, NULL, NULL, NULL, '5615a72e60494891a54112058756bf83', '.jpeg', 'image/jpeg', '230.26', '/uploads/5615a72e60494891a54112058756bf83.jpeg', NULL, 'local', NULL, '1552400602846', '1552400602858'),
('61', 'arrivederci_001.jpeg', NULL, NULL, NULL, NULL, NULL, '9ca77246b1a44df59aa3ddb77457c10a', '.jpeg', 'image/jpeg', '84.47', '/uploads/9ca77246b1a44df59aa3ddb77457c10a.jpeg', NULL, 'local', NULL, '1552401900839', '1552401900850'),
('62', 'arrivederci_002.jpeg', NULL, NULL, NULL, NULL, NULL, '3087fb16909d40c980823b25198ca253', '.jpeg', 'image/jpeg', '57.82', '/uploads/3087fb16909d40c980823b25198ca253.jpeg', NULL, 'local', NULL, '1552401900839', '1552401900851'),
('63', 'arrivederci_003.jpeg', NULL, NULL, NULL, NULL, NULL, '47167fb5d728420e9bcd49d41760dfc2', '.jpeg', 'image/jpeg', '77.9', '/uploads/47167fb5d728420e9bcd49d41760dfc2.jpeg', NULL, 'local', NULL, '1552401900839', '1552401900852'),
('64', 'arrivederci_004.jpeg', NULL, NULL, NULL, NULL, NULL, '2eff130c358c4b9d8c309ce369d3ad2d', '.jpeg', 'image/jpeg', '97.29', '/uploads/2eff130c358c4b9d8c309ce369d3ad2d.jpeg', NULL, 'local', NULL, '1552401900839', '1552401900853'),
('65', 'loubnane_001.jpeg', NULL, NULL, NULL, NULL, NULL, '0b20dec91eee46f9aca8e854b94c040b', '.jpeg', 'image/jpeg', '67.01', '/uploads/0b20dec91eee46f9aca8e854b94c040b.jpeg', NULL, 'local', NULL, '1552402071604', '1552402071613'),
('66', 'loubnane_002.jpeg', NULL, NULL, NULL, NULL, NULL, 'c124bf70bc0347dab50bb96929f04bf4', '.jpeg', 'image/jpeg', '70.31', '/uploads/c124bf70bc0347dab50bb96929f04bf4.jpeg', NULL, 'local', NULL, '1552402071604', '1552402071615'),
('67', 'loubnane_003.jpeg', NULL, NULL, NULL, NULL, NULL, '418f401edaa8496790ff34bc36e04c37', '.jpeg', 'image/jpeg', '111.73', '/uploads/418f401edaa8496790ff34bc36e04c37.jpeg', NULL, 'local', NULL, '1552402071605', '1552402071615'),
('68', 'loubnane_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'fb0053d29bbb4639af8b6cc27ff0529a', '.jpeg', 'image/jpeg', '57.6', '/uploads/fb0053d29bbb4639af8b6cc27ff0529a.jpeg', NULL, 'local', NULL, '1552402071605', '1552402071616'),
('69', 'danard_001.jpeg', NULL, NULL, NULL, NULL, NULL, 'bdb95ff372e0430d9789b6acbcddff5b', '.jpeg', 'image/jpeg', '56.73', '/uploads/bdb95ff372e0430d9789b6acbcddff5b.jpeg', NULL, 'local', NULL, '1552402253671', '1552402253708'),
('70', 'danard_002.jpeg', NULL, NULL, NULL, NULL, NULL, '4754cf06790b4c2f9c16e0b56617ccec', '.jpeg', 'image/jpeg', '98.13', '/uploads/4754cf06790b4c2f9c16e0b56617ccec.jpeg', NULL, 'local', NULL, '1552402253671', '1552402253709'),
('71', 'danard_004.jpeg', NULL, NULL, NULL, NULL, NULL, '7ce0010c16a2404dad5b4c524447529e', '.jpeg', 'image/jpeg', '53.77', '/uploads/7ce0010c16a2404dad5b4c524447529e.jpeg', NULL, 'local', NULL, '1552402253672', '1552402253709'),
('72', 'danard_003.jpeg', NULL, NULL, NULL, NULL, NULL, '1b7f5d7d35814ac283744ce40efacaf4', '.jpeg', 'image/jpeg', '207.86', '/uploads/1b7f5d7d35814ac283744ce40efacaf4.jpeg', NULL, 'local', NULL, '1552402253674', '1552402253710'),
('73', 'baronrouge_001.jpeg', NULL, NULL, NULL, NULL, NULL, '8bb416e5e6ba4b25b8d4f1b2a8e63b9d', '.jpeg', 'image/jpeg', '41.29', '/uploads/8bb416e5e6ba4b25b8d4f1b2a8e63b9d.jpeg', NULL, 'local', NULL, '1552402509316', '1552402509327'),
('74', 'baronrouge_002.jpeg', NULL, NULL, NULL, NULL, NULL, '37f1ee9be7e3470082e3231d71ece7c5', '.jpeg', 'image/jpeg', '44.76', '/uploads/37f1ee9be7e3470082e3231d71ece7c5.jpeg', NULL, 'local', NULL, '1552402509317', '1552402509328'),
('75', 'baronrouge_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'eebe1b8ed012402caefb001b403249a7', '.jpeg', 'image/jpeg', '63.84', '/uploads/eebe1b8ed012402caefb001b403249a7.jpeg', NULL, 'local', NULL, '1552402509317', '1552402509329'),
('76', 'baronrouge_004.jpeg', NULL, NULL, NULL, NULL, NULL, '84aa457c19c04c59bf6f7142f6335576', '.jpeg', 'image/jpeg', '152.88', '/uploads/84aa457c19c04c59bf6f7142f6335576.jpeg', NULL, 'local', NULL, '1552402509317', '1552402509329'),
('77', 'shescake_002.jpeg', NULL, NULL, NULL, NULL, NULL, 'daa5adc9427840d3a82929a0d19c63fa', '.jpeg', 'image/jpeg', '40.48', '/uploads/daa5adc9427840d3a82929a0d19c63fa.jpeg', NULL, 'local', NULL, '1552402698473', '1552402698485'),
('78', 'shescake_004.jpeg', NULL, NULL, NULL, NULL, NULL, '6679825a5b4f495ebf0e784ce41ac2d2', '.jpeg', 'image/jpeg', '85.88', '/uploads/6679825a5b4f495ebf0e784ce41ac2d2.jpeg', NULL, 'local', NULL, '1552402698473', '1552402698486'),
('79', 'shescake_003.jpeg', NULL, NULL, NULL, NULL, NULL, '6409c3c2b0d04cb79b6402d9d31231bb', '.jpeg', 'image/jpeg', '83.86', '/uploads/6409c3c2b0d04cb79b6402d9d31231bb.jpeg', NULL, 'local', NULL, '1552402698474', '1552402698486'),
('80', 'shescake_001.jpeg', NULL, NULL, NULL, NULL, NULL, '7f26de1d0ef440dab3d206f9e0bb459f', '.jpeg', 'image/jpeg', '77.03', '/uploads/7f26de1d0ef440dab3d206f9e0bb459f.jpeg', NULL, 'local', NULL, '1552402698474', '1552402698487'),
('81', 'merveilleux_001.jpeg', NULL, NULL, NULL, NULL, NULL, '3cccaad906dd46d2b5b3eb4a9d9c0d76', '.jpeg', 'image/jpeg', '12.43', '/uploads/3cccaad906dd46d2b5b3eb4a9d9c0d76.jpeg', NULL, 'local', NULL, '1552402851318', '1552402851329'),
('82', 'merveilleux_002.jpeg', NULL, NULL, NULL, NULL, NULL, '52643a5244e64b50a9a0a67e0af391cb', '.jpeg', 'image/jpeg', '13.96', '/uploads/52643a5244e64b50a9a0a67e0af391cb.jpeg', NULL, 'local', NULL, '1552402851319', '1552402851330'),
('83', 'merveilleux_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'b3e452041cca46b7ba603b7a1b82aa86', '.jpeg', 'image/jpeg', '13.82', '/uploads/b3e452041cca46b7ba603b7a1b82aa86.jpeg', NULL, 'local', NULL, '1552402851319', '1552402851330'),
('84', 'merveilleux_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'da411d4dc0334955b352fee0e1a60f2a', '.jpeg', 'image/jpeg', '8.89', '/uploads/da411d4dc0334955b352fee0e1a60f2a.jpeg', NULL, 'local', NULL, '1552402851319', '1552402851331'),
('85', 'comptoirgourmet_001.jpeg', NULL, NULL, NULL, NULL, NULL, 'bbd18e1c2e424df6bd0a1adf7b06b03f', '.jpeg', 'image/jpeg', '104.22', '/uploads/bbd18e1c2e424df6bd0a1adf7b06b03f.jpeg', NULL, 'local', NULL, '1552403078997', '1552403079008'),
('86', 'comptoirgourmet_003.jpeg', NULL, NULL, NULL, NULL, NULL, '20d584e9ed894ffd963772bb96121d3c', '.jpeg', 'image/jpeg', '148.79', '/uploads/20d584e9ed894ffd963772bb96121d3c.jpeg', NULL, 'local', NULL, '1552403078997', '1552403079009'),
('87', 'comptoirgourmet_002.jpeg', NULL, NULL, NULL, NULL, NULL, 'f855f3a442664ce6b17fc7f6e2972343', '.jpeg', 'image/jpeg', '64.52', '/uploads/f855f3a442664ce6b17fc7f6e2972343.jpeg', NULL, 'local', NULL, '1552403078999', '1552403079009'),
('88', 'comptoirgourmet_004.jpeg', NULL, NULL, NULL, NULL, NULL, '025075e5d11b44f0b66b66101340c4b6', '.jpeg', 'image/jpeg', '62.88', '/uploads/025075e5d11b44f0b66b66101340c4b6.jpeg', NULL, 'local', NULL, '1552403078999', '1552403079011'),
('89', 'reed_001.jpeg', NULL, NULL, NULL, NULL, NULL, '663e9a8f761b49f8ac6fca16b78bec5d', '.jpeg', 'image/jpeg', '22.8', '/uploads/663e9a8f761b49f8ac6fca16b78bec5d.jpeg', NULL, 'local', NULL, '1552403250549', '1552403250558'),
('90', 'reed_002.jpeg', NULL, NULL, NULL, NULL, NULL, '5bed26d6fdd94bb9af9308081eeaa4a5', '.jpeg', 'image/jpeg', '40.64', '/uploads/5bed26d6fdd94bb9af9308081eeaa4a5.jpeg', NULL, 'local', NULL, '1552403250549', '1552403250558'),
('91', 'reed_003.jpeg', NULL, NULL, NULL, NULL, NULL, '9a77d74713bc48548fd988ec0fa01cad', '.jpeg', 'image/jpeg', '40.25', '/uploads/9a77d74713bc48548fd988ec0fa01cad.jpeg', NULL, 'local', NULL, '1552403250550', '1552403250560'),
('92', 'reed_004.jpeg', NULL, NULL, NULL, NULL, NULL, '742f186af1cc48d880c432af108dde86', '.jpeg', 'image/jpeg', '67.22', '/uploads/742f186af1cc48d880c432af108dde86.jpeg', NULL, 'local', NULL, '1552403250550', '1552403250561'),
('93', 'thaipapaye_001.jpeg', NULL, NULL, NULL, NULL, NULL, '75387e78347047be85e2793077b1efe1', '.jpeg', 'image/jpeg', '39.15', '/uploads/75387e78347047be85e2793077b1efe1.jpeg', NULL, 'local', NULL, '1552403510460', '1552403510469'),
('94', 'thaipapaye_002.jpeg', NULL, NULL, NULL, NULL, NULL, 'd064430ea29849d695e65310862b6786', '.jpeg', 'image/jpeg', '123.18', '/uploads/d064430ea29849d695e65310862b6786.jpeg', NULL, 'local', NULL, '1552403510461', '1552403510470'),
('95', 'thaipapaye_003.jpeg', NULL, NULL, NULL, NULL, NULL, '838d4a1729ac4f21b0d0e8638fb08c48', '.jpeg', 'image/jpeg', '115.51', '/uploads/838d4a1729ac4f21b0d0e8638fb08c48.jpeg', NULL, 'local', NULL, '1552403510461', '1552403510471'),
('96', 'thaipapaye_004.jpeg', NULL, NULL, NULL, NULL, NULL, '17666bf6b4c34bff890e238fafa4cd71', '.jpeg', 'image/jpeg', '78.18', '/uploads/17666bf6b4c34bff890e238fafa4cd71.jpeg', NULL, 'local', NULL, '1552403510461', '1552403510472'),
('97', 'becaneagaston_003.jpeg', NULL, NULL, NULL, NULL, NULL, '7460f144ab584379a1ff61546b22fc89', '.jpeg', 'image/jpeg', '93.86', '/uploads/7460f144ab584379a1ff61546b22fc89.jpeg', NULL, 'local', NULL, '1552403694232', '1552403694242'),
('98', 'becaneagaston_001.jpeg', NULL, NULL, NULL, NULL, NULL, '68e4b61030e64343b496f9b34fd44fc2', '.jpeg', 'image/jpeg', '84.77', '/uploads/68e4b61030e64343b496f9b34fd44fc2.jpeg', NULL, 'local', NULL, '1552403694232', '1552403694243'),
('99', 'becaneagaston_004.jpeg', NULL, NULL, NULL, NULL, NULL, '7077c3f872734ff69ed963e0629fe7c5', '.jpeg', 'image/jpeg', '58.42', '/uploads/7077c3f872734ff69ed963e0629fe7c5.jpeg', NULL, 'local', NULL, '1552403694233', '1552403694243'),
('100', 'becaneagaston_002.jpeg', NULL, NULL, NULL, NULL, NULL, '46c7e9f67e8e4012bc7b86c004c532c1', '.jpeg', 'image/jpeg', '116.26', '/uploads/46c7e9f67e8e4012bc7b86c004c532c1.jpeg', NULL, 'local', NULL, '1552403694233', '1552403694244'),
('101', 'bmk_003.jpg', NULL, NULL, NULL, NULL, NULL, '04e20a3d1fbd44199e3b5ce22f565175', '.jpg', 'image/jpeg', '69.52', '/uploads/04e20a3d1fbd44199e3b5ce22f565175.jpg', NULL, 'local', NULL, '1552404087887', '1552404087897'),
('102', 'bmk_002.jpeg', NULL, NULL, NULL, NULL, NULL, '1a720879312e4c0ebc9c48675b365d48', '.jpeg', 'image/jpeg', '119.93', '/uploads/1a720879312e4c0ebc9c48675b365d48.jpeg', NULL, 'local', NULL, '1552404087887', '1552404087897'),
('103', 'bmk_001.jpeg', NULL, NULL, NULL, NULL, NULL, '36c6d7fa6d874a6ab1373e950fde1742', '.jpeg', 'image/jpeg', '138.33', '/uploads/36c6d7fa6d874a6ab1373e950fde1742.jpeg', NULL, 'local', NULL, '1552404087888', '1552404087899'),
('104', 'bmk_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'a1e31663399d4d3faef55b364c4252c2', '.jpeg', 'image/jpeg', '67.98', '/uploads/a1e31663399d4d3faef55b364c4252c2.jpeg', NULL, 'local', NULL, '1552404087888', '1552404087900'),
('105', 'cafebolivar_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'df4b289827c64902b59b8f957ddc05c4', '.jpeg', 'image/jpeg', '136.76', '/uploads/df4b289827c64902b59b8f957ddc05c4.jpeg', NULL, 'local', NULL, '1552404287605', '1552404287616'),
('106', 'cafebolivar_002.jpeg', NULL, NULL, NULL, NULL, NULL, 'cb8934b80115483ea789e16231942f20', '.jpeg', 'image/jpeg', '90.59', '/uploads/cb8934b80115483ea789e16231942f20.jpeg', NULL, 'local', NULL, '1552404287605', '1552404287616'),
('107', 'cafebolivar_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'dd5bf235c86149fc991ac7fb3375bb8e', '.jpeg', 'image/jpeg', '77.12', '/uploads/dd5bf235c86149fc991ac7fb3375bb8e.jpeg', NULL, 'local', NULL, '1552404287606', '1552404287617'),
('108', 'cafebolivar_001.jpeg', NULL, NULL, NULL, NULL, NULL, '56301de0837f4818b80610a8c71b94ad', '.jpeg', 'image/jpeg', '140.32', '/uploads/56301de0837f4818b80610a8c71b94ad.jpeg', NULL, 'local', NULL, '1552404287606', '1552404287617'),
('109', 'enfantsgates_002.jpeg', NULL, NULL, NULL, NULL, NULL, 'f12f7dbc3e4d4c65ab6783d4f6fab084', '.jpeg', 'image/jpeg', '96.12', '/uploads/f12f7dbc3e4d4c65ab6783d4f6fab084.jpeg', NULL, 'local', NULL, '1552404443392', '1552404443403'),
('110', 'enfantsgates_001.jpeg', NULL, NULL, NULL, NULL, NULL, '4b66f90a305f43f1b6e5ea76e65cbb31', '.jpeg', 'image/jpeg', '90.84', '/uploads/4b66f90a305f43f1b6e5ea76e65cbb31.jpeg', NULL, 'local', NULL, '1552404443392', '1552404443404'),
('111', 'enfantsgates_003.jpeg', NULL, NULL, NULL, NULL, NULL, '26bd1244a0e84b9da76bdff1187df008', '.jpeg', 'image/jpeg', '77.33', '/uploads/26bd1244a0e84b9da76bdff1187df008.jpeg', NULL, 'local', NULL, '1552404443392', '1552404443404'),
('112', 'enfantsgates_004.jpeg', NULL, NULL, NULL, NULL, NULL, 'cc91373a9b194875a10f8b6b4a112855', '.jpeg', 'image/jpeg', '101.17', '/uploads/cc91373a9b194875a10f8b6b4a112855.jpeg', NULL, 'local', NULL, '1552404443392', '1552404443405'),
('113', 'obrigao_002.jpeg', NULL, NULL, NULL, NULL, NULL, '8ca4bf5373fd4564be76d552cd5ffcf9', '.jpeg', 'image/jpeg', '121.82', '/uploads/8ca4bf5373fd4564be76d552cd5ffcf9.jpeg', NULL, 'local', NULL, '1552404669337', '1552404669350'),
('114', 'obrigao_001.jpeg', NULL, NULL, NULL, NULL, NULL, 'b525fa55e767441cadd974deea45d7ff', '.jpeg', 'image/jpeg', '58.52', '/uploads/b525fa55e767441cadd974deea45d7ff.jpeg', NULL, 'local', NULL, '1552404669338', '1552404669351'),
('115', 'obrigao_004.jpeg', NULL, NULL, NULL, NULL, NULL, '388e12ee0c434beb994b60da9f117fe5', '.jpeg', 'image/jpeg', '153.53', '/uploads/388e12ee0c434beb994b60da9f117fe5.jpeg', NULL, 'local', NULL, '1552404669339', '1552404669352'),
('116', 'obrigao_003.jpeg', NULL, NULL, NULL, NULL, NULL, 'f66469b15f484f2f88c0264f278bec75', '.jpeg', 'image/jpeg', '64.32', '/uploads/f66469b15f484f2f88c0264f278bec75.jpeg', NULL, 'local', NULL, '1552404669340', '1552404669353'),
('117', '0.jpg', NULL, NULL, NULL, NULL, NULL, '5f4a1af0c3bd49799a4de5269112fa50', '.jpg', 'image/jpeg', '4.86', '/uploads/5f4a1af0c3bd49799a4de5269112fa50.jpg', NULL, 'local', NULL, '1552486065339', '1552486065345'),
('118', '1.jpg', NULL, NULL, NULL, NULL, NULL, '7360be631cfa47179e444a4573f5859f', '.jpg', 'image/jpeg', '3.6', '/uploads/7360be631cfa47179e444a4573f5859f.jpg', NULL, 'local', NULL, '1552486072475', '1552486072479'),
('119', '1C4EEDC2-FE9C-40B3-A2C9-A038873EE692-200w.jpeg', NULL, NULL, NULL, NULL, NULL, '6b5f232ac3b94e41bc0ea6a4cc19a1c4', '.jpeg', 'image/jpeg', '10.61', '/uploads/6b5f232ac3b94e41bc0ea6a4cc19a1c4.jpeg', NULL, 'local', NULL, '1552486099981', '1552486099987'),
('120', '2.jpg', NULL, NULL, NULL, NULL, NULL, 'a0e518bdcd4b44ea967347c8243e627b', '.jpg', 'image/jpeg', '5.16', '/uploads/a0e518bdcd4b44ea967347c8243e627b.jpg', NULL, 'local', NULL, '1552486126127', '1552486126130'),
('121', '03F55412-DE8A-4F83-AAA6-D67EE5CE48DA-200w.jpeg', NULL, NULL, NULL, NULL, NULL, '8f89036c960b4d1db6c96fd0e4fcf44b', '.jpeg', 'image/jpeg', '14.88', '/uploads/8f89036c960b4d1db6c96fd0e4fcf44b.jpeg', NULL, 'local', NULL, '1552486168661', '1552486168664'),
('122', '6h0HeYG_.jpg', NULL, NULL, NULL, NULL, NULL, '4d8da455f00a45cc8e5e1a4cec93f8bf', '.jpg', 'image/jpeg', '32.8', '/uploads/4d8da455f00a45cc8e5e1a4cec93f8bf.jpg', NULL, 'local', NULL, '1552486183311', '1552486183316'),
('123', '7D3FA6C0-83C8-4834-B432-6C65ED4FD4C3-500w.jpeg', NULL, NULL, NULL, NULL, NULL, '2a0c08471b9a455cb16d6fc1c139e019', '.jpeg', 'image/jpeg', '61.53', '/uploads/2a0c08471b9a455cb16d6fc1c139e019.jpeg', NULL, 'local', NULL, '1552486190893', '1552486190896'),
('124', '8.jpg', NULL, NULL, NULL, NULL, NULL, '3f3e183029654e5cb65477f611a43de1', '.jpg', 'image/jpeg', '5.81', '/uploads/3f3e183029654e5cb65477f611a43de1.jpg', NULL, 'local', NULL, '1552486201743', '1552486201747'),
('125', '8B510E03-96BA-43F0-A85A-F38BB3005AF1-500w.jpeg', NULL, NULL, NULL, NULL, NULL, 'baa9c9d0bbd24075a10c2a4654dfa4ab', '.jpeg', 'image/jpeg', '55.56', '/uploads/baa9c9d0bbd24075a10c2a4654dfa4ab.jpeg', NULL, 'local', NULL, '1552486219608', '1552486219612'),
('126', '17 (1).jpg', NULL, NULL, NULL, NULL, NULL, '8408122737cb4618a475a0d4527cd594', '.jpg', 'image/jpeg', '3.2', '/uploads/8408122737cb4618a475a0d4527cd594.jpg', NULL, 'local', NULL, '1552486231299', '1552486231304'),
('127', '18.jpg', NULL, NULL, NULL, NULL, NULL, '6a743db5fd784bee87915d8d326a1c62', '.jpg', 'image/jpeg', '4.34', '/uploads/6a743db5fd784bee87915d8d326a1c62.jpg', NULL, 'local', NULL, '1552486250932', '1552486250935'),
('128', '21.jpg', NULL, NULL, NULL, NULL, NULL, '4cab75169c904a24be2d484d263d2f1e', '.jpg', 'image/jpeg', '3.47', '/uploads/4cab75169c904a24be2d484d263d2f1e.jpg', NULL, 'local', NULL, '1552486259194', '1552486259199'),
('129', '22.jpg', NULL, NULL, NULL, NULL, NULL, '4cec26e0326047c0a690eeb13410ea7a', '.jpg', 'image/jpeg', '4.75', '/uploads/4cec26e0326047c0a690eeb13410ea7a.jpg', NULL, 'local', NULL, '1552486266357', '1552486266361'),
('130', '26CFEFB3-21C8-49FC-8C19-8E6A62B6D2E0-200w.jpeg', NULL, NULL, NULL, NULL, NULL, 'f6b42ef1a2604e2cac9744eb41ba578b', '.jpeg', 'image/jpeg', '9.07', '/uploads/f6b42ef1a2604e2cac9744eb41ba578b.jpeg', NULL, 'local', NULL, '1552486277258', '1552486277262'),
('131', '26.jpg', NULL, NULL, NULL, NULL, NULL, '5c3b4812c1a34c7ca4d4889d2c93d784', '.jpg', 'image/jpeg', '4.68', '/uploads/5c3b4812c1a34c7ca4d4889d2c93d784.jpg', NULL, 'local', NULL, '1552486293530', '1552486293535'),
('132', '29.jpg', NULL, NULL, NULL, NULL, NULL, 'b3957f8e200546f7a472a90f34d53e21', '.jpg', 'image/jpeg', '6.52', '/uploads/b3957f8e200546f7a472a90f34d53e21.jpg', NULL, 'local', NULL, '1552486301037', '1552486301040'),
('133', '31.jpg', NULL, NULL, NULL, NULL, NULL, '904697174b3c48de943cd1e9f3c671e9', '.jpg', 'image/jpeg', '6.38', '/uploads/904697174b3c48de943cd1e9f3c671e9.jpg', NULL, 'local', NULL, '1552486318664', '1552486318667'),
('134', '32.jpg', NULL, NULL, NULL, NULL, NULL, '71291239647d48a698dbdff2214236c8', '.jpg', 'image/jpeg', '5.24', '/uploads/71291239647d48a698dbdff2214236c8.jpg', NULL, 'local', NULL, '1552486325951', '1552486325955'),
('135', '33.jpg', NULL, NULL, NULL, NULL, NULL, '37d2d966995f482a84a062ba22382322', '.jpg', 'image/jpeg', '5.11', '/uploads/37d2d966995f482a84a062ba22382322.jpg', NULL, 'local', NULL, '1552486336506', '1552486336510'),
('136', '35.jpg', NULL, NULL, NULL, NULL, NULL, '698918331512445681e3f564959d2143', '.jpg', 'image/jpeg', '4.56', '/uploads/698918331512445681e3f564959d2143.jpg', NULL, 'local', NULL, '1552486344693', '1552486344697'),
('137', '36.jpg', NULL, NULL, NULL, NULL, NULL, 'f1c5ee5e03c3487cb62f680097ba77ae', '.jpg', 'image/jpeg', '4.74', '/uploads/f1c5ee5e03c3487cb62f680097ba77ae.jpg', NULL, 'local', NULL, '1552486773723', '1552486773726'),
('138', '41.jpg', NULL, NULL, NULL, NULL, NULL, '2ae2f7e34b0a4b80b8b2b7917f5f183e', '.jpg', 'image/jpeg', '4.25', '/uploads/2ae2f7e34b0a4b80b8b2b7917f5f183e.jpg', NULL, 'local', NULL, '1552486780207', '1552486780212'),
('139', '42.jpg', NULL, NULL, NULL, NULL, NULL, '4e741baab42d48cd954d247509a34f31', '.jpg', 'image/jpeg', '5.0', '/uploads/4e741baab42d48cd954d247509a34f31.jpg', NULL, 'local', NULL, '1552486785557', '1552486785559'),
('140', '43 (1).jpg', NULL, NULL, NULL, NULL, NULL, 'e368d18a4d0a4a91912874cf4dc769dd', '.jpg', 'image/jpeg', '3.9', '/uploads/e368d18a4d0a4a91912874cf4dc769dd.jpg', NULL, 'local', NULL, '1552486792905', '1552486792908'),
('141', '43.jpg', NULL, NULL, NULL, NULL, NULL, '6c84394710c04f85aaf6d5e7e75cf803', '.jpg', 'image/jpeg', '4.96', '/uploads/6c84394710c04f85aaf6d5e7e75cf803.jpg', NULL, 'local', NULL, '1552486804023', '1552486804027'),
('142', '44.jpg', NULL, NULL, NULL, NULL, NULL, '12266f6ee42640349f67562a5e04bb7c', '.jpg', 'image/jpeg', '3.54', '/uploads/12266f6ee42640349f67562a5e04bb7c.jpg', NULL, 'local', NULL, '1552486811491', '1552486811493'),
('143', '46.jpg', NULL, NULL, NULL, NULL, NULL, '6ed96f3016754dbebb33aae965f870ab', '.jpg', 'image/jpeg', '4.82', '/uploads/6ed96f3016754dbebb33aae965f870ab.jpg', NULL, 'local', NULL, '1552486821112', '1552486821117'),
('144', '47 (1).jpg', NULL, NULL, NULL, NULL, NULL, '12cff693ee43449fb684ac9cf0bb8b8f', '.jpg', 'image/jpeg', '4.45', '/uploads/12cff693ee43449fb684ac9cf0bb8b8f.jpg', NULL, 'local', NULL, '1552486832717', '1552486832721'),
('145', '47.jpg', NULL, NULL, NULL, NULL, NULL, 'beccdb7317cc448ca0e2e1e2aaaac79c', '.jpg', 'image/jpeg', '11.33', '/uploads/beccdb7317cc448ca0e2e1e2aaaac79c.jpg', NULL, 'local', NULL, '1552486841842', '1552486841845'),
('146', '48.jpg', NULL, NULL, NULL, NULL, NULL, 'b953521ed034488e914265abe7d31df3', '.jpg', 'image/jpeg', '3.77', '/uploads/b953521ed034488e914265abe7d31df3.jpg', NULL, 'local', NULL, '1552486850020', '1552486850023'),
('147', '49.jpg', NULL, NULL, NULL, NULL, NULL, '5ae7dfafd7784a87b4edd60ce9a49a8d', '.jpg', 'image/jpeg', '4.29', '/uploads/5ae7dfafd7784a87b4edd60ce9a49a8d.jpg', NULL, 'local', NULL, '1552486860254', '1552486860257'),
('148', '57.jpg', NULL, NULL, NULL, NULL, NULL, '6f2db1c508704ac3b1486d78de1d70c9', '.jpg', 'image/jpeg', '5.87', '/uploads/6f2db1c508704ac3b1486d78de1d70c9.jpg', NULL, 'local', NULL, '1552486866730', '1552486866733'),
('149', '61.jpg', NULL, NULL, NULL, NULL, NULL, 'd01f50af772b41f0bd289231df5c93c5', '.jpg', 'image/jpeg', '6.24', '/uploads/d01f50af772b41f0bd289231df5c93c5.jpg', NULL, 'local', NULL, '1552486874218', '1552486874221'),
('150', '63.jpg', NULL, NULL, NULL, NULL, NULL, '9efb315f16684ceb9228e80095608c54', '.jpg', 'image/jpeg', '6.46', '/uploads/9efb315f16684ceb9228e80095608c54.jpg', NULL, 'local', NULL, '1552486885469', '1552486885472'),
('151', '64.jpg', NULL, NULL, NULL, NULL, NULL, '99b633f2983747aebe0a8df659e3f9fe', '.jpg', 'image/jpeg', '9.38', '/uploads/99b633f2983747aebe0a8df659e3f9fe.jpg', NULL, 'local', NULL, '1552486891615', '1552486891617'),
('152', '65.jpg', NULL, NULL, NULL, NULL, NULL, '48c69d7a1c5143fc928b71455bd23c6f', '.jpg', 'image/jpeg', '5.97', '/uploads/48c69d7a1c5143fc928b71455bd23c6f.jpg', NULL, 'local', NULL, '1552486910922', '1552486910925'),
('153', '68.jpg', NULL, NULL, NULL, NULL, NULL, 'b2ae251dfaed4458bf400d29b690650f', '.jpg', 'image/jpeg', '6.95', '/uploads/b2ae251dfaed4458bf400d29b690650f.jpg', NULL, 'local', NULL, '1552486925296', '1552486925299'),
('154', '76.jpg', NULL, NULL, NULL, NULL, NULL, 'd9d5b7bc76d24e5fa3c3d7db3d11ff18', '.jpg', 'image/jpeg', '4.69', '/uploads/d9d5b7bc76d24e5fa3c3d7db3d11ff18.jpg', NULL, 'local', NULL, '1552486964492', '1552486964497'),
('155', '78.jpg', NULL, NULL, NULL, NULL, NULL, '07db9fb3ffdb4096b51ef54403df34e8', '.jpg', 'image/jpeg', '4.64', '/uploads/07db9fb3ffdb4096b51ef54403df34e8.jpg', NULL, 'local', NULL, '1552486971213', '1552486971216'),
('156', '79.jpg', NULL, NULL, NULL, NULL, NULL, '40387009aecb47568fd484562130cdba', '.jpg', 'image/jpeg', '5.27', '/uploads/40387009aecb47568fd484562130cdba.jpg', NULL, 'local', NULL, '1552486978398', '1552486978401'),
('157', '79.jpg', NULL, NULL, NULL, NULL, NULL, '4c81d486bed8444da5d7549beb28ad82', '.jpg', 'image/jpeg', '5.27', '/uploads/4c81d486bed8444da5d7549beb28ad82.jpg', NULL, 'local', NULL, '1552487031320', '1552487031323'),
('158', '80.jpg', NULL, NULL, NULL, NULL, NULL, '858e41f89db1471496d90d6b1559fb5d', '.jpg', 'image/jpeg', '4.82', '/uploads/858e41f89db1471496d90d6b1559fb5d.jpg', NULL, 'local', NULL, '1552487037922', '1552487037925'),
('159', '81.jpg', NULL, NULL, NULL, NULL, NULL, '31fa32373507400cbcd41ce0936b16c5', '.jpg', 'image/jpeg', '4.54', '/uploads/31fa32373507400cbcd41ce0936b16c5.jpg', NULL, 'local', NULL, '1552487044618', '1552487044621'),
('160', '82.jpg', NULL, NULL, NULL, NULL, NULL, 'b385a61171984a23aba27cce5a34b16a', '.jpg', 'image/jpeg', '6.29', '/uploads/b385a61171984a23aba27cce5a34b16a.jpg', NULL, 'local', NULL, '1552487051306', '1552487051309'),
('161', '86.jpg', NULL, NULL, NULL, NULL, NULL, '49e42c764a7146c2bfc950b22efc8c97', '.jpg', 'image/jpeg', '5.43', '/uploads/49e42c764a7146c2bfc950b22efc8c97.jpg', NULL, 'local', NULL, '1552487058262', '1552487058265'),
('162', '91 (1).jpg', NULL, NULL, NULL, NULL, NULL, '009669ab69804d7192ffe7d849a7b254', '.jpg', 'image/jpeg', '4.86', '/uploads/009669ab69804d7192ffe7d849a7b254.jpg', NULL, 'local', NULL, '1552487066063', '1552487066066'),
('163', '95 (1).jpg', NULL, NULL, NULL, NULL, NULL, '55b13bca870d40f8a1555e72aab4d149', '.jpg', 'image/jpeg', '6.59', '/uploads/55b13bca870d40f8a1555e72aab4d149.jpg', NULL, 'local', NULL, '1552487083812', '1552487083815'),
('164', '95.jpg', NULL, NULL, NULL, NULL, NULL, 'e4174f8131db4e6285fe07ad8db05f1d', '.jpg', 'image/jpeg', '4.58', '/uploads/e4174f8131db4e6285fe07ad8db05f1d.jpg', NULL, 'local', NULL, '1552487100548', '1552487100551'),
('165', '97.jpg', NULL, NULL, NULL, NULL, NULL, '62e77b52d6c740ce92455d494fa80e9c', '.jpg', 'image/jpeg', '4.41', '/uploads/62e77b52d6c740ce92455d494fa80e9c.jpg', NULL, 'local', NULL, '1552487108167', '1552487108170'),
('166', '282A12CA-E0D7-4011-8BDD-1FAFAAB035F7-200w.jpeg', NULL, NULL, NULL, NULL, NULL, '4271e7fedf4e4774a48b7caedfdccfd0', '.jpeg', 'image/jpeg', '6.37', '/uploads/4271e7fedf4e4774a48b7caedfdccfd0.jpeg', NULL, 'local', NULL, '1552487131008', '1552487131011'),
('167', 'A7299C8E-CEFC-47D9-939A-3C8CA0EA4D13-200w.jpeg', NULL, NULL, NULL, NULL, NULL, '01940b20380843f09cf62feac2ad4ee1', '.jpeg', 'image/jpeg', '17.34', '/uploads/01940b20380843f09cf62feac2ad4ee1.jpeg', NULL, 'local', NULL, '1552487623353', '1552487623357'),
('168', 'AEF44435-B547-4B84-A2AE-887DFAEE6DDF-200w.jpeg', NULL, NULL, NULL, NULL, NULL, '1591b45a290a4902b2216b105a3a15b6', '.jpeg', 'image/jpeg', '15.11', '/uploads/1591b45a290a4902b2216b105a3a15b6.jpeg', NULL, 'local', NULL, '1552487628201', '1552487628204'),
('169', 'B0298C36-9751-48EF-BE15-80FB9CD11143-500w.jpeg', NULL, NULL, NULL, NULL, NULL, '7aa91d545849491cb24f3840eb3a11c1', '.jpeg', 'image/jpeg', '48.03', '/uploads/7aa91d545849491cb24f3840eb3a11c1.jpeg', NULL, 'local', NULL, '1552487635135', '1552487635138'),
('170', 'BA0CB1F2-8C79-4376-B13B-DD5FB8772537-200w.jpeg', NULL, NULL, NULL, NULL, NULL, '86438b567f79451cb3e65f43b12fb868', '.jpeg', 'image/jpeg', '15.05', '/uploads/86438b567f79451cb3e65f43b12fb868.jpeg', NULL, 'local', NULL, '1552487644311', '1552487644314'),
('171', 'dJj9Z8uq.jpg', NULL, NULL, NULL, NULL, NULL, 'cfa6423926484aab84fdf4e57f445cea', '.jpg', 'image/jpeg', '42.5', '/uploads/cfa6423926484aab84fdf4e57f445cea.jpg', NULL, 'local', NULL, '1552487650493', '1552487650495'),
('172', 'e-3MyGW3.jpg', NULL, NULL, NULL, NULL, NULL, 'eac763d49f20473c9fb8d4faaa827926', '.jpg', 'image/jpeg', '32.8', '/uploads/eac763d49f20473c9fb8d4faaa827926.jpg', NULL, 'local', NULL, '1552487658133', '1552487658136'),
('173', 'E0B4CAB3-F491-4322-BEF2-208B46748D4A-200w.jpeg', NULL, NULL, NULL, NULL, NULL, 'ee9bc0b57dc046db83cd2b0c6fe152b7', '.jpeg', 'image/jpeg', '10.48', '/uploads/ee9bc0b57dc046db83cd2b0c6fe152b7.jpeg', NULL, 'local', NULL, '1552487665581', '1552487665584'),
('174', 'F6440FF2-AB6C-4E71-A57C-F2E79808EC82-500w.jpeg', NULL, NULL, NULL, NULL, NULL, 'e0517434e9f24eb3ae77c887d9e82a45', '.jpeg', 'image/jpeg', '56.02', '/uploads/e0517434e9f24eb3ae77c887d9e82a45.jpeg', NULL, 'local', NULL, '1552487671461', '1552487671464'),
('175', 'GfWweiGR.jpg', NULL, NULL, NULL, NULL, NULL, '5c8d772694424da4961e879c5742f284', '.jpg', 'image/jpeg', '56.06', '/uploads/5c8d772694424da4961e879c5742f284.jpg', NULL, 'local', NULL, '1552487678195', '1552487678198'),
('176', 'gPZwCbdS.jpg', NULL, NULL, NULL, NULL, NULL, '291535c2461144e08775b4a264fa509f', '.jpg', 'image/jpeg', '32.8', '/uploads/291535c2461144e08775b4a264fa509f.jpg', NULL, 'local', NULL, '1552487685196', '1552487685199'),
('177', 'hKv3Fddh.jpg', NULL, NULL, NULL, NULL, NULL, '7d74e89a87c844239ac63da72cde5c02', '.jpg', 'image/jpeg', '480.9', '/uploads/7d74e89a87c844239ac63da72cde5c02.jpg', NULL, 'local', NULL, '1552487692674', '1552487692677'),
('178', 'L7wQctBt.jpg', NULL, NULL, NULL, NULL, NULL, 'b3d1508e8fa0432086f066cee702677d', '.jpg', 'image/jpeg', '32.8', '/uploads/b3d1508e8fa0432086f066cee702677d.jpg', NULL, 'local', NULL, '1552487698629', '1552487698634'),
('179', 'L7wQctBt.jpg', NULL, NULL, NULL, NULL, NULL, 'e3269e475f5f46adbb3a8785b5572b81', '.jpg', 'image/jpeg', '32.8', '/uploads/e3269e475f5f46adbb3a8785b5572b81.jpg', NULL, 'local', NULL, '1552487705112', '1552487705115'),
('180', 'MV5BMjA3NjYzMzE1MV5BMl5BanBnXkFtZTgwNTA4NDY4OTE@._V1_UX172_CR0,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, '9a07581583114e01bde3a0ff1d0aa71b', '.jpg', 'image/jpeg', '9.04', '/uploads/9a07581583114e01bde3a0ff1d0aa71b.jpg', NULL, 'local', NULL, '1552487711689', '1552487711694'),
('181', 'MV5BMjE5ODk2NTI2Nl5BMl5BanBnXkFtZTgwNzIyMDA4MTE@._V1_UY256_CR6,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, '36f48befbd2c46dabfbd34c07b8e7767', '.jpg', 'image/jpeg', '10.28', '/uploads/36f48befbd2c46dabfbd34c07b8e7767.jpg', NULL, 'local', NULL, '1552487718820', '1552487718825'),
('182', 'MV5BMjEzMjA0ODk1OF5BMl5BanBnXkFtZTcwMTA4ODM3OQ@@._V1_UY256_CR5,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, 'e1987dd1d34e450eb96c44ac2b1c2b33', '.jpg', 'image/jpeg', '7.82', '/uploads/e1987dd1d34e450eb96c44ac2b1c2b33.jpg', NULL, 'local', NULL, '1552487725977', '1552487725983'),
('183', 'MV5BMjUzZTJmZDItODRjYS00ZGRhLTg2NWQtOGE0YjJhNWVlMjNjXkEyXkFqcGdeQXVyMTg4NDI0NDM@._V1_UY256_CR42,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, '53f52952b41143afba1a8d56a76abef8', '.jpg', 'image/jpeg', '7.72', '/uploads/53f52952b41143afba1a8d56a76abef8.jpg', NULL, 'local', NULL, '1552487736742', '1552487736746'),
('184', 'MV5BMTAyNTAzMTA4OTJeQTJeQWpwZ15BbWU3MDA4NDI2Njk@._V1_UX172_CR0,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, '69d39e3b1b994947a3956282ddeed3d4', '.jpg', 'image/jpeg', '6.86', '/uploads/69d39e3b1b994947a3956282ddeed3d4.jpg', NULL, 'local', NULL, '1552487752796', '1552487752800'),
('185', 'MV5BMTkxODQwNTgxN15BMl5BanBnXkFtZTcwMjk2OTY1Ng@@._V1_UY256_CR7,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, 'b6512dcb221e4940abf12df0314753c4', '.jpg', 'image/jpeg', '7.68', '/uploads/b6512dcb221e4940abf12df0314753c4.jpg', NULL, 'local', NULL, '1552487761648', '1552487761652'),
('186', 'MV5BMTkzNjE5MzY5M15BMl5BanBnXkFtZTgwMDI5ODMxODE@._V1_UY256_CR98,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, '19f605795bee4972b61002a3f49676a6', '.jpg', 'image/jpeg', '5.53', '/uploads/19f605795bee4972b61002a3f49676a6.jpg', NULL, 'local', NULL, '1552487784569', '1552487784573'),
('187', 'MV5BMTQwMDQ0NDk1OV5BMl5BanBnXkFtZTcwNDcxOTExNg@@._V1_UY256_CR2,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, '838a36d843d24d55aa7b0c9ef81df4d4', '.jpg', 'image/jpeg', '11.52', '/uploads/838a36d843d24d55aa7b0c9ef81df4d4.jpg', NULL, 'local', NULL, '1552488855609', '1552488855613'),
('188', 'MV5BMTUxNTExMzUzOF5BMl5BanBnXkFtZTgwOTI1MjA3OTE@._V1_UX172_CR0,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, '138d04bf892e41d0ad5d5240a8da84f2', '.jpg', 'image/jpeg', '9.21', '/uploads/138d04bf892e41d0ad5d5240a8da84f2.jpg', NULL, 'local', NULL, '1552488986007', '1552488986010'),
('189', 'MV5BODFjZTkwMjItYzRhMS00OWYxLWI3YTUtNWIzOWQ4Yjg4NGZiXkEyXkFqcGdeQXVyMTQ0ODAxNzE@._V1_UX172_CR0,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, 'a75d32e41ef4403987a548fa3b496b35', '.jpg', 'image/jpeg', '8.94', '/uploads/a75d32e41ef4403987a548fa3b496b35.jpg', NULL, 'local', NULL, '1552489004045', '1552489004051'),
('190', 'MV5BOWViYjUzOWMtMzRkZi00MjNkLTk4M2ItMTVkMDg5MzE2ZDYyXkEyXkFqcGdeQXVyODQwNjM3NDA@._V1_UY256_CR36,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, 'f156fc8303d042c0aa937246f44fe8d4', '.jpg', 'image/jpeg', '5.02', '/uploads/f156fc8303d042c0aa937246f44fe8d4.jpg', NULL, 'local', NULL, '1552489010709', '1552489010712'),
('191', 'MV5BOWViYjUzOWMtMzRkZi00MjNkLTk4M2ItMTVkMDg5MzE2ZDYyXkEyXkFqcGdeQXVyODQwNjM3NDA@._V1_UY256_CR36,0,172,256_AL_.jpg', NULL, NULL, NULL, NULL, NULL, '78111234bf864db48f4b080eeee35f86', '.jpg', 'image/jpeg', '5.02', '/uploads/78111234bf864db48f4b080eeee35f86.jpg', NULL, 'local', NULL, '1552489025433', '1552489025437'),
('192', 'n4Ngwvi7.jpg', NULL, NULL, NULL, NULL, NULL, '016b3f09c3d64d0e89fe00700ce3f39e', '.jpg', 'image/jpeg', '32.8', '/uploads/016b3f09c3d64d0e89fe00700ce3f39e.jpg', NULL, 'local', NULL, '1552489033047', '1552489033051'),
('193', 'N5PLzyan.jpg', NULL, NULL, NULL, NULL, NULL, '5bf44b356c0242b298c7504afcafb467', '.jpg', 'image/jpeg', '42.5', '/uploads/5bf44b356c0242b298c7504afcafb467.jpg', NULL, 'local', NULL, '1552489039388', '1552489039391'),
('194', 'N25WgvW_.png', NULL, NULL, NULL, NULL, NULL, 'd4c6bb8a05314a62a1c2a9b52e2e1422', '.png', 'image/png', '116.75', '/uploads/d4c6bb8a05314a62a1c2a9b52e2e1422.png', NULL, 'local', NULL, '1552489054260', '1552489054263'),
('195', 'oedmUmVc.jpg', NULL, NULL, NULL, NULL, NULL, '0c0727d7a26649738a6293b1c8d2f277', '.jpg', 'image/jpeg', '42.5', '/uploads/0c0727d7a26649738a6293b1c8d2f277.jpg', NULL, 'local', NULL, '1552489060664', '1552489060666'),
('196', 'pexels-photo-61100.jpeg', NULL, NULL, NULL, NULL, NULL, '2fc9eee231ca427d8f4c4f430daf2f6e', '.jpeg', 'image/jpeg', '18.39', '/uploads/2fc9eee231ca427d8f4c4f430daf2f6e.jpeg', NULL, 'local', NULL, '1552489067069', '1552489067071'),
('197', 'pexels-photo-220453.jpeg', NULL, NULL, NULL, NULL, NULL, '51813299b2f94d5d9f188d312112fd15', '.jpeg', 'image/jpeg', '8.61', '/uploads/51813299b2f94d5d9f188d312112fd15.jpeg', NULL, 'local', NULL, '1552489107050', '1552489107054'),
('198', 'pexels-photo-247885.jpeg', NULL, NULL, NULL, NULL, NULL, 'a0777a01756a4f2196fe47b694b70e89', '.jpeg', 'image/jpeg', '27.79', '/uploads/a0777a01756a4f2196fe47b694b70e89.jpeg', NULL, 'local', NULL, '1552489131502', '1552489131504'),
('199', 'pexels-photo-355164.jpeg', NULL, NULL, NULL, NULL, NULL, '90fc7420b7974f92a5840cda34601b80', '.jpeg', 'image/jpeg', '16.4', '/uploads/90fc7420b7974f92a5840cda34601b80.jpeg', NULL, 'local', NULL, '1552489140661', '1552489140665'),
('200', 'pexels-photo-415829.jpeg', NULL, NULL, NULL, NULL, NULL, '147b1af63a974781adec49df3f632090', '.jpeg', 'image/jpeg', '12.41', '/uploads/147b1af63a974781adec49df3f632090.jpeg', NULL, 'local', NULL, '1552489149463', '1552489149466'),
('201', 'pexels-photo-614810.jpeg', NULL, NULL, NULL, NULL, NULL, '1d6781c15d9b466988dca19f4ccb93fe', '.jpeg', 'image/jpeg', '10.43', '/uploads/1d6781c15d9b466988dca19f4ccb93fe.jpeg', NULL, 'local', NULL, '1552489156421', '1552489156425'),
('202', 'photo-1438761681033-6461ffad8d80.jpeg', NULL, NULL, NULL, NULL, NULL, '7a88543f039a4a87a634805491e609d6', '.jpeg', 'image/jpeg', '6.46', '/uploads/7a88543f039a4a87a634805491e609d6.jpeg', NULL, 'local', NULL, '1552489170260', '1552489170263'),
('203', 'photo-1456327102063-fb5054efe647.jpeg', NULL, NULL, NULL, NULL, NULL, '60954239cc7c46a5aeaf7bd1aac3d652', '.jpeg', 'image/jpeg', '8.26', '/uploads/60954239cc7c46a5aeaf7bd1aac3d652.jpeg', NULL, 'local', NULL, '1552489177628', '1552489177632'),
('204', 'photo-1463453091185-61582044d556.jpeg', NULL, NULL, NULL, NULL, NULL, '8c827996abcb4add863b83d81a524672', '.jpeg', 'image/jpeg', '12.56', '/uploads/8c827996abcb4add863b83d81a524672.jpeg', NULL, 'local', NULL, '1552489185638', '1552489185641'),
('205', 'photo-1476493279419-b785d41e38d8.jpeg', NULL, NULL, NULL, NULL, NULL, 'c386d14e109d4640a2fadbceaf68b86d', '.jpeg', 'image/jpeg', '8.63', '/uploads/c386d14e109d4640a2fadbceaf68b86d.jpeg', NULL, 'local', NULL, '1552489192303', '1552489192307'),
('206', 'photo-1488426862026-3ee34a7d66df.jpeg', NULL, NULL, NULL, NULL, NULL, 'bfe030a2c902495ea12eaf7f54bbba86', '.jpeg', 'image/jpeg', '17.73', '/uploads/bfe030a2c902495ea12eaf7f54bbba86.jpeg', NULL, 'local', NULL, '1552489200320', '1552489200324'),
('207', 'photo-1493666438817-866a91353ca9.jpeg', NULL, NULL, NULL, NULL, NULL, '3f3a08cf3c2d41d6b8af5244ea02e03e', '.jpeg', 'image/jpeg', '9.89', '/uploads/3f3a08cf3c2d41d6b8af5244ea02e03e.jpeg', NULL, 'local', NULL, '1552489211796', '1552489211801'),
('208', 'photo-1494790108377-be9c29b29330.jpeg', NULL, NULL, NULL, NULL, NULL, '44021421d8174e67b905526455035cd3', '.jpeg', 'image/jpeg', '11.76', '/uploads/44021421d8174e67b905526455035cd3.jpeg', NULL, 'local', NULL, '1552489218141', '1552489218146'),
('209', 'photo-1496081081095-d32308dd6206.jpeg', NULL, NULL, NULL, NULL, NULL, 'af205ba1af1740768395258c96db0546', '.jpeg', 'image/jpeg', '11.45', '/uploads/af205ba1af1740768395258c96db0546.jpeg', NULL, 'local', NULL, '1552489231624', '1552489231628'),
('210', 'photo-1498529605908-f357a9af7bf5.jpeg', NULL, NULL, NULL, NULL, NULL, 'c4c0247b9690426aaa62f545bcbaf2cf', '.jpeg', 'image/jpeg', '7.32', '/uploads/c4c0247b9690426aaa62f545bcbaf2cf.jpeg', NULL, 'local', NULL, '1552489238087', '1552489238090'),
('211', 'photo-1502378735452-bc7d86632805.jpeg', NULL, NULL, NULL, NULL, NULL, '86fb6b18dfd84817941eb3c9411bacf5', '.jpeg', 'image/jpeg', '9.59', '/uploads/86fb6b18dfd84817941eb3c9411bacf5.jpeg', NULL, 'local', NULL, '1552489244851', '1552489244855'),
('212', 'photo-1502720705749-871143f0e671.jpeg', NULL, NULL, NULL, NULL, NULL, 'f68d55b7940f4493b715c607517d886d', '.jpeg', 'image/jpeg', '13.03', '/uploads/f68d55b7940f4493b715c607517d886d.jpeg', NULL, 'local', NULL, '1552489250531', '1552489250536'),
('213', 'photo-1506085452766-c330853bea50.jpeg', NULL, NULL, NULL, NULL, NULL, '67b2ac8db706436b80b9852ee86ae477', '.jpeg', 'image/jpeg', '5.77', '/uploads/67b2ac8db706436b80b9852ee86ae477.jpeg', NULL, 'local', NULL, '1552489255374', '1552489255378'),
('214', 'photo-1506085452766-c330853bea50.jpeg', NULL, NULL, NULL, NULL, NULL, 'dff0f166718546919cfd99280c8042f1', '.jpeg', 'image/jpeg', '5.77', '/uploads/dff0f166718546919cfd99280c8042f1.jpeg', NULL, 'local', NULL, '1552489262256', '1552489262260'),
('215', 'photo-1506794778202-cad84cf45f1d.jpeg', NULL, NULL, NULL, NULL, NULL, '99a13c6b03014f1ca13513d08a74f090', '.jpeg', 'image/jpeg', '15.47', '/uploads/99a13c6b03014f1ca13513d08a74f090.jpeg', NULL, 'local', NULL, '1552489269245', '1552489269248'),
('216', 'photo-1506803682981-6e718a9dd3ee.jpeg', NULL, NULL, NULL, NULL, NULL, 'f0c197304cd546fc805f770553733f88', '.jpeg', 'image/jpeg', '6.52', '/uploads/f0c197304cd546fc805f770553733f88.jpeg', NULL, 'local', NULL, '1552489274354', '1552489274357'),
('217', 'photo-1507003211169-0a1dd7228f2d.jpeg', NULL, NULL, NULL, NULL, NULL, '70dd0d4d9eba45319e186bac2e171ca3', '.jpeg', 'image/jpeg', '11.14', '/uploads/70dd0d4d9eba45319e186bac2e171ca3.jpeg', NULL, 'local', NULL, '1552489286097', '1552489286101'),
('218', 'logo-strapi', '', '', '1138', '302', '{"thumbnail":{"hash":"thumbnail_logo_strapi_31733a1ee6","ext":".png","mime":"image/png","width":245,"height":65,"size":5.42,"path":null,"url":"/uploads/thumbnail_logo_strapi_31733a1ee6.png"},"large":{"hash":"large_logo_strapi_31733a1ee6","ext":".png","mime":"image/png","width":1000,"height":265,"size":24.21,"path":null,"url":"/uploads/large_logo_strapi_31733a1ee6.png"},"medium":{"hash":"medium_logo_strapi_31733a1ee6","ext":".png","mime":"image/png","width":750,"height":199,"size":17.25,"path":null,"url":"/uploads/medium_logo_strapi_31733a1ee6.png"},"small":{"hash":"small_logo_strapi_31733a1ee6","ext":".png","mime":"image/png","width":500,"height":133,"size":11.02,"path":null,"url":"/uploads/small_logo_strapi_31733a1ee6.png"}}', 'logo_strapi_31733a1ee6', '.png', 'image/png', '14.98', '/uploads/logo_strapi_31733a1ee6.png', NULL, 'local', NULL, '1592484918710', '1592484918710');

INSERT INTO "upload_file_morph" ("id", "upload_file_id", "related_id", "related_type", "field", "order") VALUES
('1', '1', '1', 'restaurants', 'cover', NULL),
('2', '2', '1', 'restaurants', 'cover', NULL),
('3', '3', '1', 'restaurants', 'cover', NULL),
('4', '4', '1', 'restaurants', 'cover', NULL),
('5', '5', '3', 'restaurants', 'cover', NULL),
('6', '6', '3', 'restaurants', 'cover', NULL),
('7', '7', '3', 'restaurants', 'cover', NULL),
('8', '8', '3', 'restaurants', 'cover', NULL),
('9', '9', '2', 'restaurants', 'cover', NULL),
('10', '10', '2', 'restaurants', 'cover', NULL),
('11', '11', '2', 'restaurants', 'cover', NULL),
('12', '12', '2', 'restaurants', 'cover', NULL),
('13', '13', '4', 'restaurants', 'cover', NULL),
('14', '14', '4', 'restaurants', 'cover', NULL),
('15', '15', '4', 'restaurants', 'cover', NULL),
('16', '16', '4', 'restaurants', 'cover', NULL),
('17', '17', '5', 'restaurants', 'cover', NULL),
('18', '18', '5', 'restaurants', 'cover', NULL),
('19', '19', '5', 'restaurants', 'cover', NULL),
('20', '20', '5', 'restaurants', 'cover', NULL),
('21', '21', '6', 'restaurants', 'cover', NULL),
('22', '22', '6', 'restaurants', 'cover', NULL),
('23', '23', '6', 'restaurants', 'cover', NULL),
('24', '24', '6', 'restaurants', 'cover', NULL),
('25', '25', '7', 'restaurants', 'cover', NULL),
('26', '26', '7', 'restaurants', 'cover', NULL),
('27', '27', '7', 'restaurants', 'cover', NULL),
('28', '28', '7', 'restaurants', 'cover', NULL),
('29', '29', '8', 'restaurants', 'cover', NULL),
('30', '30', '8', 'restaurants', 'cover', NULL),
('31', '31', '8', 'restaurants', 'cover', NULL),
('32', '32', '8', 'restaurants', 'cover', NULL),
('33', '33', '9', 'restaurants', 'cover', NULL),
('34', '34', '9', 'restaurants', 'cover', NULL),
('35', '35', '9', 'restaurants', 'cover', NULL),
('36', '36', '9', 'restaurants', 'cover', NULL),
('37', '37', '10', 'restaurants', 'cover', NULL),
('38', '38', '10', 'restaurants', 'cover', NULL),
('39', '39', '10', 'restaurants', 'cover', NULL),
('40', '40', '10', 'restaurants', 'cover', NULL),
('41', '41', '11', 'restaurants', 'cover', NULL),
('42', '42', '11', 'restaurants', 'cover', NULL),
('43', '43', '11', 'restaurants', 'cover', NULL),
('44', '44', '11', 'restaurants', 'cover', NULL),
('45', '45', '12', 'restaurants', 'cover', NULL),
('46', '46', '12', 'restaurants', 'cover', NULL),
('47', '47', '12', 'restaurants', 'cover', NULL),
('48', '48', '12', 'restaurants', 'cover', NULL),
('49', '49', '13', 'restaurants', 'cover', NULL),
('50', '50', '13', 'restaurants', 'cover', NULL),
('51', '51', '13', 'restaurants', 'cover', NULL),
('52', '52', '13', 'restaurants', 'cover', NULL),
('53', '53', '14', 'restaurants', 'cover', NULL),
('54', '54', '14', 'restaurants', 'cover', NULL),
('55', '55', '14', 'restaurants', 'cover', NULL),
('56', '56', '14', 'restaurants', 'cover', NULL),
('57', '57', '15', 'restaurants', 'cover', NULL),
('58', '58', '15', 'restaurants', 'cover', NULL),
('59', '59', '15', 'restaurants', 'cover', NULL),
('60', '60', '15', 'restaurants', 'cover', NULL),
('61', '61', '16', 'restaurants', 'cover', NULL),
('62', '62', '16', 'restaurants', 'cover', NULL),
('63', '63', '16', 'restaurants', 'cover', NULL),
('64', '64', '16', 'restaurants', 'cover', NULL),
('65', '65', '17', 'restaurants', 'cover', NULL),
('66', '66', '17', 'restaurants', 'cover', NULL),
('67', '67', '17', 'restaurants', 'cover', NULL),
('68', '68', '17', 'restaurants', 'cover', NULL),
('69', '69', '18', 'restaurants', 'cover', NULL),
('70', '70', '18', 'restaurants', 'cover', NULL),
('71', '71', '18', 'restaurants', 'cover', NULL),
('72', '72', '18', 'restaurants', 'cover', NULL),
('73', '73', '19', 'restaurants', 'cover', NULL),
('74', '74', '19', 'restaurants', 'cover', NULL),
('75', '75', '19', 'restaurants', 'cover', NULL),
('76', '76', '19', 'restaurants', 'cover', NULL),
('77', '77', '20', 'restaurants', 'cover', NULL),
('78', '78', '20', 'restaurants', 'cover', NULL),
('79', '79', '20', 'restaurants', 'cover', NULL),
('80', '80', '20', 'restaurants', 'cover', NULL),
('81', '81', '21', 'restaurants', 'cover', NULL),
('82', '82', '21', 'restaurants', 'cover', NULL),
('83', '83', '21', 'restaurants', 'cover', NULL),
('84', '84', '21', 'restaurants', 'cover', NULL),
('85', '85', '22', 'restaurants', 'cover', NULL),
('86', '86', '22', 'restaurants', 'cover', NULL),
('87', '87', '22', 'restaurants', 'cover', NULL),
('88', '88', '22', 'restaurants', 'cover', NULL),
('89', '89', '23', 'restaurants', 'cover', NULL),
('90', '90', '23', 'restaurants', 'cover', NULL),
('91', '91', '23', 'restaurants', 'cover', NULL),
('92', '92', '23', 'restaurants', 'cover', NULL),
('93', '93', '24', 'restaurants', 'cover', NULL),
('94', '94', '24', 'restaurants', 'cover', NULL),
('95', '95', '24', 'restaurants', 'cover', NULL),
('96', '96', '24', 'restaurants', 'cover', NULL),
('97', '97', '25', 'restaurants', 'cover', NULL),
('98', '98', '25', 'restaurants', 'cover', NULL),
('99', '99', '25', 'restaurants', 'cover', NULL),
('100', '100', '25', 'restaurants', 'cover', NULL),
('101', '101', '26', 'restaurants', 'cover', NULL),
('102', '102', '26', 'restaurants', 'cover', NULL),
('103', '103', '26', 'restaurants', 'cover', NULL),
('104', '104', '26', 'restaurants', 'cover', NULL),
('105', '105', '27', 'restaurants', 'cover', NULL),
('106', '106', '27', 'restaurants', 'cover', NULL),
('107', '107', '27', 'restaurants', 'cover', NULL),
('108', '108', '27', 'restaurants', 'cover', NULL),
('109', '109', '28', 'restaurants', 'cover', NULL),
('110', '110', '28', 'restaurants', 'cover', NULL),
('111', '111', '28', 'restaurants', 'cover', NULL),
('112', '112', '28', 'restaurants', 'cover', NULL),
('113', '113', '29', 'restaurants', 'cover', NULL),
('114', '114', '29', 'restaurants', 'cover', NULL),
('115', '115', '29', 'restaurants', 'cover', NULL),
('116', '116', '29', 'restaurants', 'cover', NULL),
('117', '117', '1', 'users-permissions_user', 'picture', NULL),
('118', '118', '2', 'users-permissions_user', 'picture', NULL),
('119', '119', '3', 'users-permissions_user', 'picture', NULL),
('120', '120', '4', 'users-permissions_user', 'picture', NULL),
('121', '121', '5', 'users-permissions_user', 'picture', NULL),
('122', '122', '6', 'users-permissions_user', 'picture', NULL),
('123', '123', '7', 'users-permissions_user', 'picture', NULL),
('124', '124', '8', 'users-permissions_user', 'picture', NULL),
('125', '125', '9', 'users-permissions_user', 'picture', NULL),
('126', '126', '10', 'users-permissions_user', 'picture', NULL),
('127', '127', '11', 'users-permissions_user', 'picture', NULL),
('128', '128', '12', 'users-permissions_user', 'picture', NULL),
('129', '129', '13', 'users-permissions_user', 'picture', NULL),
('130', '130', '14', 'users-permissions_user', 'picture', NULL),
('131', '131', '15', 'users-permissions_user', 'picture', NULL),
('132', '132', '16', 'users-permissions_user', 'picture', NULL),
('133', '133', '17', 'users-permissions_user', 'picture', NULL),
('134', '134', '18', 'users-permissions_user', 'picture', NULL),
('135', '135', '19', 'users-permissions_user', 'picture', NULL),
('136', '136', '20', 'users-permissions_user', 'picture', NULL),
('137', '137', '21', 'users-permissions_user', 'picture', NULL),
('138', '138', '22', 'users-permissions_user', 'picture', NULL),
('139', '139', '23', 'users-permissions_user', 'picture', NULL),
('140', '140', '24', 'users-permissions_user', 'picture', NULL),
('141', '141', '25', 'users-permissions_user', 'picture', NULL),
('142', '142', '26', 'users-permissions_user', 'picture', NULL),
('143', '143', '27', 'users-permissions_user', 'picture', NULL),
('144', '144', '28', 'users-permissions_user', 'picture', NULL),
('145', '145', '29', 'users-permissions_user', 'picture', NULL),
('146', '146', '30', 'users-permissions_user', 'picture', NULL),
('147', '147', '31', 'users-permissions_user', 'picture', NULL),
('148', '148', '32', 'users-permissions_user', 'picture', NULL),
('149', '149', '33', 'users-permissions_user', 'picture', NULL),
('150', '150', '34', 'users-permissions_user', 'picture', NULL),
('151', '151', '35', 'users-permissions_user', 'picture', NULL),
('152', '152', '37', 'users-permissions_user', 'picture', NULL),
('153', '153', '36', 'users-permissions_user', 'picture', NULL),
('154', '154', '38', 'users-permissions_user', 'picture', NULL),
('155', '155', '39', 'users-permissions_user', 'picture', NULL),
('156', '156', '40', 'users-permissions_user', 'picture', NULL),
('157', '157', '41', 'users-permissions_user', 'picture', NULL),
('158', '158', '42', 'users-permissions_user', 'picture', NULL),
('159', '159', '43', 'users-permissions_user', 'picture', NULL),
('160', '160', '44', 'users-permissions_user', 'picture', NULL),
('161', '161', '45', 'users-permissions_user', 'picture', NULL),
('162', '162', '46', 'users-permissions_user', 'picture', NULL),
('163', '163', '47', 'users-permissions_user', 'picture', NULL),
('164', '164', '48', 'users-permissions_user', 'picture', NULL),
('165', '165', '49', 'users-permissions_user', 'picture', NULL),
('166', '166', '50', 'users-permissions_user', 'picture', NULL),
('167', '167', '51', 'users-permissions_user', 'picture', NULL),
('168', '168', '52', 'users-permissions_user', 'picture', NULL),
('169', '169', '53', 'users-permissions_user', 'picture', NULL),
('170', '170', '54', 'users-permissions_user', 'picture', NULL),
('171', '171', '55', 'users-permissions_user', 'picture', NULL),
('172', '172', '56', 'users-permissions_user', 'picture', NULL),
('173', '173', '57', 'users-permissions_user', 'picture', NULL),
('174', '174', '58', 'users-permissions_user', 'picture', NULL),
('175', '175', '59', 'users-permissions_user', 'picture', NULL),
('176', '176', '60', 'users-permissions_user', 'picture', NULL),
('177', '177', '61', 'users-permissions_user', 'picture', NULL),
('178', '178', '62', 'users-permissions_user', 'picture', NULL),
('180', '180', '64', 'users-permissions_user', 'picture', NULL),
('181', '181', '65', 'users-permissions_user', 'picture', NULL),
('182', '182', '66', 'users-permissions_user', 'picture', NULL),
('183', '183', '67', 'users-permissions_user', 'picture', NULL),
('184', '184', '68', 'users-permissions_user', 'picture', NULL),
('185', '185', '69', 'users-permissions_user', 'picture', NULL),
('186', '186', '70', 'users-permissions_user', 'picture', NULL),
('187', '187', '63', 'users-permissions_user', 'picture', NULL),
('188', '188', '71', 'users-permissions_user', 'picture', NULL),
('189', '189', '72', 'users-permissions_user', 'picture', NULL),
('190', '190', '73', 'users-permissions_user', 'picture', NULL),
('191', '191', '75', 'users-permissions_user', 'picture', NULL),
('192', '192', '76', 'users-permissions_user', 'picture', NULL),
('193', '193', '77', 'users-permissions_user', 'picture', NULL),
('194', '194', '78', 'users-permissions_user', 'picture', NULL),
('195', '195', '79', 'users-permissions_user', 'picture', NULL),
('196', '196', '80', 'users-permissions_user', 'picture', NULL),
('197', '197', '81', 'users-permissions_user', 'picture', NULL),
('198', '198', '82', 'users-permissions_user', 'picture', NULL),
('199', '199', '83', 'users-permissions_user', 'picture', NULL),
('200', '200', '84', 'users-permissions_user', 'picture', NULL),
('201', '201', '85', 'users-permissions_user', 'picture', NULL),
('202', '202', '86', 'users-permissions_user', 'picture', NULL),
('203', '203', '87', 'users-permissions_user', 'picture', NULL),
('204', '204', '88', 'users-permissions_user', 'picture', NULL),
('205', '205', '89', 'users-permissions_user', 'picture', NULL),
('206', '206', '90', 'users-permissions_user', 'picture', NULL),
('207', '207', '91', 'users-permissions_user', 'picture', NULL),
('208', '208', '92', 'users-permissions_user', 'picture', NULL),
('209', '209', '93', 'users-permissions_user', 'picture', NULL),
('210', '210', '94', 'users-permissions_user', 'picture', NULL),
('211', '211', '96', 'users-permissions_user', 'picture', NULL),
('212', '212', '95', 'users-permissions_user', 'picture', NULL),
('213', '213', '97', 'users-permissions_user', 'picture', NULL),
('214', '214', '98', 'users-permissions_user', 'picture', NULL),
('215', '215', '99', 'users-permissions_user', 'picture', NULL),
('216', '216', '100', 'users-permissions_user', 'picture', NULL),
('217', '217', '101', 'users-permissions_user', 'picture', NULL),
('218', '218', '1', 'components_about_us_headers', 'logo', '1');

INSERT INTO "users-permissions_permission" ("id", "type", "controller", "action", "enabled", "policy", "role") VALUES
('1', 'application', 'category', 'find', '1', '', '1'),
('2', 'application', 'category', 'findone', '1', '', '1'),
('3', 'application', 'category', 'count', '1', '', '1'),
('4', 'application', 'category', 'create', '1', '', '1'),
('5', 'application', 'category', 'update', '1', '', '1'),
('7', 'application', 'like', 'find', '1', '', '1'),
('8', 'application', 'like', 'findone', '1', '', '1'),
('9', 'application', 'like', 'count', '1', '', '1'),
('10', 'application', 'like', 'create', '1', '', '1'),
('11', 'application', 'like', 'update', '1', '', '1'),
('13', 'application', 'restaurant', 'find', '1', '', '1'),
('14', 'application', 'restaurant', 'findone', '1', '', '1'),
('15', 'application', 'restaurant', 'count', '1', '', '1'),
('16', 'application', 'restaurant', 'create', '1', '', '1'),
('17', 'application', 'restaurant', 'update', '1', '', '1'),
('19', 'application', 'review', 'find', '1', '', '1'),
('20', 'application', 'review', 'findone', '1', '', '1'),
('21', 'application', 'review', 'count', '1', '', '1'),
('22', 'application', 'review', 'create', '1', '', '1'),
('23', 'application', 'review', 'update', '1', '', '1'),
('26', 'content-manager', 'contentmanager', 'find', '1', '', '1'),
('27', 'content-manager', 'contentmanager', 'count', '1', '', '1'),
('28', 'content-manager', 'contentmanager', 'findone', '1', '', '1'),
('29', 'content-manager', 'contentmanager', 'create', '1', '', '1'),
('30', 'content-manager', 'contentmanager', 'update', '1', '', '1'),
('32', 'content-manager', 'contentmanager', 'delete', '1', '', '1'),
('42', 'email', 'email', 'send', '1', '', '1'),
('60', 'upload', 'upload', 'upload', '1', '', '1'),
('62', 'upload', 'upload', 'getsettings', '1', '', '1'),
('63', 'upload', 'upload', 'updatesettings', '1', '', '1'),
('64', 'upload', 'upload', 'find', '1', '', '1'),
('65', 'upload', 'upload', 'findone', '1', '', '1'),
('66', 'upload', 'upload', 'count', '1', '', '1'),
('67', 'upload', 'upload', 'destroy', '1', '', '1'),
('68', 'upload', 'upload', 'search', '1', '', '1'),
('69', 'users-permissions', 'auth', 'callback', '1', '', '1'),
('71', 'users-permissions', 'auth', 'connect', '1', '', '1'),
('72', 'users-permissions', 'auth', 'forgotpassword', '1', '', '1'),
('73', 'users-permissions', 'auth', 'register', '1', '', '1'),
('74', 'users-permissions', 'auth', 'emailconfirmation', '1', '', '1'),
('75', 'users-permissions', 'user', 'find', '1', '', '1'),
('76', 'users-permissions', 'user', 'me', '1', '', '1'),
('77', 'users-permissions', 'user', 'findone', '1', '', '1'),
('78', 'users-permissions', 'user', 'create', '1', '', '1'),
('79', 'users-permissions', 'user', 'update', '1', '', '1'),
('80', 'users-permissions', 'user', 'destroy', '1', '', '1'),
('81', 'users-permissions', 'user', 'destroyall', '1', '', '1'),
('82', 'users-permissions', 'userspermissions', 'createrole', '1', '', '1'),
('83', 'users-permissions', 'userspermissions', 'deleteprovider', '1', '', '1'),
('84', 'users-permissions', 'userspermissions', 'deleterole', '1', '', '1'),
('85', 'users-permissions', 'userspermissions', 'getpermissions', '1', '', '1'),
('86', 'users-permissions', 'userspermissions', 'getpolicies', '1', '', '1'),
('87', 'users-permissions', 'userspermissions', 'getrole', '1', '', '1'),
('88', 'users-permissions', 'userspermissions', 'getroles', '1', '', '1'),
('89', 'users-permissions', 'userspermissions', 'getroutes', '1', '', '1'),
('90', 'users-permissions', 'userspermissions', 'index', '1', '', '1'),
('91', 'users-permissions', 'userspermissions', 'init', '1', '', '1'),
('92', 'users-permissions', 'userspermissions', 'searchusers', '1', '', '1'),
('93', 'users-permissions', 'userspermissions', 'updaterole', '1', '', '1'),
('94', 'users-permissions', 'userspermissions', 'getemailtemplate', '1', '', '1'),
('95', 'users-permissions', 'userspermissions', 'updateemailtemplate', '1', '', '1'),
('96', 'users-permissions', 'userspermissions', 'getadvancedsettings', '1', '', '1'),
('97', 'users-permissions', 'userspermissions', 'updateadvancedsettings', '1', '', '1'),
('98', 'users-permissions', 'userspermissions', 'getproviders', '1', '', '1'),
('99', 'users-permissions', 'userspermissions', 'updateproviders', '1', '', '1'),
('100', 'application', 'category', 'find', '0', '', '2'),
('101', 'application', 'category', 'findone', '0', '', '2'),
('102', 'application', 'category', 'count', '0', '', '2'),
('103', 'application', 'category', 'create', '0', '', '2'),
('104', 'application', 'category', 'update', '0', '', '2'),
('106', 'application', 'like', 'find', '0', '', '2'),
('107', 'application', 'like', 'findone', '0', '', '2'),
('108', 'application', 'like', 'count', '0', '', '2'),
('109', 'application', 'like', 'create', '1', '', '2'),
('110', 'application', 'like', 'update', '0', '', '2'),
('112', 'application', 'restaurant', 'find', '1', '', '2'),
('113', 'application', 'restaurant', 'findone', '0', '', '2'),
('114', 'application', 'restaurant', 'count', '0', '', '2'),
('115', 'application', 'restaurant', 'create', '0', '', '2'),
('116', 'application', 'restaurant', 'update', '0', '', '2'),
('118', 'application', 'review', 'find', '0', '', '2'),
('119', 'application', 'review', 'findone', '0', '', '2'),
('120', 'application', 'review', 'count', '0', '', '2'),
('121', 'application', 'review', 'create', '1', '', '2'),
('122', 'application', 'review', 'update', '0', '', '2'),
('125', 'content-manager', 'contentmanager', 'find', '0', '', '2'),
('126', 'content-manager', 'contentmanager', 'count', '0', '', '2'),
('127', 'content-manager', 'contentmanager', 'findone', '0', '', '2'),
('128', 'content-manager', 'contentmanager', 'create', '0', '', '2'),
('129', 'content-manager', 'contentmanager', 'update', '0', '', '2'),
('131', 'content-manager', 'contentmanager', 'delete', '0', '', '2'),
('141', 'email', 'email', 'send', '0', '', '2'),
('159', 'upload', 'upload', 'upload', '0', '', '2'),
('161', 'upload', 'upload', 'getsettings', '0', '', '2'),
('162', 'upload', 'upload', 'updatesettings', '0', '', '2'),
('163', 'upload', 'upload', 'find', '0', '', '2'),
('164', 'upload', 'upload', 'findone', '0', '', '2'),
('165', 'upload', 'upload', 'count', '0', '', '2'),
('166', 'upload', 'upload', 'destroy', '0', '', '2'),
('167', 'upload', 'upload', 'search', '0', '', '2'),
('168', 'users-permissions', 'auth', 'callback', '0', '', '2'),
('170', 'users-permissions', 'auth', 'connect', '1', '', '2'),
('171', 'users-permissions', 'auth', 'forgotpassword', '0', '', '2'),
('172', 'users-permissions', 'auth', 'register', '0', '', '2'),
('173', 'users-permissions', 'auth', 'emailconfirmation', '0', '', '2'),
('174', 'users-permissions', 'user', 'find', '0', '', '2'),
('175', 'users-permissions', 'user', 'me', '1', '', '2'),
('176', 'users-permissions', 'user', 'findone', '0', '', '2'),
('177', 'users-permissions', 'user', 'create', '0', '', '2'),
('178', 'users-permissions', 'user', 'update', '0', '', '2'),
('179', 'users-permissions', 'user', 'destroy', '0', '', '2'),
('180', 'users-permissions', 'user', 'destroyall', '0', '', '2'),
('181', 'users-permissions', 'userspermissions', 'createrole', '0', '', '2'),
('182', 'users-permissions', 'userspermissions', 'deleteprovider', '0', '', '2'),
('183', 'users-permissions', 'userspermissions', 'deleterole', '0', '', '2'),
('184', 'users-permissions', 'userspermissions', 'getpermissions', '0', '', '2'),
('185', 'users-permissions', 'userspermissions', 'getpolicies', '0', '', '2'),
('186', 'users-permissions', 'userspermissions', 'getrole', '0', '', '2'),
('187', 'users-permissions', 'userspermissions', 'getroles', '0', '', '2'),
('188', 'users-permissions', 'userspermissions', 'getroutes', '0', '', '2'),
('189', 'users-permissions', 'userspermissions', 'index', '0', '', '2'),
('190', 'users-permissions', 'userspermissions', 'init', '1', '', '2'),
('191', 'users-permissions', 'userspermissions', 'searchusers', '0', '', '2'),
('192', 'users-permissions', 'userspermissions', 'updaterole', '0', '', '2'),
('193', 'users-permissions', 'userspermissions', 'getemailtemplate', '0', '', '2'),
('194', 'users-permissions', 'userspermissions', 'updateemailtemplate', '0', '', '2'),
('195', 'users-permissions', 'userspermissions', 'getadvancedsettings', '0', '', '2'),
('196', 'users-permissions', 'userspermissions', 'updateadvancedsettings', '0', '', '2'),
('197', 'users-permissions', 'userspermissions', 'getproviders', '0', '', '2'),
('198', 'users-permissions', 'userspermissions', 'updateproviders', '0', '', '2'),
('199', 'application', 'category', 'find', '1', '', '3'),
('200', 'application', 'category', 'findone', '1', '', '3'),
('201', 'application', 'category', 'count', '0', '', '3'),
('202', 'application', 'category', 'create', '0', '', '3'),
('203', 'application', 'category', 'update', '0', '', '3'),
('205', 'application', 'like', 'find', '1', '', '3'),
('206', 'application', 'like', 'findone', '1', '', '3'),
('207', 'application', 'like', 'count', '0', '', '3'),
('208', 'application', 'like', 'create', '0', '', '3'),
('209', 'application', 'like', 'update', '0', '', '3'),
('211', 'application', 'restaurant', 'find', '1', '', '3'),
('212', 'application', 'restaurant', 'findone', '1', '', '3'),
('213', 'application', 'restaurant', 'count', '0', '', '3'),
('214', 'application', 'restaurant', 'create', '0', '', '3'),
('215', 'application', 'restaurant', 'update', '0', '', '3'),
('217', 'application', 'review', 'find', '1', '', '3'),
('218', 'application', 'review', 'findone', '1', '', '3'),
('219', 'application', 'review', 'count', '0', '', '3'),
('220', 'application', 'review', 'create', '0', '', '3'),
('221', 'application', 'review', 'update', '0', '', '3'),
('224', 'content-manager', 'contentmanager', 'find', '0', '', '3'),
('225', 'content-manager', 'contentmanager', 'count', '0', '', '3'),
('226', 'content-manager', 'contentmanager', 'findone', '0', '', '3'),
('227', 'content-manager', 'contentmanager', 'create', '0', '', '3'),
('228', 'content-manager', 'contentmanager', 'update', '0', '', '3'),
('230', 'content-manager', 'contentmanager', 'delete', '0', '', '3'),
('240', 'email', 'email', 'send', '0', '', '3'),
('258', 'upload', 'upload', 'upload', '0', '', '3'),
('260', 'upload', 'upload', 'getsettings', '0', '', '3'),
('261', 'upload', 'upload', 'updatesettings', '0', '', '3'),
('262', 'upload', 'upload', 'find', '0', '', '3'),
('263', 'upload', 'upload', 'findone', '0', '', '3'),
('264', 'upload', 'upload', 'count', '0', '', '3'),
('265', 'upload', 'upload', 'destroy', '0', '', '3'),
('266', 'upload', 'upload', 'search', '0', '', '3'),
('267', 'users-permissions', 'auth', 'callback', '1', '', '3'),
('269', 'users-permissions', 'auth', 'connect', '1', '', '3'),
('270', 'users-permissions', 'auth', 'forgotpassword', '1', '', '3'),
('271', 'users-permissions', 'auth', 'register', '1', '', '3'),
('272', 'users-permissions', 'auth', 'emailconfirmation', '1', '', '3'),
('273', 'users-permissions', 'user', 'find', '0', '', '3'),
('274', 'users-permissions', 'user', 'me', '1', '', '3'),
('275', 'users-permissions', 'user', 'findone', '0', '', '3'),
('276', 'users-permissions', 'user', 'create', '0', '', '3'),
('277', 'users-permissions', 'user', 'update', '0', '', '3'),
('278', 'users-permissions', 'user', 'destroy', '0', '', '3'),
('279', 'users-permissions', 'user', 'destroyall', '0', '', '3'),
('280', 'users-permissions', 'userspermissions', 'createrole', '0', '', '3'),
('281', 'users-permissions', 'userspermissions', 'deleteprovider', '0', '', '3'),
('282', 'users-permissions', 'userspermissions', 'deleterole', '0', '', '3'),
('283', 'users-permissions', 'userspermissions', 'getpermissions', '0', '', '3'),
('284', 'users-permissions', 'userspermissions', 'getpolicies', '0', '', '3'),
('285', 'users-permissions', 'userspermissions', 'getrole', '0', '', '3'),
('286', 'users-permissions', 'userspermissions', 'getroles', '0', '', '3'),
('287', 'users-permissions', 'userspermissions', 'getroutes', '0', '', '3'),
('288', 'users-permissions', 'userspermissions', 'index', '0', '', '3'),
('289', 'users-permissions', 'userspermissions', 'init', '1', '', '3'),
('290', 'users-permissions', 'userspermissions', 'searchusers', '0', '', '3'),
('291', 'users-permissions', 'userspermissions', 'updaterole', '0', '', '3'),
('292', 'users-permissions', 'userspermissions', 'getemailtemplate', '0', '', '3'),
('293', 'users-permissions', 'userspermissions', 'updateemailtemplate', '0', '', '3'),
('294', 'users-permissions', 'userspermissions', 'getadvancedsettings', '0', '', '3'),
('295', 'users-permissions', 'userspermissions', 'updateadvancedsettings', '0', '', '3'),
('296', 'users-permissions', 'userspermissions', 'getproviders', '0', '', '3'),
('297', 'users-permissions', 'userspermissions', 'updateproviders', '0', '', '3'),
('298', 'application', 'category', 'delete', '0', '', '1'),
('299', 'application', 'like', 'delete', '0', '', '1'),
('300', 'application', 'restaurant', 'delete', '0', '', '1'),
('301', 'application', 'review', 'delete', '0', '', '1'),
('302', 'content-manager', 'contentmanager', 'deletemany', '0', '', '1'),
('303', 'content-manager', 'contenttypes', 'listcontenttypes', '0', '', '1'),
('304', 'content-manager', 'contenttypes', 'findcontenttype', '0', '', '1'),
('305', 'content-manager', 'contenttypes', 'updatecontenttype', '0', '', '1'),
('316', 'documentation', 'documentation', 'getinfos', '0', '', '1'),
('317', 'documentation', 'documentation', 'index', '0', '', '1'),
('318', 'documentation', 'documentation', 'loginview', '0', '', '1'),
('319', 'documentation', 'documentation', 'login', '0', '', '1'),
('320', 'documentation', 'documentation', 'regeneratedoc', '0', '', '1'),
('321', 'documentation', 'documentation', 'deletedoc', '0', '', '1'),
('322', 'documentation', 'documentation', 'updatesettings', '0', '', '1'),
('323', 'application', 'category', 'delete', '0', '', '2'),
('324', 'application', 'like', 'delete', '0', '', '2'),
('325', 'application', 'restaurant', 'delete', '0', '', '2'),
('326', 'application', 'review', 'delete', '0', '', '2'),
('327', 'content-manager', 'contentmanager', 'deletemany', '0', '', '2'),
('328', 'content-manager', 'contenttypes', 'listcontenttypes', '0', '', '2'),
('329', 'content-manager', 'contenttypes', 'findcontenttype', '0', '', '2'),
('330', 'content-manager', 'contenttypes', 'updatecontenttype', '0', '', '2'),
('341', 'documentation', 'documentation', 'getinfos', '0', '', '2'),
('342', 'documentation', 'documentation', 'index', '0', '', '2'),
('343', 'documentation', 'documentation', 'loginview', '0', '', '2'),
('344', 'documentation', 'documentation', 'login', '0', '', '2'),
('345', 'documentation', 'documentation', 'regeneratedoc', '0', '', '2'),
('346', 'documentation', 'documentation', 'deletedoc', '0', '', '2'),
('347', 'documentation', 'documentation', 'updatesettings', '0', '', '2'),
('348', 'application', 'category', 'delete', '0', '', '3'),
('349', 'application', 'like', 'delete', '0', '', '3'),
('350', 'application', 'restaurant', 'delete', '0', '', '3'),
('351', 'application', 'review', 'delete', '0', '', '3'),
('352', 'content-manager', 'contentmanager', 'deletemany', '0', '', '3'),
('353', 'content-manager', 'contenttypes', 'listcontenttypes', '0', '', '3'),
('354', 'content-manager', 'contenttypes', 'findcontenttype', '0', '', '3'),
('355', 'content-manager', 'contenttypes', 'updatecontenttype', '0', '', '3'),
('366', 'documentation', 'documentation', 'getinfos', '0', '', '3'),
('367', 'documentation', 'documentation', 'index', '0', '', '3'),
('368', 'documentation', 'documentation', 'loginview', '0', '', '3'),
('369', 'documentation', 'documentation', 'login', '0', '', '3'),
('370', 'documentation', 'documentation', 'regeneratedoc', '0', '', '3'),
('371', 'documentation', 'documentation', 'deletedoc', '0', '', '3'),
('372', 'documentation', 'documentation', 'updatesettings', '0', '', '3'),
('373', 'content-manager', 'components', 'listcomponents', '0', '', '1'),
('374', 'content-manager', 'components', 'findcomponent', '0', '', '1'),
('375', 'content-manager', 'components', 'updatecomponent', '0', '', '1'),
('376', 'content-type-builder', 'componentcategories', 'editcategory', '0', '', '1'),
('377', 'content-type-builder', 'componentcategories', 'deletecategory', '0', '', '1'),
('378', 'content-type-builder', 'components', 'getcomponents', '0', '', '1'),
('379', 'content-type-builder', 'components', 'getcomponent', '0', '', '1'),
('380', 'content-type-builder', 'components', 'createcomponent', '0', '', '1'),
('381', 'content-type-builder', 'components', 'updatecomponent', '0', '', '1'),
('382', 'content-type-builder', 'components', 'deletecomponent', '0', '', '1'),
('383', 'content-type-builder', 'connections', 'getconnections', '0', '', '1'),
('384', 'content-type-builder', 'contenttypes', 'getcontenttypes', '0', '', '1'),
('385', 'content-type-builder', 'contenttypes', 'getcontenttype', '0', '', '1'),
('386', 'content-type-builder', 'contenttypes', 'createcontenttype', '0', '', '1'),
('387', 'content-type-builder', 'contenttypes', 'updatecontenttype', '0', '', '1'),
('388', 'content-type-builder', 'contenttypes', 'deletecontenttype', '0', '', '1'),
('389', 'users-permissions', 'auth', 'sendemailconfirmation', '0', '', '1'),
('390', 'content-manager', 'components', 'listcomponents', '0', '', '2'),
('391', 'content-manager', 'components', 'findcomponent', '0', '', '2'),
('392', 'content-manager', 'components', 'updatecomponent', '0', '', '2'),
('393', 'content-type-builder', 'componentcategories', 'editcategory', '0', '', '2'),
('394', 'content-type-builder', 'componentcategories', 'deletecategory', '0', '', '2'),
('395', 'content-type-builder', 'components', 'getcomponents', '0', '', '2'),
('396', 'content-type-builder', 'components', 'getcomponent', '0', '', '2'),
('397', 'content-type-builder', 'components', 'createcomponent', '0', '', '2'),
('398', 'content-type-builder', 'components', 'updatecomponent', '0', '', '2'),
('399', 'content-type-builder', 'components', 'deletecomponent', '0', '', '2'),
('400', 'content-type-builder', 'connections', 'getconnections', '0', '', '2'),
('401', 'content-type-builder', 'contenttypes', 'getcontenttypes', '0', '', '2'),
('402', 'content-type-builder', 'contenttypes', 'getcontenttype', '0', '', '2'),
('403', 'content-type-builder', 'contenttypes', 'createcontenttype', '0', '', '2'),
('404', 'content-type-builder', 'contenttypes', 'updatecontenttype', '0', '', '2'),
('405', 'content-type-builder', 'contenttypes', 'deletecontenttype', '0', '', '2'),
('406', 'users-permissions', 'auth', 'sendemailconfirmation', '0', '', '2'),
('407', 'content-manager', 'components', 'listcomponents', '0', '', '3'),
('408', 'content-manager', 'components', 'findcomponent', '0', '', '3'),
('409', 'content-manager', 'components', 'updatecomponent', '0', '', '3'),
('410', 'content-type-builder', 'componentcategories', 'editcategory', '0', '', '3'),
('411', 'content-type-builder', 'componentcategories', 'deletecategory', '0', '', '3'),
('412', 'content-type-builder', 'components', 'getcomponents', '0', '', '3'),
('413', 'content-type-builder', 'components', 'getcomponent', '0', '', '3'),
('414', 'content-type-builder', 'components', 'createcomponent', '0', '', '3'),
('415', 'content-type-builder', 'components', 'updatecomponent', '0', '', '3'),
('416', 'content-type-builder', 'components', 'deletecomponent', '0', '', '3'),
('417', 'content-type-builder', 'connections', 'getconnections', '0', '', '3'),
('418', 'content-type-builder', 'contenttypes', 'getcontenttypes', '0', '', '3'),
('419', 'content-type-builder', 'contenttypes', 'getcontenttype', '0', '', '3'),
('420', 'content-type-builder', 'contenttypes', 'createcontenttype', '0', '', '3'),
('421', 'content-type-builder', 'contenttypes', 'updatecontenttype', '0', '', '3'),
('422', 'content-type-builder', 'contenttypes', 'deletecontenttype', '0', '', '3'),
('423', 'users-permissions', 'auth', 'sendemailconfirmation', '0', '', '3'),
('424', 'application', 'about-us', 'delete', '0', '', '1'),
('425', 'application', 'about-us', 'delete', '0', '', '2'),
('426', 'application', 'about-us', 'delete', '0', '', '3'),
('427', 'application', 'about-us', 'find', '0', '', '1'),
('428', 'application', 'about-us', 'find', '0', '', '2'),
('429', 'application', 'about-us', 'find', '0', '', '3'),
('430', 'application', 'about-us', 'update', '0', '', '1'),
('431', 'application', 'about-us', 'update', '0', '', '2'),
('432', 'application', 'about-us', 'update', '0', '', '3'),
('433', 'content-manager', 'contentmanager', 'checkuidavailability', '0', '', '1'),
('434', 'content-manager', 'contentmanager', 'checkuidavailability', '0', '', '2'),
('435', 'content-manager', 'contentmanager', 'checkuidavailability', '0', '', '3'),
('436', 'content-manager', 'contentmanager', 'generateuid', '0', '', '1'),
('437', 'content-manager', 'contentmanager', 'generateuid', '0', '', '2'),
('438', 'content-manager', 'contentmanager', 'generateuid', '0', '', '3'),
('439', 'content-type-builder', 'builder', 'getreservednames', '0', '', '1'),
('440', 'content-type-builder', 'builder', 'getreservednames', '0', '', '2'),
('441', 'content-type-builder', 'builder', 'getreservednames', '0', '', '3'),
('442', 'upload', 'proxy', 'uploadproxy', '0', '', '1'),
('443', 'upload', 'proxy', 'uploadproxy', '0', '', '2'),
('444', 'upload', 'proxy', 'uploadproxy', '0', '', '3'),
('445', 'users-permissions', 'auth', 'resetpassword', '0', '', '1'),
('446', 'users-permissions', 'auth', 'resetpassword', '0', '', '2'),
('447', 'users-permissions', 'auth', 'resetpassword', '0', '', '3'),
('448', 'users-permissions', 'user', 'count', '0', '', '1'),
('449', 'users-permissions', 'user', 'count', '0', '', '2'),
('450', 'users-permissions', 'user', 'count', '0', '', '3');

INSERT INTO "users-permissions_role" ("id", "name", "description", "type") VALUES
('1', 'Administrator', 'These users have all access in the project.', 'root'),
('2', 'Authenticated', 'Default role given to authenticated user.', 'authenticated'),
('3', 'Public', 'Default role given to unauthenticated user.', 'public');

INSERT INTO "users-permissions_user" ("id", "username", "email", "provider", "password", "resetPasswordToken", "confirmed", "blocked", "role", "created_at", "updated_at") VALUES
('1', 'Accrada', 'accrada@gmail.com', 'local', '$2a$10$aKhCBsrCJ9YZTVzQdsZldeL6fjkBkpEN9KpJFaWUwU1SwLJFxq/Y.', NULL, NULL, NULL, '2', NULL, NULL),
('2', 'tuskangles', 'tuskangles@gmail.com', 'local', '$2a$10$BHELBvaA5j/8IBncz4zgd.t2npkgmc9N7B5sI92FaNZnX6P8wLIze', NULL, NULL, NULL, '2', NULL, NULL),
('3', 'planechange', 'planechange@gmail.com', 'local', '$2a$10$PH/6/owJDxrx.HDImjLjQOoREeWkAPCNqsQWxvkFlvc9T4RHWiuGO', NULL, NULL, NULL, '2', NULL, NULL),
('4', 'deskointment', 'deskointment@gmail.com', 'local', '$2a$10$bm4ytA3Unu32dFBD.FCJ.OZmvKYdrWFPSZLUNeAs0Cd7Vk9lfm2qm', NULL, NULL, NULL, '2', NULL, NULL),
('5', 'rumblecullionly', 'rumblecullionly@gmail.com', 'local', '$2a$10$k3hTjNHtt5SdDUHAmufiLew9wqKr0rDbrcfbLzU/V1P6EnNT2KhGO', NULL, NULL, NULL, '2', NULL, NULL),
('6', 'vengefulcofferdam', 'vengefulcofferdam@gmail.com', 'local', '$2a$10$nWv9i07xOvlFM2W2lAoYs.wbS2MXisCBGIztRUkW7t9X.1u3pdX6m', NULL, NULL, NULL, '2', NULL, NULL),
('7', 'crumbedacetone', 'crumbedacetone@gmail.com', 'local', '$2a$10$wPfzrxkGmJnv3YIMjPj2TOvCFdLZpWRDNCPXoFqYvOHDDTmXPX8Ye', NULL, NULL, NULL, '2', NULL, NULL),
('8', 'hamstringdusk', 'hamstringdusk@gmail.com', 'local', '$2a$10$zfStpFvuq/t2IlDTRuE0K.qDvC5855K.NCETQKxSoG.3UhG3tRU3e', NULL, NULL, NULL, '2', NULL, NULL),
('9', 'bubblegumirritating', 'bubblegumirritating@gmail.com', 'local', '$2a$10$KUmsUWoDCGW5VKrg378OiOn09wE4ZrzhegP.wcKpFlgfJ4TzTJONy', NULL, NULL, NULL, '2', NULL, NULL),
('10', 'cablebroad', 'cablebroad@gmail.com', 'local', '$2a$10$jMA.RxmJ4iyqLv2bUZgj4enqiz.u7IUKlyqykscUIxJhGjmxujM/m', NULL, NULL, NULL, '2', NULL, NULL),
('11', 'lostriggcreatures', 'lostriggcreatures@gmail.com', 'local', '$2a$10$FjK0parx029Dg7lvftd/kuSkIU/ik/bleGvDXodFl/E6J7VygQgZe', NULL, NULL, NULL, '2', NULL, NULL),
('12', 'wimpgland', 'wimpgland@gmail.com', 'local', '$2a$10$kOKWl5tiA4n8.6/lN9xYe.MIK5JPwd21c9NnfO0TvFupNdoO21eKu', NULL, NULL, NULL, '2', NULL, NULL),
('13', 'leukocyteahead', 'leukocyteahead@gmail.com', 'local', '$2a$10$wMCA/v8h3Fa/N6h3TtI0XeL8reRTwUh0RSb8OFCFi4Pbnhbq9gpi2', NULL, NULL, NULL, '2', NULL, NULL),
('14', 'pryelflock', 'pryelflock@gmail.com', 'local', '$2a$10$jg.MJUzLZbjhvsncDC5v.e/78DBdWpjxAMnEE89qM6itYj3h1/B5e', NULL, NULL, NULL, '2', NULL, NULL),
('15', 'jemmybasket', 'jemmybasket@gmail.com', 'local', '$2a$10$NKFXISttaPqIMQFHpNyvKOcKKro9eicK5.NYoWxrGe43R0BEG9D6y', NULL, NULL, NULL, '2', NULL, NULL),
('16', 'lankycalifornium', 'lankycalifornium@gmail.com', 'local', '$2a$10$VyfUPM9toRs5jVVOPUG6POuFCJr.uGjG0B5.w1eekxuz251Txy7GC', NULL, NULL, NULL, '2', NULL, NULL),
('17', 'loyununtrium', 'loyununtrium@gmail.com', 'local', '$2a$10$ds6U6aqB9HR4mH4K5tI3UOCniql2SEYM6NYu5sR20vv/XfiB0h6yO', NULL, NULL, NULL, '2', NULL, NULL),
('18', 'sentencemour', 'sentencemour@gmail.com', 'local', '$2a$10$ejzinfvH8XZ3.tQWkTqTkOpDJtt1tDU9ppfNKsECia1jkFkCB1x1.', NULL, NULL, NULL, '2', NULL, NULL),
('19', 'steersmancovet', 'steersmancovet@gmail.com', 'local', '$2a$10$lE5PB4IOVSacZoLrejHqceMTZJBYW9bqqMbOu0t5/Wb9hzTt3G9M.', NULL, NULL, NULL, '2', NULL, NULL),
('20', 'lateraldysprosium', 'lateraldysprosium@gmail.com', 'local', '$2a$10$8wLpm2ix4i09ChM6xTVcE.VJCEPgcVo/9jHAxaQ9JcanTOgqcxnIm', NULL, NULL, NULL, '2', NULL, NULL),
('21', 'analystzany', 'analystzany@gmail.com', 'local', '$2a$10$f6KQVGgB3Y1STSbc1Lkw9eMDNncHQUecnEjWUjs1UI9oLvdjEyzJm', NULL, NULL, NULL, '2', NULL, NULL),
('22', 'ongiving', 'ongiving@gmail.com', 'local', '$2a$10$xKacH7vESbSduOrPmY2.wOhS8I4T8hoWJ8nbW3I2bZ.gXb5/XsPky', NULL, NULL, NULL, '2', NULL, NULL),
('23', 'namakatext', 'namakatext@gmail.com', 'local', '$2a$10$iZlhQMg6A6epy05DymlCh.9AHhopE78.BAw2a2eBAdjO2LeWqPWEW', NULL, NULL, NULL, '2', NULL, NULL),
('24', 'beardlint', 'beardlint@gmail.com', 'local', '$2a$10$SEorsB2Ofdk/aMOu.RkvTOXZDxX52gnjth.Q3heVpF5uD25qXa61i', NULL, NULL, NULL, '2', NULL, NULL),
('25', 'wideeyedtroupe', 'wideeyedtroupe@gmail.com', 'local', '$2a$10$nj7JRjBA.ekc6iMaJ6alJORRHdingI6G.dgSDRiBd1BccFktGdNjO', NULL, NULL, NULL, '2', NULL, NULL),
('26', 'berkrounding', 'berkrounding@gmail.com', 'local', '$2a$10$PLX3GB8oUvgU8AIjt3qgU.gUSrH7.bHG9i1XGI7kNiOCsifCMBdJy', NULL, NULL, NULL, '2', NULL, NULL),
('27', 'presentalias', 'presentalias@gmail.com', 'local', '$2a$10$BZdAZQn9QFOVvv40qXKvqubA..RiKpI7LnMFwJCSMoacpxOHA7D0m', NULL, NULL, NULL, '2', NULL, NULL),
('28', 'footmanresurrect', 'footmanresurrect@gmail.com', 'local', '$2a$10$vCx3iq4FrwOmiNCLIh5hheFiQpAD5Lf5D0Ma1OD/6c.xfhqaYUpNC', NULL, NULL, NULL, '2', NULL, NULL),
('29', 'swingerallegiance', 'swingerallegiance@gmail.com', 'local', '$2a$10$zzTQNpfyhphUtRuUQVXa.uJUD34PTHcClnz7IRf4cGjTp8uE0puUS', NULL, NULL, NULL, '2', NULL, NULL),
('30', 'matlabregain', 'matlabregain@gmail.com', 'local', '$2a$10$..9wMzA1HJulcHBe5xDMhOIa66Wb5Z0Lz1qwALZeZQgjwcrLN0sja', NULL, NULL, NULL, '2', NULL, NULL),
('31', 'catchabledramatic', 'catchabledramatic@gmail.com', 'local', '$2a$10$DehWWl97Dif4hePaKWykJekAciNyQD7Pgiuhp7s9fARmxsn6IGB7y', NULL, NULL, NULL, '2', NULL, NULL),
('32', 'doinghorns', 'doinghorns@gmail.com', 'local', '$2a$10$3rmoIpirreiciW1Z5ag1hOb3O7nQa9.2.Lz0IMssdSzrUjCowrmaG', NULL, NULL, NULL, '2', NULL, NULL),
('33', 'naptrunc', 'naptrunc@gmail.com', 'local', '$2a$10$rvwBwr0qm5Dq3Mo5cPG0ve3BHVlzL5cdKAzVjmQwIFaYFZb0GTCbm', NULL, NULL, NULL, '2', NULL, NULL),
('34', 'phonepigjump', 'phonepigjump@gmail.com', 'local', '$2a$10$/wmEdBFCRfsQHonptJHPaePeDKwgExkNGUyFmf9D1K5KJV/bKg8W2', NULL, NULL, NULL, '2', NULL, NULL),
('35', 'lushlyexcretion', 'lushlyexcretion@gmail.com', 'local', '$2a$10$g1U9bz7qlH5KDjqi3CY.kenIFaKoHENdtauFRiQzwLkF0BI8Wo106', NULL, NULL, NULL, '2', NULL, NULL),
('36', 'downloadcivil', 'downloadcivil@gmail.com', 'local', '$2a$10$uwrxpHo6W2xBMcFq0TF0wu0KAhUhhBMaf/j4uoS/pKqTpmRgzKIoO', NULL, NULL, NULL, '2', NULL, NULL),
('37', 'carbonrecast', 'carbonrecast@gmail.com', 'local', '$2a$10$GbcYJksD9ziaYgeVOIs.kelMYymw4TXHQrCJhLKo2n8s1sFoe4OxS', NULL, NULL, NULL, '2', NULL, NULL),
('38', 'omissibletashing', 'omissibletashing@gmail.com', 'local', '$2a$10$oqBo6tmUza/S8FQF4DI6O.c207Y0Va4W2w1Jw2LOSxrPqcvb.DP0.', NULL, NULL, NULL, '2', NULL, NULL),
('39', 'puppyprint', 'puppyprint@gmail.com', 'local', '$2a$10$PNtAZujiyYEoerrvUmmQL.XnWUywEVn0.15MjeeKoOACYO6OOC5ze', NULL, NULL, NULL, '2', NULL, NULL),
('40', 'yappingclassroom', 'yappingclassroom@gmail.com', 'local', '$2a$10$IYHiuU4WtACt18ETOa1ckOLe5PNg70fBPVXC8hwHam4.iJ6Gc.9CG', NULL, NULL, NULL, '2', NULL, NULL),
('41', 'remoteessential', 'remoteessential@gmail.com', 'local', '$2a$10$Jz69p6s7ftIhqwGBkzbHF.W/nhioCB9iQ/a.rpqCNIantIm1.XI.u', NULL, NULL, NULL, '2', NULL, NULL),
('42', 'tramuninsured', 'tramuninsured@gmail.com', 'local', '$2a$10$VxtVf89P.d4iUfoNiVKk3.xl1UEZPdgS/S9VWETdyJ9muKd9APIKm', NULL, NULL, NULL, '2', NULL, NULL),
('43', 'flaskreluctant', 'flaskreluctant@gmail.com', 'local', '$2a$10$O8KD6RJd25i30UWGzIeU6.KzO6EBZwscKWNxlNCRlDgFfxT/MYFhe', NULL, NULL, NULL, '2', NULL, NULL),
('44', 'outeractivity', 'outeractivity@gmail.com', 'local', '$2a$10$3QdxBamfsqTrq/U.KA8UN.fzO1OQTgSSBwQZt2wfYSwvBynYM21O.', NULL, NULL, NULL, '2', NULL, NULL),
('45', 'xeroxchest', 'xeroxchest@gmail.com', 'local', '$2a$10$iwR3uM.3hEPU3BotZsoMO.7f1aHmkr855YxZL1QVFD8ENhdXyU/wC', NULL, NULL, NULL, '2', NULL, NULL),
('46', 'hastinesslength', 'hastinesslength@gmail.com', 'local', '$2a$10$ECu8SxAcWKTXqaDTDiPGWOJ88ntFuqFgOhrY54UrXtIYgSSCVg6He', NULL, NULL, NULL, '2', NULL, NULL),
('47', 'snowdropkooky', 'snowdropkooky@gmail.com', 'local', '$2a$10$1n3VE3ZgEAQ1HgZ0rD57c.sn.imZqTQ0194MtAECkmP9ZC3lWAEsm', NULL, NULL, NULL, '2', NULL, NULL),
('48', 'sodatokens', 'sodatokens@gmail.com', 'local', '$2a$10$Q/xN7PfrBidtKDQL1sOpm.s03p2HRS./24rl04mzDUfiVHlPIyYxK', NULL, NULL, NULL, '2', NULL, NULL),
('49', 'unfastenwelcome', 'unfastenwelcome@gmail.com', 'local', '$2a$10$NqGSi3A6V2slHoN.4CmIdeYqZRIukOSJ2UBA4Z3V0dMYEcYVvQ5kO', NULL, NULL, NULL, '2', NULL, NULL),
('50', 'hardhatcowsic', 'hardhatcowsic@gmail.com', 'local', '$2a$10$DpvzeOCdUzdNb7wzB1xKPu3l07SBZ9vHkUBfHAUWrlyVVFj6CBYYO', NULL, NULL, NULL, '2', NULL, NULL),
('51', 'matinguneaten', 'matinguneaten@gmail.com', 'local', '$2a$10$klLj1Q.Y9zpcnHeXfBlIX.2Agxxb9LbrzxmMLKv3Dt38//fI92m/6', NULL, NULL, NULL, '2', NULL, NULL),
('52', 'prongnuptials', 'prongnuptials@gmail.com', 'local', '$2a$10$Hjs4.SpFDTERdNyFMd/WkuaQMwWcHzvBqVGXPy7Le4Ec81GY.zMwK', NULL, NULL, NULL, '2', NULL, NULL),
('53', 'snappingcucumber', 'snappingcucumber@gmail.com', 'local', '$2a$10$LiTlEWlWcKQxxWT3kJAHduUvV8U5gIp.mFPnU7cIbsw.OijB0plFa', NULL, NULL, NULL, '2', NULL, NULL),
('54', 'jacksuperbowl', 'jacksuperbowl@gmail.com', 'local', '$2a$10$wBgtFKkPDBFowMKIhsf3pOPIOR41ZnxsxgIQBsjgTZBBol7xtYmmi', NULL, NULL, NULL, '2', NULL, NULL),
('55', 'choatgag', 'choatgag@gmail.com', 'local', '$2a$10$g2TFGfHYbH2/VcPCJi2sEuRytdwF/mo1D76AHpzxxscU4kw/GnX3e', NULL, NULL, NULL, '2', NULL, NULL),
('56', 'timingmaintain', 'timingmaintain@gmail.com', 'local', '$2a$10$qLzLK7E8rNzEMdQ.iE2hr.TkASMjwGVaHZ5l7qvNgL0hdJMrg2Udi', NULL, NULL, NULL, '2', NULL, NULL),
('57', 'criticismdeport', 'criticismdeport@gmail.com', 'local', '$2a$10$AXKLO9fsJyRAf42x4wjwee1ru5F40Dbj2MkExlP0XgVpOEyAeJKyS', NULL, NULL, NULL, '2', NULL, NULL),
('58', 'nativesun', 'nativesun@gmail.com', 'local', '$2a$10$H/VH.uF3xnp1BoT9xBArYehAwUSiE6nwI5xiXCbVUmH51g/4xk3Ya', NULL, NULL, NULL, '2', NULL, NULL),
('59', 'biologysoup', 'biologysoup@gmail.com', 'local', '$2a$10$6OZjcW01uVOy7/6MhE6VTeL0o8ZrUhFCgUZm.OJLraZU4EsyQUAc6', NULL, NULL, NULL, '2', NULL, NULL),
('60', 'thawculture', 'thawculture@gmail.com', 'local', '$2a$10$6sYeXuhFOdZQVpL99Oy.LeQXDOodtEhaWC9YYQn3KMqxAJxnWYpJG', NULL, NULL, NULL, '2', NULL, NULL),
('61', 'lekearlobe', 'lekearlobe@gmail.com', 'local', '$2a$10$3NpR901TyXZ/U8OHcDYlLe9j2aspBKU2D/jzmcVq9tKSSx.v.Jj9G', NULL, NULL, NULL, '2', NULL, NULL),
('62', 'censorflight', 'censorflight@gmail.com', 'local', '$2a$10$wYl96u/dpRldfIPtUsgnvOLCEkkGC1o6mguVlowYWwLI.patf4c16', NULL, NULL, NULL, '2', NULL, NULL),
('63', 'unreachedavailable', 'unreachedavailable@gmail.com', 'local', '$2a$10$FUABrYyeRMD68hECLHDPSOS1g8xUH1xtkpFXD2L/u/UjBnV63K73O', NULL, NULL, NULL, '2', NULL, NULL),
('64', 'nortoninevitable', 'nortoninevitable@gmail.com', 'local', '$2a$10$GuY4dW43Ryph2LH4FMipIOwkkzuJw/VMUHnB4UuInqY1FdjyY9Q3m', NULL, NULL, NULL, '2', NULL, NULL),
('65', 'maplelewis', 'maplelewis@gmail.com', 'local', '$2a$10$XuwPRq93KsaukqB92rIlyedTbF8/GWXxeGerszc5y./sxVLGDiAuS', NULL, NULL, NULL, '2', NULL, NULL),
('66', 'yttriumripple', 'yttriumripple@gmail.com', 'local', '$2a$10$/HTaA2SD3fxmquHpzsZbjuA1rg1gPa3pZG92e98GLzv0GLZnw//Q.', NULL, NULL, NULL, '2', NULL, NULL),
('67', 'lieflattered', 'lieflattered@gmail.com', 'local', '$2a$10$NZpJKsp/XT03kuL6CY1VMeYbp/ryeqUf3vti3BpzCSuJhzCATPgR.', NULL, NULL, NULL, '2', NULL, NULL),
('68', 'spraymosque', 'spraymosque@gmail.com', 'local', '$2a$10$Y3vt4ih5XQ36FmXIDeDSa.67DXS2ahbXlbTvtGOov9AubQC0Ggr36', NULL, NULL, NULL, '2', NULL, NULL),
('69', 'untreatedmail', 'untreatedmail@gmail.com', 'local', '$2a$10$cAdky8sidPUAhFLpGMO3mOYxAm2tmo3utuUA.QI7TCDEh6edYziMW', NULL, NULL, NULL, '2', NULL, NULL),
('70', 'aspireoctopus', 'aspireoctopus@gmail.com', 'local', '$2a$10$LsIAr.yEljnXPg9nB0NBhu4YLqud/UFKbv0qBmHYpSNhLpsp5nIb6', NULL, NULL, NULL, '2', NULL, NULL),
('71', 'scaredrainage', 'scaredrainage@gmail.com', 'local', '$2a$10$0fHbxF9qAKea5DO.sNqEgO9NMGH1uz/sAO3gG4MQZRbMZnJdUl6Qe', NULL, NULL, NULL, '2', NULL, NULL),
('72', 'cremeadams', 'cremeadams@gmail.com', 'local', '$2a$10$MIOM5LZCcYhOjhwM.tTFuOt1IOwPTEeKMqZIMJIZb8Ot/7hzpqsX6', NULL, NULL, NULL, '2', NULL, NULL),
('73', 'trapperboth', 'trapperboth@gmail.com', 'local', '$2a$10$eA58JNs6trYWeoeHWTKCZ.aAw5RuLVZuhdfSNImaICGalY8gmsH1C', NULL, NULL, NULL, '2', NULL, NULL),
('74', 'fancychancellor', 'fancychancellor@gmail.com', 'local', '$2a$10$uAwuxaIZYsaeh0U9RC7hq.82foNuCoD2qvsPW08DXasDy9vMPnPCK', NULL, NULL, NULL, '2', NULL, NULL),
('75', 'brandbenny', 'brandbenny@gmail.com', 'local', '$2a$10$Xocx03S4kWj2ZcX1xIKbiee7uI6KlZ4F52oXhPi8BsrCZC5XWfdam', NULL, NULL, NULL, '2', NULL, NULL),
('76', 'frokensaucepan', 'frokensaucepan@gmail.com', 'local', '$2a$10$KKtnr7CMyzi950vtfiwhIO1GRy0P2urA7J3.GcVJmraJ6nSzvqtTO', NULL, NULL, NULL, '2', NULL, NULL),
('77', 'meanwhilecoming', 'meanwhilecoming@gmail.com', 'local', '$2a$10$B0JtireDd7bJi3mt6DIyruTS5cOA3EhhrawbhdIF7dgg584L19aOq', NULL, NULL, NULL, '2', NULL, NULL),
('78', 'unicornmobilize', 'unicornmobilize@gmail.Com', 'local', '$2a$10$LmCMh2jrhqDwMj.qo1nmuep2iF/HhDcDjmUSCm.rnqXOYKBuY6OI.', NULL, NULL, NULL, '2', NULL, NULL),
('79', 'noveltyblatantly', 'noveltyblatantly@gmail.com', 'local', '$2a$10$W8aBdkgLiioQGxAt1KkdZ.jVr0LpZYGtWEgGMZyeso3ab42UXScoO', NULL, NULL, NULL, '2', NULL, NULL),
('80', 'sumsplornish', 'sumsplornish@gmail.com', 'local', '$2a$10$Be3.kc5oDFCMeQ.XIYw7mOgrYs0j52tg1.zHV0a34lQAdvb9jOMSu', NULL, NULL, NULL, '2', NULL, NULL),
('81', 'fetchstrength', 'fetchstrength@gmail.com', 'local', '$2a$10$LovkaRPv1TwR/e/84QPVnumwh/WwzsMcyNaE9hkP7E60QohqFL99q', NULL, NULL, NULL, '2', NULL, NULL),
('82', 'feabulge', 'feabulge@gmail.com', 'local', '$2a$10$rBH9p86JT1CL1UE./q0YPu988OEvjfrkK1zqC7viHkel7VtOfqhXW', NULL, NULL, NULL, '2', NULL, NULL),
('83', 'millcivil', 'millcivil@gmail.com', 'local', '$2a$10$UPr0M4U1.yKWXOcjqyAR2u/E7L5th4rhiDxHoJ4wvp0xbQIoBp8Qm', NULL, NULL, NULL, '2', NULL, NULL),
('84', 'dweebscraper', 'dweebscraper@gmail.com', 'local', '$2a$10$5cCTlNqjH.STS6qLhZTOgOjguvkBSCMpyCyTT2szD.nXSFscXUNC6', NULL, NULL, NULL, '2', NULL, NULL),
('85', 'clerkincredible', 'clerkincredible@gmail.com', 'local', '$2a$10$XXtvJJazO/iWSVBypUpZ..HP81zuTvWfi.yPpDkPePxBBhseOUTva', NULL, NULL, NULL, '2', NULL, NULL),
('86', 'tarzanwham', 'tarzanwham@gmail.com', 'local', '$2a$10$x7HvnhC2OxJEe7Uukeb75uU0qpEmLwbflXi8bB/6ZgO8dbQMcJjse', NULL, NULL, NULL, '2', NULL, NULL),
('87', 'fraidcorizon', 'fraidcorizon@gmail.com', 'local', '$2a$10$M5LulQ3lVHkpGChHsS5aHeZb1RPF3UlEOKscIakFZ7z8D9Uk6j7pW', NULL, NULL, NULL, '2', NULL, NULL),
('88', 'imagevirgin', 'imagevirgin@gmail.com', 'local', '$2a$10$wYO7cRgvGtz3Thy7OxTWfei9HvUZSi9owYco9HVya2zr3WKDsVkei', NULL, NULL, NULL, '2', NULL, NULL),
('89', 'dominancewhite', 'dominancewhite@gmail.com', 'local', '$2a$10$iDTtn0wbfcNLpVP0lI1lweT/gRszoSGtVPdIwQaxYHhiD7zPz5Kc.', NULL, NULL, NULL, '2', NULL, NULL),
('90', 'bingersmorals', 'bingersmorals@gmail.com', 'local', '$2a$10$eMAFuAfI4bTU70k.va3SKu4I3fKf.EhIyUOvDzySnrT9WM.6O1By6', NULL, NULL, NULL, '2', NULL, NULL),
('91', 'dumpregistered', 'dumpregistered@gmail.com', 'local', '$2a$10$TbG5YVtpaPSQ03NNpZFMBOCWL1WG5EwSPke5tu2AAUdNyhzR2Fd/.', NULL, NULL, NULL, '2', NULL, NULL),
('92', 'overstockjockstrap', 'overstockjockstrap@gmail.com', 'local', '$2a$10$hX0hMP5Vk5HWPMXsQykt.uhOoeBmjThPlg5iwdqVBn5IK9/0IAqkK', NULL, NULL, NULL, '2', NULL, NULL),
('93', 'pleadmerchants', 'pleadmerchants@gmail.com', 'local', '$2a$10$JSQ0.jkvrnBsXigCXsTctOzdWV8AjOSIphIR9bCFZqjUWcx7GexXi', NULL, NULL, NULL, '2', NULL, NULL),
('94', 'rockingrabble', 'rockingrabble@gmail.com', 'local', '$2a$10$R0eWoUDDiiCiSxjyWIyx0.yYv4pS0pXKMmTlk0fduqv6V3Nwyz0pu', NULL, NULL, NULL, '2', NULL, NULL),
('95', 'chapsguessing', 'chapsguessing@gmail.com', 'local', '$2a$10$0GEpKsTcGpFjjEevEIG.YO41QTNGgoUmKJ3msBDymLI8A4dbkg.FK', NULL, NULL, NULL, '2', NULL, NULL),
('96', 'lurchicy', 'lurchicy@gmail.com', 'local', '$2a$10$A9ZlGkebkwqdjT6uCThMVu2XcYzvH.n1kQBvkVB94VwWWdcb9AbRq', NULL, NULL, NULL, '2', NULL, NULL),
('97', 'baryonwrist', 'baryonwrist@gmail.Com', 'local', '$2a$10$PzqW5M5p7fhphc4zgy7Kf.yx0qzakkj9zA7VZSXfWjCI3NqqwXucS', NULL, NULL, NULL, '2', NULL, NULL),
('98', 'unsecuredpebbles', 'unsecuredpebbles@gmail.colm', 'local', '$2a$10$s4uTFglnPrwgxaLHo6CXEeK31SWf2HBYqfSZrR8Z8iUkBpcchmybi', NULL, NULL, NULL, '2', NULL, NULL),
('99', 'koalamax', 'koalamax@gmail.com', 'local', '$2a$10$4VU4eWQ6Za4sHr/ap5.6ROVkgC6oBH5L.trmoVj8MXJzwHsr7AGiq', NULL, NULL, NULL, '2', NULL, NULL),
('100', 'sophidubbed', 'sophidubbed@gmail.com', 'local', '$2a$10$RNdZIIx9dmdYflfOpdAiieDqWBxjaVpereHnNYXjkBQcOEhS0qnaa', NULL, NULL, NULL, '2', NULL, NULL),
('101', 'sesamecollar', 'sesamecollar@gmail.com', 'local', '$2a$10$WjV.RNbPy5sZ3h.oucWzsuKOZQPR2NXA7pnZaxWjYyeX77HTUJxu2', NULL, NULL, NULL, '2', NULL, NULL);

